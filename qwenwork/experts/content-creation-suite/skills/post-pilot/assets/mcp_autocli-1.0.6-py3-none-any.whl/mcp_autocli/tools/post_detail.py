"""`post_detail` tool — fetch one specific post (and its comments) by URL.

Why this exists:
content-radar wants to mine comments for pain points / negative sentiment /
user questions. `search` only gives titles + aggregate counts; the rich text
(comment bodies) lives in detail pages and needs a separate call.

Platform coverage:

| platform     | autocli subcommand                       | what it returns           |
|--------------|------------------------------------------|---------------------------|
| xiaohongshu  | `xiaohongshu creator-note-detail <url>`  | note + stats + comments   |
| youtube      | `youtube comments <url>`                 | comment list (+ video meta)|
| twitter      | `twitter thread <url>`                   | original tweet + replies  |
| zhihu        | `zhihu question <id>`                    | question + top answers    |
| douban       | `douban subject <id>`                    | movie/book metadata + reviews |
| arxiv        | `arxiv paper <id>`                       | paper metadata (no comments) |

URL → ID resolution: zhihu / douban / arxiv adapters take a bare numeric/
slug id (not a URL), so when the caller passes a URL we regex-match the
canonical patterns and extract the id. Anything we can't parse is forwarded
verbatim — autocli will reject it with a clear error if invalid.

Platforms NOT covered (and why):
- bilibili: only `subtitle` exists for video text content; no comment fetch.
- douyin / weibo: no detail/comment subcommand in autocli today.

Output is shaped via `normalize_detail` (see lib/result_normalizer.py) —
single dict with `comments[]`, not a list. Different shape from search/
user_timeline/following_feed/hot because the data model is fundamentally
"one post" not "list of posts".
"""
from __future__ import annotations

import asyncio
import re
import time
from typing import Any

from ..lib import platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    AutocliResult,
    run_autocli_json,
)
from ..lib.result_normalizer import NormalizedDetail, normalize_detail
from .search import (
    EXTENSION_HEAL_WAIT_SECONDS,
    RETRYABLE_REASONS,
    RETRY_BACKOFF_SECONDS,
    SEARCH_MAX_ATTEMPTS,
    _auto_launch_edge_for_login,
    _classify_error,
)


DETAIL_TIMEOUT_SECONDS = 45

# `--comment-limit` (xhs) and `--limit` (others) cap returned comment / answer
# rows. A None entry means the adapter has no comment-limit knob — we still
# slice client-side after normalize_detail returns.
PLATFORM_DETAIL_CMD: dict[str, tuple[str, str | None]] = {
    "xiaohongshu": ("creator-note-detail", None),
    "youtube":     ("comments",            "--limit"),
    "twitter":     ("thread",              "--limit"),
    "zhihu":       ("question",            "--limit"),
    "douban":      ("subject",             None),
    "arxiv":       ("paper",               None),
}

SUPPORTED_PLATFORMS: list[str] = list(PLATFORM_DETAIL_CMD.keys())

# Match canonical URL forms back to their bare id. Keep patterns permissive
# — autocli will reject malformed ids itself with a useful error.
_URL_TO_ID: dict[str, re.Pattern[str]] = {
    "xiaohongshu": re.compile(r"xiaohongshu\.com/(?:search_result|explore|discovery/item)/([a-f0-9]{24})"),
    "zhihu":  re.compile(r"zhihu\.com/question/(\d+)"),
    "douban": re.compile(r"douban\.com(?:/[a-z]+)?/subject/(\d+)"),
    "arxiv":  re.compile(r"arxiv\.org/(?:abs|pdf)/([\w.]+)"),
}


def _resolve_post_id(platform: str, url_or_id: str) -> str:
    """For id-only adapters, extract the id from a URL; passthrough otherwise."""
    pat = _URL_TO_ID.get(platform)
    if pat is None:
        return url_or_id
    m = pat.search(url_or_id)
    return m.group(1) if m else url_or_id


async def _attempt(args: list[str]) -> tuple[Any | None, str | None]:
    """Run one autocli detail call. Returns (parsed_json_or_None, skip_reason_or_None)."""
    try:
        parsed, raw = await run_autocli_json(args, timeout=DETAIL_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    # A dict with no useful fields is treated as empty_result so the retry
    # loop gets a chance — autocli occasionally returns `{}` on transient
    # extension hiccups before the real payload lands on retry.
    if isinstance(parsed, dict) and not parsed:
        return None, "empty_result"
    if isinstance(parsed, list) and not parsed:
        return None, "empty_result"
    return parsed, None


async def _fetch_one(
    platform_key: str, url: str, comment_limit: int
) -> tuple[Any | None, str | None]:
    spec = PLATFORM_DETAIL_CMD.get(platform_key)
    if spec is None:
        return None, "unsupported_platform_for_post_detail"
    subcmd, limit_flag = spec
    post_id = _resolve_post_id(platform_key, url)
    args = [platform_key, subcmd, post_id]
    if limit_flag is not None:
        args.extend([limit_flag, str(comment_limit)])

    last_reason: str | None = None
    for attempt in range(SEARCH_MAX_ATTEMPTS):
        parsed, last_reason = await _attempt(args)
        if parsed is not None:
            return parsed, None
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    if last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        parsed, last_reason = await _attempt(args)
        if parsed is not None:
            return parsed, None

    return None, last_reason


async def post_detail(
    platform: str,
    url: str,
    comment_limit: int = 30,
) -> dict[str, Any]:
    """Fetch one post + its comments.

    Args:
        platform: One of xiaohongshu / youtube / twitter.
        url: Full URL of the post / video / tweet.
        comment_limit: Max comments to return; capped at 100 in the tool schema.

    Returns:
        {
          "platform": str,
          "url":      str,
          "detail":   NormalizedDetail | None,
          "metadata": {
            "skip_reason":     str | None,
            "edge_launched":   bool | None,
            "elapsed_seconds": float,
          }
        }
    """
    platform = (platform or "").strip()
    url = (url or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if not url:
        raise ValueError("url must be non-empty")
    if platform not in platform_defs.PLATFORM_KEYS:
        raise ValueError(f"unsupported platform: {platform}")
    if platform not in PLATFORM_DETAIL_CMD:
        return {
            "platform": platform,
            "url": url,
            "detail": None,
            "metadata": {
                "skip_reason": "unsupported_platform_for_post_detail",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
            },
        }

    # Some adapters need a logged-in Edge profile (xhs, youtube, twitter);
    # others run anonymously (zhihu, douban, arxiv). requires_login covers
    # the platform_defs.PLATFORM_KEYS subset; new id-only platforms outside
    # that subset just return False and skip the login dance.
    launch_result = None
    if platform_defs.requires_login(platform):
        launch_result = await _auto_launch_edge_for_login([platform])

    started = time.monotonic()
    parsed, reason = await _fetch_one(platform, url, comment_limit)
    elapsed = round(time.monotonic() - started, 2)

    detail: NormalizedDetail | None = None
    if parsed is not None:
        detail = normalize_detail(platform, url, parsed)
        # Client-side cap on comments in case the subcommand ignored the flag.
        comments = detail.get("comments") or []
        if len(comments) > comment_limit:
            detail["comments"] = comments[:comment_limit]

    metadata: dict[str, Any] = {
        "skip_reason": reason,
        "edge_launched": bool(launch_result.get("ok")) if launch_result else None,
        "elapsed_seconds": elapsed,
    }
    if launch_result is not None:
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "platform": platform,
        "url": url,
        "detail": detail,
        "metadata": metadata,
    }
