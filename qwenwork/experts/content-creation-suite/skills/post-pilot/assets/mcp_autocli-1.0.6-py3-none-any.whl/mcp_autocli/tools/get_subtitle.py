"""`get_subtitle` tool — fetch a post's subtitle/caption segments.

This complements `download_media` for two use cases:
- An agent that wants a verbatim transcript with timestamps (not the ASR
  segments transcribe_audio gives — these are uploader-authored / platform-
  generated, and exact rather than recognized).
- Feeding a downstream video-script-generator with structured per-line text.

Platform coverage today:
- bilibili: `bilibili subtitle <bvid> --lang ...` — works for any video that
  has AI-generated or uploader-supplied subtitles. Returns segments with
  from/to/content. Cookies sufficient for anonymous access yield AI subs;
  uploader-paid subs may need login.
- douyin: two-step path — spawn `autocli douyin download <id>` to harvest
  `metadata.subtitle_infos` (URLs to the subtitle JSON files), then fetch
  the chosen language's JSON directly with a douyin Referer and parse the
  segments. Returns the same {from, to, content} shape as bilibili.
- youtube: `youtube transcript <url> --mode raw [--lang ...]` — uses
  YouTube's Android InnerTube API to fetch the official caption track,
  parsing the XML into per-line segments. Auto-falls-back to ASR captions
  if uploader-supplied captions are unavailable.

Other platforms (xiaohongshu / twitter) have no subtitle API exposed by
autocli — for those the correct path is download_media -> transcribe_audio
(ASR), or for non-strict transcripts download_media -> understand_media
(prose description).
"""
from __future__ import annotations

import asyncio
import json
import ssl
import time
import urllib.error
import urllib.request
from typing import Any

from ..lib.autocli_runner import AutocliNotFoundError, run_autocli_json


SUPPORTED_PLATFORMS: list[str] = ["bilibili", "douyin", "youtube"]

SUBTITLE_TIMEOUT_SECONDS = 60
DOUYIN_FETCH_TIMEOUT_SECONDS = 30

_SSL_CTX = ssl.create_default_context()

# Douyin subtitle CDN strictly checks Referer — same as the video direct links.
_DOUYIN_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Referer": "https://www.douyin.com/",
}


async def _fetch_douyin_subtitle_json(url: str) -> tuple[Any | None, str | None]:
    """Download douyin subtitle JSON. Returns (parsed_json, error_msg)."""
    def _blocking() -> tuple[Any | None, str | None]:
        req = urllib.request.Request(url, headers=_DOUYIN_HEADERS)
        try:
            with urllib.request.urlopen(req, timeout=DOUYIN_FETCH_TIMEOUT_SECONDS, context=_SSL_CTX) as resp:  # noqa: S310
                body = resp.read()
        except urllib.error.HTTPError as e:
            return None, f"http_{e.code}"
        except urllib.error.URLError as e:
            return None, f"url_error: {e.reason!r}"
        except (TimeoutError, OSError) as e:
            return None, f"io_error: {e!r}"

        # Subtitle is either JSON (TikTok/Douyin's structured format)
        # or WebVTT/SRT plaintext. Try JSON first.
        text = body.decode("utf-8", errors="replace")
        try:
            return json.loads(text), None
        except json.JSONDecodeError:
            return {"_raw_text": text}, None  # caller parses based on shape

    return await asyncio.to_thread(_blocking)


def _parse_douyin_subtitle(parsed: Any) -> list[dict]:
    """Convert Douyin subtitle JSON into [{index, from, to, content}, ...].

    Douyin returns one of two shapes:
    1. WebVTT plaintext (most common today). Lines look like:
         WEBVTT
         00:00:00.000 --> 00:00:02.500
         字幕内容
    2. Structured JSON: { utterances: [{start_time, end_time, text}] }
    """
    # Plain WebVTT path
    if isinstance(parsed, dict) and "_raw_text" in parsed:
        text = parsed["_raw_text"]
        segments = []
        idx = 0
        for block in text.split("\n\n"):
            block = block.strip()
            if not block or block.startswith("WEBVTT"):
                continue
            lines = block.splitlines()
            # find the timing line
            ts_line = None
            content_lines = []
            for ln in lines:
                if "-->" in ln:
                    ts_line = ln
                elif ts_line:
                    content_lines.append(ln)
            if not ts_line or not content_lines:
                continue
            try:
                left, right = [s.strip() for s in ts_line.split("-->", 1)]
            except ValueError:
                continue
            idx += 1
            segments.append({
                "index": idx,
                "from": left,
                "to": right.split()[0] if right else "",
                "content": "\n".join(content_lines).strip(),
            })
        return segments

    # Structured-JSON path
    if isinstance(parsed, dict) and isinstance(parsed.get("utterances"), list):
        segments = []
        for i, utt in enumerate(parsed["utterances"], 1):
            if not isinstance(utt, dict):
                continue
            # times come as milliseconds
            start_ms = utt.get("start_time", 0)
            end_ms = utt.get("end_time", 0)
            segments.append({
                "index": i,
                "from": f"{start_ms / 1000:.2f}s",
                "to": f"{end_ms / 1000:.2f}s",
                "content": utt.get("text", ""),
            })
        return segments

    return []


async def _get_subtitle_youtube(post_id: str, lang: str) -> dict[str, Any]:
    """YouTube subtitle via `autocli youtube transcript --mode raw`.

    Output of the adapter (mode=raw) is `[{timestamp: '0.00s', speaker: '',
    text: '...'}, ...]`. We map timestamp → from, take the next segment's
    timestamp → to (and an empty string for the last item), normalising to
    the shared {index, from, to, content} schema.

    post_id can be a full YouTube URL or a bare videoId — the adapter's
    first evaluate step normalises that for us.
    """
    started = time.monotonic()
    args = ["youtube", "transcript", post_id, "--mode", "raw"]
    if lang:
        args.extend(["--lang", lang])

    try:
        parsed, raw = await run_autocli_json(args, timeout=SUBTITLE_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return {
            "platform": "youtube",
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"autocli_spawn_error: {e!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    if not isinstance(parsed, list):
        tail = (raw.stdout or raw.stderr or "")[-200:]
        return {
            "platform": "youtube",
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"no_subtitle_or_error: {tail!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    segments: list[dict[str, Any]] = []
    for i, item in enumerate(parsed):
        if not isinstance(item, dict):
            continue
        ts = item.get("timestamp", "")
        text = item.get("text", "")
        # Next segment's timestamp is the natural `to` boundary; last segment
        # has no successor so leave to="" (callers that need precise end can
        # subtract a small epsilon from the next start).
        next_ts = ""
        if i + 1 < len(parsed) and isinstance(parsed[i + 1], dict):
            next_ts = parsed[i + 1].get("timestamp", "")
        segments.append({
            "index": i + 1,
            "from": ts,
            "to": next_ts,
            "content": text,
        })

    return {
        "platform": "youtube",
        "post_id": post_id,
        "segments": segments,
        "skip_reason": None if segments else "empty_transcript",
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }


async def _get_subtitle_douyin(post_id: str, lang: str) -> dict[str, Any]:
    """Two-step douyin subtitle: autocli download for subtitle_infos, then fetch JSON."""
    started = time.monotonic()
    args = ["douyin", "download", post_id, "--output", "/tmp/_mcp_autocli_unused"]
    try:
        parsed, raw = await run_autocli_json(args, timeout=SUBTITLE_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"autocli_spawn_error: {e!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    if not isinstance(parsed, dict):
        tail = (raw.stdout or raw.stderr or "")[-200:]
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"autocli_no_json: {tail!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    subtitle_infos = parsed.get("subtitle_infos") or []
    if not subtitle_infos:
        # Either video has no subtitles, or evaluate fell through (captcha/etc).
        extracted_via = parsed.get("extracted_via", "")
        if extracted_via == "none":
            return {
                "platform": "douyin",
                "post_id": post_id,
                "segments": [],
                "skip_reason": "page_not_rendered (captcha or anti-bot)",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": "no_subtitle_infos (video has no captions)",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # Pick subtitle entry. lang filter is best-effort — autocli's subtitle_infos
    # entries carry a `lang_id` int or `language` str depending on Douyin's
    # API version; we accept both.
    def _matches_lang(entry: dict) -> bool:
        if not lang:
            return True
        for key in ("language", "lang", "lang_id"):
            v = entry.get(key)
            if v is not None and str(v).lower() == lang.lower():
                return True
        return False

    target = next((e for e in subtitle_infos if isinstance(e, dict) and _matches_lang(e)), None)
    if target is None:
        target = subtitle_infos[0] if isinstance(subtitle_infos[0], dict) else None
    if target is None:
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": "subtitle_infos has no usable entry",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # Subtitle URL field is typically `url` or `subtitle_url`
    sub_url = target.get("url") or target.get("subtitle_url") or ""
    if not sub_url and isinstance(target.get("url_list"), list) and target["url_list"]:
        sub_url = target["url_list"][0]
    if not sub_url:
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": "subtitle entry has no url",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    raw_parsed, err = await _fetch_douyin_subtitle_json(sub_url)
    if raw_parsed is None:
        return {
            "platform": "douyin",
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"subtitle_fetch_failed: {err}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    segments = _parse_douyin_subtitle(raw_parsed)
    return {
        "platform": "douyin",
        "post_id": post_id,
        "segments": segments,
        "skip_reason": None if segments else "subtitle_parse_returned_empty",
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }


async def get_subtitle(
    platform: str,
    post_id: str,
    lang: str = "",
) -> dict[str, Any]:
    """Fetch subtitle segments for one post.

    Args:
        platform: Currently only "bilibili" supported.
        post_id: Platform-native id (bilibili: BVID, e.g. "BV1xxxxxx").
        lang: Optional language code (e.g. "zh-CN", "ai-zh", "en-US").
              Empty string means autocli picks the first available.

    Returns:
        {
          "platform": str,
          "post_id": str,
          "segments": [{"index": int, "from": str, "to": str, "content": str}],
          "skip_reason": str | None,
          "elapsed_seconds": float
        }
    """
    platform = (platform or "").strip()
    post_id = (post_id or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if not post_id:
        raise ValueError("post_id must be non-empty")

    started = time.monotonic()

    if platform not in SUPPORTED_PLATFORMS:
        return {
            "platform": platform,
            "post_id": post_id,
            "segments": [],
            "skip_reason": (
                f"unsupported_platform_for_subtitle (only {SUPPORTED_PLATFORMS}); "
                "for ASR transcripts on other platforms, use download_media then "
                "transcribe_audio."
            ),
            "elapsed_seconds": 0.0,
        }

    if platform == "douyin":
        return await _get_subtitle_douyin(post_id, lang)

    if platform == "youtube":
        return await _get_subtitle_youtube(post_id, lang)

    # bilibili
    args = ["bilibili", "subtitle", post_id]
    if lang:
        args.extend(["--lang", lang])

    try:
        parsed, raw = await run_autocli_json(args, timeout=SUBTITLE_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return {
            "platform": platform,
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"autocli_spawn_error: {e!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    if not isinstance(parsed, list):
        tail = (raw.stdout or raw.stderr or "")[-200:]
        # autocli throws "此视频没有发现外挂或智能字幕" etc. into stderr; surface as skip
        return {
            "platform": platform,
            "post_id": post_id,
            "segments": [],
            "skip_reason": f"no_subtitle_or_error: {tail!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # autocli returns [{index, from, to, content}, ...]
    segments = [
        {
            "index": seg.get("index"),
            "from": seg.get("from"),
            "to": seg.get("to"),
            "content": seg.get("content", ""),
        }
        for seg in parsed
        if isinstance(seg, dict)
    ]

    return {
        "platform": platform,
        "post_id": post_id,
        "segments": segments,
        "skip_reason": None if segments else "empty_subtitle",
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
