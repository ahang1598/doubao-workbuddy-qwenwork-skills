"""`user_timeline` tool — fetch the most recent posts of a specified user.

Use cases:
- Content creators tracking their own back-catalogue or a competitor's pace.
- Wukong content-radar's `follow_list` config: enumerate specific creator
  user-ids and pull each one's last N posts as supplementary signal.

Platform coverage is intentionally narrower than `search` because the
underlying autocli only exposes user-keyed retrieval on three platforms:

| platform     | autocli subcommand               | user_id format                |
|--------------|----------------------------------|-------------------------------|
| bilibili     | `bilibili user-videos <uid>`     | numeric UID (e.g. "12345")    |
| xiaohongshu  | `xiaohongshu user <user_id>`     | 24-char hex profile id        |
| douyin       | `douyin user <sec_uid>`          | sec_uid string                |

Weibo / Twitter / YouTube are not supported here:
- weibo / youtube: autocli has no user-keyed retrieval command at all.
- twitter: the `profile` subcommand returns bio/stats, not a tweet list; for
  Twitter follow-feeds use `following_feed` (covers self's timeline instead).

Reasons surfaced via skipped_platforms[].reason mirror search.py's classifier
verbatim — same retry policy, same self-heal pass on
`extension_disconnected`.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

from ..lib import platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    AutocliResult,
    run_autocli_json,
)
from ..lib.result_normalizer import NormalizedItem, normalize
from .search import (
    EXTENSION_HEAL_WAIT_SECONDS,
    RETRYABLE_REASONS,
    RETRY_BACKOFF_SECONDS,
    SEARCH_MAX_ATTEMPTS,
    _auto_launch_edge_for_login,
    _classify_error,
)


TIMELINE_TIMEOUT_SECONDS = 45

# Each platform's autocli subcommand for "give me this user's recent posts".
# Values are tuples (subcommand_name, takes_limit_flag) — `--limit` is the
# standard autocli flag but a couple of subcommands historically rejected it,
# so we keep it gated.
PLATFORM_TIMELINE_CMD: dict[str, tuple[str, bool]] = {
    "bilibili":    ("user-videos", True),
    "xiaohongshu": ("user",        True),
    "douyin":      ("user",        True),
}

SUPPORTED_PLATFORMS: list[str] = list(PLATFORM_TIMELINE_CMD.keys())


async def _attempt(args: list[str], platform_key: str) -> tuple[list[NormalizedItem] | None, str | None]:
    try:
        parsed, raw = await run_autocli_json(args, timeout=TIMELINE_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    items = normalize(platform_key, parsed)
    if items:
        return items, None
    return None, "empty_result"


async def _fetch_one(
    platform_key: str, user_id: str, limit: int
) -> tuple[list[NormalizedItem], str | None]:
    spec = PLATFORM_TIMELINE_CMD.get(platform_key)
    if spec is None:
        return [], "unsupported_platform_for_user_timeline"
    subcmd, takes_limit = spec
    args = [platform_key, subcmd, user_id]
    if takes_limit:
        args.extend(["--limit", str(limit)])

    last_reason: str | None = None
    for attempt in range(SEARCH_MAX_ATTEMPTS):
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    if last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None

    return [], last_reason


async def user_timeline(
    platform: str,
    user_id: str,
    limit: int = 20,
) -> dict[str, Any]:
    """Pull the most recent posts of one specific user on one specific platform.

    Args:
        platform: One of bilibili / xiaohongshu / douyin. Other keys are
          rejected with `unsupported_platform_for_user_timeline`.
        user_id: Platform-native user identifier (see module docstring).
        limit: Max items to return; capped at 50 in the tool schema.

    Returns:
        {
          "platform": str,
          "user_id":  str,
          "items":    [NormalizedItem, ...],
          "metadata": {
            "skip_reason":     str | None,
            "edge_launched":   bool | None,
            "elapsed_seconds": float,
          }
        }
    """
    platform = (platform or "").strip()
    user_id = (user_id or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if not user_id:
        raise ValueError("user_id must be non-empty")
    if platform not in platform_defs.PLATFORM_KEYS:
        raise ValueError(f"unsupported platform: {platform}")
    if platform not in PLATFORM_TIMELINE_CMD:
        return {
            "platform": platform,
            "user_id": user_id,
            "items": [],
            "metadata": {
                "skip_reason": "unsupported_platform_for_user_timeline",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
            },
        }

    # Pre-flight Edge launch if this is a login platform — same contract as
    # search: "agent asked for xhs user-timeline → Edge window appears".
    launch_result = None
    if platform_defs.requires_login(platform):
        launch_result = await _auto_launch_edge_for_login([platform])

    started = time.monotonic()
    items, reason = await _fetch_one(platform, user_id, limit)
    elapsed = round(time.monotonic() - started, 2)

    metadata: dict[str, Any] = {
        "skip_reason": reason,
        "edge_launched": bool(launch_result.get("ok")) if launch_result else None,
        "elapsed_seconds": elapsed,
    }
    if launch_result is not None:
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "platform": platform,
        "user_id": user_id,
        "items": items,
        "metadata": metadata,
    }
