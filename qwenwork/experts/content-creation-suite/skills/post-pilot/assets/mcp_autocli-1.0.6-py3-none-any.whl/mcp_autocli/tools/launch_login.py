"""`launch_login` tool — spawn the dedicated Edge profile and open login tabs
for the requested platforms. Returns immediately; does not wait for the user.

This tool exists because logging in is the one step machines cannot do for
humans. The Wukong agent calls it when `search`'s metadata reports
`platforms_skipped[reason=login_required]`, then prompts the user to log in
and reply "已登录" before retrying search.

We deliberately do NOT:
- Wait for the extension to come back online (agent retries `search` instead)
- Block on user input (MCP tools must return promptly)
- Touch the user's primary Edge profile — we always use ~/.autocli/edge-profile
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import signal
import subprocess
from typing import Any

from ..lib import paths, platform_defs


LAUNCH_TIMEOUT_SECONDS = 10
_EXTENSION_VERSION_FILE = paths.AUTOCLI_DIR / ".extension-version"


def _read_extension_version() -> str | None:
    """Read version from the installed extension's manifest.json."""
    manifest = paths.EXTENSION_DIR / "manifest.json"
    if not manifest.exists():
        return None
    try:
        with open(manifest, "r", encoding="utf-8") as f:
            return json.load(f).get("version")
    except (json.JSONDecodeError, OSError):
        return None


def _read_cached_version() -> str | None:
    try:
        return _EXTENSION_VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return None


def _write_cached_version(version: str) -> None:
    try:
        _EXTENSION_VERSION_FILE.write_text(version, encoding="utf-8")
    except OSError:
        pass


def _kill_dedicated_edge() -> bool:
    """Kill Edge processes running under the dedicated autocli profile.

    Returns True if any process was killed.
    """
    profile_flag = str(paths.EDGE_PROFILE_DIR)
    killed = False
    try:
        out = subprocess.check_output(["ps", "aux"], text=True)
        for line in out.splitlines():
            if "Microsoft Edge" in line and profile_flag in line:
                parts = line.split()
                pid = int(parts[1])
                try:
                    os.kill(pid, signal.SIGTERM)
                    killed = True
                except OSError:
                    pass
    except (subprocess.SubprocessError, OSError):
        pass
    return killed


def _clear_extension_cache() -> None:
    """Delete Chromium's cached extension data so it re-reads from disk."""
    profile_default = paths.EDGE_PROFILE_DIR / "Default"
    for subdir in ("Service Worker", "Local Extension Settings",
                   "Extension State", "Extension Scripts"):
        target = profile_default / subdir
        if target.exists():
            try:
                shutil.rmtree(target)
            except OSError:
                pass


def _ensure_extension_fresh() -> None:
    """If the extension was updated on disk, kill old Edge and clear cache."""
    current = _read_extension_version()
    if not current:
        return
    cached = _read_cached_version()
    if cached == current:
        return
    if cached is not None:
        _kill_dedicated_edge()
        import time
        time.sleep(1)
        _clear_extension_cache()
    _write_cached_version(current)


def _build_edge_args(login_urls: list[str]) -> list[str]:
    """Construct the msedge.exe argv that opens our dedicated profile + tabs.

    --user-data-dir pins us to the isolated profile so the user's primary Edge
    is never touched. --new-window forces a fresh window even if msedge is
    already running for the dedicated profile (so the user can find it).
    """
    args = [
        f"--user-data-dir={paths.EDGE_PROFILE_DIR}",
        "--new-window",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    # Loading the extension is what makes autocli's data flow work. The
    # extension dir is dropped here by the content-radar skill's setup script;
    # if it's missing we still launch (the user may want a login-only window).
    if paths.EXTENSION_DIR.exists():
        args.append(f"--load-extension={paths.EXTENSION_DIR}")
    args.extend(login_urls)
    return args


def _spawn_edge(edge_exe, args: list[str]) -> int:
    """Spawn msedge detached from the MCP server. Returns its PID.

    creationflags=DETACHED_PROCESS on Windows so killing the MCP server later
    does not also kill Edge. On macOS, start_new_session=True plays the
    equivalent role.
    """
    if paths.IS_WINDOWS:
        flags = 0x00000008  # DETACHED_PROCESS
        proc = subprocess.Popen(
            [str(edge_exe), *args],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
            close_fds=True,
        )
    else:
        proc = subprocess.Popen(
            [str(edge_exe), *args],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            close_fds=True,
        )
    return proc.pid


async def launch_login(
    platforms: list[str],
    url_overrides: dict[str, str] | None = None,
    extension_only: bool = False,
) -> dict[str, Any]:
    """Open the dedicated Edge with login tabs for the given platforms.

    *url_overrides* maps platform key → URL to open instead of the default
    login URL.

    *extension_only* launches Edge with just the extension loaded (no URL
    tabs). Used by publish — the adapter's navigate step opens the page.

    Returns:
        {
          "ok": bool,
          "edge_pid": int | None,
          "opened_pages": [{platform, url}, ...],
          "skipped_platforms": [{platform, reason}, ...],
          "user_instruction": str,
          "error": str | None,
        }
    """
    _ensure_extension_fresh()

    if not platforms:
        return {
            "ok": False,
            "edge_pid": None,
            "opened_pages": [],
            "skipped_platforms": [],
            "user_instruction": "",
            "error": "platforms must be a non-empty list",
        }

    edge_exe = paths.edge_executable()
    if edge_exe is None:
        return {
            "ok": False,
            "edge_pid": None,
            "opened_pages": [],
            "skipped_platforms": [],
            "user_instruction": "",
            "error": (
                "Microsoft Edge not installed. Install from "
                "https://www.microsoft.com/edge/download and retry."
            ),
        }

    # extension_only: just ensure Edge + extension are running, no URL tabs.
    if extension_only:
        paths.EDGE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        args = _build_edge_args([])
        try:
            pid = await asyncio.wait_for(
                asyncio.to_thread(_spawn_edge, edge_exe, args),
                timeout=LAUNCH_TIMEOUT_SECONDS,
            )
        except (asyncio.TimeoutError, OSError) as e:
            return {
                "ok": False, "edge_pid": None,
                "opened_pages": [], "skipped_platforms": [],
                "user_instruction": "",
                "error": f"Edge spawn failed: {e!r}",
            }
        return {
            "ok": True, "edge_pid": pid,
            "opened_pages": [], "skipped_platforms": [],
            "user_instruction": "",
            "error": None,
        }

    overrides = url_overrides or {}
    opened: list[dict[str, str]] = []
    skipped: list[dict[str, str]] = []
    for key in platforms:
        if key in overrides:
            opened.append({"platform": key, "url": overrides[key]})
            continue
        p = platform_defs.get(key)
        if p is None:
            skipped.append({"platform": key, "reason": "unsupported_platform"})
            continue
        if not p.requires_login:
            skipped.append({"platform": key, "reason": "platform_does_not_need_login"})
            continue
        opened.append({"platform": key, "url": p.login_url})

    if not opened:
        return {
            "ok": False,
            "edge_pid": None,
            "opened_pages": [],
            "skipped_platforms": skipped,
            "user_instruction": "",
            "error": "no valid login platforms in request",
        }

    paths.EDGE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    args = _build_edge_args([p["url"] for p in opened])
    try:
        pid = await asyncio.wait_for(
            asyncio.to_thread(_spawn_edge, edge_exe, args),
            timeout=LAUNCH_TIMEOUT_SECONDS,
        )
    except asyncio.TimeoutError:
        return {
            "ok": False,
            "edge_pid": None,
            "opened_pages": opened,
            "skipped_platforms": skipped,
            "user_instruction": "",
            "error": f"Edge spawn timed out after {LAUNCH_TIMEOUT_SECONDS}s",
        }
    except OSError as e:
        return {
            "ok": False,
            "edge_pid": None,
            "opened_pages": opened,
            "skipped_platforms": skipped,
            "user_instruction": "",
            "error": f"Edge spawn failed: {e!r}",
        }

    names = ", ".join(
        platform_defs.get(p["platform"]).display_name  # type: ignore[union-attr]
        for p in opened
    )
    instruction = (
        f"已为你打开 {names} 的登录页（AutoCLI 专用 Edge 窗口，与主浏览器隔离）。"
        f"请在新窗口完成登录后回复\"已登录\"，我将重新搜索。"
    )

    return {
        "ok": True,
        "edge_pid": pid,
        "opened_pages": opened,
        "skipped_platforms": skipped,
        "user_instruction": instruction,
        "error": None,
    }
