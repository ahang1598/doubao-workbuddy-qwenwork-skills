"""`platform_action` tool — generic gateway to any autocli adapter subcommand.

Existing specialised tools (search / hot / post_detail / user_timeline /
following_feed / account_dashboard / account_notifications / download_media /
publish / get_subtitle / transcribe_audio / extract_keyframes / launch_login)
remain untouched.  This tool covers *everything else*: per-platform read and
write operations that map 1-to-1 onto `autocli <platform> <action> [args]`.

Design:
- One MCP tool instead of 150+ individual tools (avoids LLM tool-choice
  overload).
- A static PLATFORM_ACTIONS registry declares every legal (platform, action)
  pair with its positional args, named flags, login requirement, and write
  flag.
- Validation happens at the MCP layer; autocli is only spawned for known
  combinations.
- Write operations carry a `write_warning` field in the response so the
  calling agent can surface a confirmation prompt before committing the
  action.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any

from ..lib import platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    run_autocli_json,
)
from .search import (
    EXTENSION_HEAL_WAIT_SECONDS,
    RETRYABLE_REASONS,
    RETRY_BACKOFF_SECONDS,
    SEARCH_MAX_ATTEMPTS,
    _auto_launch_edge_for_login,
    _classify_error,
)


ACTION_TIMEOUT_SECONDS = 60


@dataclass(frozen=True)
class ActionSpec:
    positional: list[str]
    flags: list[str]
    login: bool
    write: bool


# ---------------------------------------------------------------------------
# Action registry — every (platform, action) pair the MCP layer accepts.
#
# Keys that are already covered by specialised tools are intentionally
# excluded so there's no ambiguity about which tool to use.
# ---------------------------------------------------------------------------

PLATFORM_ACTIONS: dict[str, dict[str, ActionSpec]] = {
    # ── Twitter / X ──────────────────────────────────────────────────────
    # NOTE: "post" is handled by the `publish` tool (platform="twitter").
    "twitter": {
        "profile":       ActionSpec(["username"], [],            True, False),
        "reply":         ActionSpec(["url", "text"], [],         True, True),
        "delete":        ActionSpec(["url"],      [],            True, True),
        "like":          ActionSpec(["url"],      [],            True, True),
        "bookmark":      ActionSpec(["url"],      [],            True, True),
        "unbookmark":    ActionSpec(["url"],      [],            True, True),
        "bookmarks":     ActionSpec([],           ["limit"],     True, False),
        "follow":        ActionSpec(["username"], [],            True, True),
        "unfollow":      ActionSpec(["username"], [],            True, True),
        "block":         ActionSpec(["username"], [],            True, True),
        "unblock":       ActionSpec(["username"], [],            True, True),
        "followers":     ActionSpec(["username"], ["limit"],     True, False),
        "following":     ActionSpec(["username"], ["limit"],     True, False),
        "notifications": ActionSpec([],           ["limit"],     True, False),
        "hide-reply":    ActionSpec(["url"],      [],            True, True),
        "reply-dm":      ActionSpec(["username", "text"], [],    True, True),
        "article":       ActionSpec(["url"],      [],            True, False),
        "accept":        ActionSpec([],           [],            True, True),
        "download":      ActionSpec(["username"], ["tweet-url", "limit", "output"], True, False),
    },

    # ── YouTube ──────────────────────────────────────────────────────────
    "youtube": {
        "video":            ActionSpec(["url"],  [],            True, False),
        "comments":         ActionSpec(["url"],  ["limit"],     True, False),
        "comment":          ActionSpec(["url", "text"], [],     True, True),
        "transcript":       ActionSpec(["url"],  [],            True, False),
        "transcript-group": ActionSpec(["url"],  [],            True, False),
    },

    # ── Reddit ───────────────────────────────────────────────────────────
    "reddit": {
        "frontpage":     ActionSpec([],               ["limit"],  True, False),
        "hot":           ActionSpec([],               ["limit"],  True, False),
        "popular":       ActionSpec([],               ["limit"],  True, False),
        "subreddit":     ActionSpec(["subreddit"],    ["limit"],  True, False),
        "read":          ActionSpec(["url"],          [],         True, False),
        "comment":       ActionSpec(["post-id", "text"], [],     True, True),
        "save":          ActionSpec(["url"],          [],         True, True),
        "saved":         ActionSpec([],               ["limit"],  True, False),
        "upvote":        ActionSpec(["url"],          [],         True, True),
        "upvoted":       ActionSpec([],               ["limit"],  True, False),
        "subscribe":     ActionSpec(["subreddit"],    [],         True, True),
        "user":          ActionSpec(["username"],     [],         True, False),
        "user-posts":    ActionSpec(["username"],     ["limit"],  True, False),
        "user-comments": ActionSpec(["username"],     ["limit"],  True, False),
    },

    # ── Facebook ─────────────────────────────────────────────────────────
    "facebook": {
        "feed":          ActionSpec([],            ["limit"],  True, False),
        "profile":       ActionSpec(["username"],  [],         True, False),
        "friends":       ActionSpec([],            ["limit"],  True, False),
        "add-friend":    ActionSpec(["username"],  [],         True, True),
        "groups":        ActionSpec([],            ["limit"],  True, False),
        "join-group":    ActionSpec(["group-url"], [],         True, True),
        "events":        ActionSpec([],            ["limit"],  True, False),
        "memories":      ActionSpec([],            [],         True, False),
        "notifications": ActionSpec([],            ["limit"],  True, False),
    },

    # ── Instagram ────────────────────────────────────────────────────────
    "instagram": {
        "explore":   ActionSpec([],               ["limit"],  True, False),
        "profile":   ActionSpec(["username"],      [],         True, False),
        "user":      ActionSpec(["username"],      ["limit"],  True, False),
        "follow":    ActionSpec(["username"],      [],         True, True),
        "unfollow":  ActionSpec(["username"],      [],         True, True),
        "followers": ActionSpec(["username"],      ["limit"],  True, False),
        "following": ActionSpec(["username"],      ["limit"],  True, False),
        "like":      ActionSpec(["url"],           [],         True, True),
        "unlike":    ActionSpec(["url"],           [],         True, True),
        "comment":   ActionSpec(["url", "text"],   [],         True, True),
        "save":      ActionSpec(["url"],           [],         True, True),
        "unsave":    ActionSpec(["url"],           [],         True, True),
        "saved":     ActionSpec([],                ["limit"],  True, False),
    },

    # ── TikTok ───────────────────────────────────────────────────────────
    "tiktok": {
        "explore":       ActionSpec([],               ["limit"],  True, False),
        "profile":       ActionSpec(["username"],      [],         True, False),
        "user":          ActionSpec(["username"],      ["limit"],  True, False),
        "follow":        ActionSpec(["username"],      [],         True, True),
        "unfollow":      ActionSpec(["username"],      [],         True, True),
        "following":     ActionSpec([],                ["limit"],  True, False),
        "friends":       ActionSpec([],                ["limit"],  True, False),
        "like":          ActionSpec(["url"],           [],         True, True),
        "unlike":        ActionSpec(["url"],           [],         True, True),
        "comment":       ActionSpec(["url", "text"],   [],         True, True),
        "save":          ActionSpec(["url"],           [],         True, True),
        "unsave":        ActionSpec(["url"],           [],         True, True),
        "live":          ActionSpec(["username"],      [],         True, False),
        "notifications": ActionSpec([],                ["limit"],  True, False),
    },

    # ── Medium ───────────────────────────────────────────────────────────
    "medium": {
        "feed": ActionSpec([],           ["limit"],  True, False),
        "user": ActionSpec(["username"], [],         True, False),
    },

    # ── Substack ─────────────────────────────────────────────────────────
    "substack": {
        "feed":        ActionSpec([],              ["limit"],  True, False),
        "publication": ActionSpec(["publication"], [],         True, False),
    },

    # ── Discord ──────────────────────────────────────────────────────────
    "discord-app": {
        "servers":  ActionSpec([],       [],         True, False),
        "channels": ActionSpec([],       [],         True, False),
        "members":  ActionSpec([],       ["limit"],  True, False),
        "read":     ActionSpec([],       ["limit"],  True, False),
        "send":     ActionSpec(["text"], [],         True, True),
        "status":   ActionSpec([],       [],         True, False),
    },

    # ── Coupang ──────────────────────────────────────────────────────────
    "coupang": {
        "add-to-cart": ActionSpec(["url"], [], True, True),
    },

    # ── Barchart ─────────────────────────────────────────────────────────
    "barchart": {
        "quote":   ActionSpec(["symbol"], [],                     True, False),
        "options": ActionSpec(["symbol"], ["type", "limit"],      True, False),
        "greeks":  ActionSpec(["symbol"], ["type", "limit"],      True, False),
        "flow":    ActionSpec([],         ["limit"],              True, False),
    },

    # ── Yahoo Finance ────────────────────────────────────────────────────
    "yahoo-finance": {
        "quote": ActionSpec(["symbol"], [], True, False),
    },

    # ── Notion ───────────────────────────────────────────────────────────
    "notion": {
        "read":      ActionSpec([],       [],         True, False),
        "write":     ActionSpec(["text"], [],         True, True),
        "new":       ActionSpec(["title"],["type"],   True, True),
        "export":    ActionSpec([],       ["format"], True, False),
        "favorites": ActionSpec([],       [],         True, False),
        "sidebar":   ActionSpec([],       [],         True, False),
        "status":    ActionSpec([],       [],         True, False),
    },

    # ── ChatGPT ──────────────────────────────────────────────────────────
    "chatgpt": {
        "ask":    ActionSpec(["text"],  ["timeout"],  False, True),
        "send":   ActionSpec(["text"],  [],           True,  True),
        "read":   ActionSpec([],        [],           True,  False),
        "new":    ActionSpec([],        [],           True,  True),
        "ax":     ActionSpec(["text"],  [],           False, True),
        "status": ActionSpec([],        [],           True,  False),
    },

    # ── HackerNews ───────────────────────────────────────────────────────
    "hackernews": {
        "top":  ActionSpec([],           ["limit"],  False, False),
        "best": ActionSpec([],           ["limit"],  False, False),
        "new":  ActionSpec([],           ["limit"],  False, False),
        "ask":  ActionSpec([],           ["limit"],  False, False),
        "show": ActionSpec([],           ["limit"],  False, False),
        "jobs": ActionSpec([],           ["limit"],  False, False),
        "user": ActionSpec(["username"], [],         False, False),
    },

    # ── Lobsters ─────────────────────────────────────────────────────────
    "lobsters": {
        "hot":    ActionSpec([], ["limit"],  False, False),
        "active": ActionSpec([], ["limit"],  False, False),
        "newest": ActionSpec([], ["limit"],  False, False),
        "tag":    ActionSpec(["tag"], ["limit"], False, False),
    },

    # ── Dev.to ───────────────────────────────────────────────────────────
    "devto": {
        "top":  ActionSpec([],           ["limit"],  False, False),
        "user": ActionSpec(["username"], ["limit"],  False, False),
    },

    # ── StackOverflow ────────────────────────────────────────────────────
    "stackoverflow": {
        "hot":        ActionSpec([], ["limit"],  False, False),
        "bounties":   ActionSpec([], ["limit"],  False, False),
        "unanswered": ActionSpec([], ["limit"],  False, False),
    },

    # ── arXiv ────────────────────────────────────────────────────────────
    "arxiv": {
        "paper": ActionSpec(["paper-id"], [], False, False),
    },

    # ── Hugging Face ─────────────────────────────────────────────────────
    "hf": {
        "top": ActionSpec([], ["limit"], False, False),
    },

    # ── Wikipedia ────────────────────────────────────────────────────────
    "wikipedia": {
        "summary":  ActionSpec(["title"],  [],         False, False),
        "random":   ActionSpec([],         ["limit"],  False, False),
        "trending": ActionSpec([],         ["limit"],  False, False),
    },

    # ── Google ───────────────────────────────────────────────────────────
    "google": {
        "news":    ActionSpec(["query"],   ["limit"],  False, False),
        "trends":  ActionSpec([],          ["limit"],  False, False),
        "suggest": ActionSpec(["query"],   [],         False, False),
    },

    # ── Bloomberg ────────────────────────────────────────────────────────
    "bloomberg": {
        "main":         ActionSpec([], ["limit"], False, False),
        "markets":      ActionSpec([], ["limit"], False, False),
        "economics":    ActionSpec([], ["limit"], False, False),
        "politics":     ActionSpec([], ["limit"], False, False),
        "tech":         ActionSpec([], ["limit"], False, False),
        "industries":   ActionSpec([], ["limit"], False, False),
        "opinions":     ActionSpec([], ["limit"], False, False),
        "businessweek": ActionSpec([], ["limit"], False, False),
        "feeds":        ActionSpec([], ["limit"], False, False),
    },

    # ── Apple Podcasts ───────────────────────────────────────────────────
    "apple-podcasts": {
        "episodes": ActionSpec(["podcast-url"], ["limit"], False, False),
    },

    # ── Grok ─────────────────────────────────────────────────────────────
    "grok": {
        "ask": ActionSpec(["text"], ["timeout"], False, True),
    },

    # ── Cursor ───────────────────────────────────────────────────────────
    "cursor": {
        "ask":          ActionSpec(["text"],  ["timeout"],  False, True),
        "send":         ActionSpec(["text"],  [],           False, True),
        "read":         ActionSpec([],        [],           False, False),
        "new":          ActionSpec([],        [],           False, True),
        "composer":     ActionSpec(["text"],  [],           False, True),
        "dump":         ActionSpec([],        [],           False, False),
        "export":       ActionSpec([],        ["format"],   False, False),
        "extract-code": ActionSpec([],        [],           False, False),
        "history":      ActionSpec([],        ["limit"],    False, False),
        "model":        ActionSpec([],        [],           False, False),
        "screenshot":   ActionSpec([],        [],           False, False),
        "status":       ActionSpec([],        [],           False, False),
    },

    # ── Codex ────────────────────────────────────────────────────────────
    "codex": {
        "ask":          ActionSpec(["text"],  ["timeout"],  False, True),
        "send":         ActionSpec(["text"],  [],           False, True),
        "read":         ActionSpec([],        [],           False, False),
        "new":          ActionSpec([],        [],           False, True),
        "dump":         ActionSpec([],        [],           False, False),
        "export":       ActionSpec([],        ["format"],   False, False),
        "extract-diff": ActionSpec([],        [],           False, False),
        "history":      ActionSpec([],        ["limit"],    False, False),
        "model":        ActionSpec([],        [],           False, False),
        "screenshot":   ActionSpec([],        [],           False, False),
        "status":       ActionSpec([],        [],           False, False),
    },
}


# Flat set for quick validation.
ALL_PLATFORMS_WITH_ACTIONS: list[str] = sorted(PLATFORM_ACTIONS.keys())


def _build_action_summary() -> str:
    """Build a compact action registry string for the tool description."""
    lines: list[str] = []
    for plat in sorted(PLATFORM_ACTIONS):
        specs = PLATFORM_ACTIONS[plat]
        read_actions = sorted(a for a, s in specs.items() if not s.write)
        write_actions = sorted(a for a, s in specs.items() if s.write)
        parts: list[str] = []
        if read_actions:
            parts.append("read: " + ", ".join(read_actions))
        if write_actions:
            parts.append("WRITE: " + ", ".join(write_actions))
        lines.append(f"  {plat}: " + " | ".join(parts))
    return "\n".join(lines)


ACTION_SUMMARY: str = _build_action_summary()


# ---------------------------------------------------------------------------
# Core implementation
# ---------------------------------------------------------------------------

async def _attempt(
    args: list[str],
) -> tuple[Any | None, str | None]:
    """Run one autocli invocation. Returns (parsed_json, skip_reason)."""
    try:
        parsed, raw = await run_autocli_json(args, timeout=ACTION_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    if isinstance(parsed, (dict, list)) and not parsed:
        return None, "empty_result"
    return parsed, None


async def platform_action(
    platform: str,
    action: str,
    args: list[str] | None = None,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute an autocli adapter subcommand.

    Args:
        platform: Platform key (e.g. "twitter", "instagram").
        action: Subcommand name (e.g. "profile", "like", "follow").
        args: Positional arguments (e.g. ["elonmusk"] for twitter profile).
        options: Named flags as key-value pairs (e.g. {"limit": 20}).

    Returns:
        {
          "platform":      str,
          "action":        str,
          "data":          <parsed JSON from autocli> | None,
          "write_warning": str | None,     # set for write actions
          "metadata": {
            "skip_reason":     str | None,
            "edge_launched":   bool | None,
            "elapsed_seconds": float,
            "is_write":        bool,
          }
        }
    """
    platform = (platform or "").strip()
    action = (action or "").strip()
    args = args or []
    options = options or {}

    if not platform:
        raise ValueError("platform must be non-empty")
    if not action:
        raise ValueError("action must be non-empty")

    # Validate platform exists in registry.
    plat_actions = PLATFORM_ACTIONS.get(platform)
    if plat_actions is None:
        return {
            "platform": platform,
            "action": action,
            "data": None,
            "write_warning": None,
            "metadata": {
                "skip_reason": f"unsupported_platform: {platform}. "
                               f"Supported: {', '.join(ALL_PLATFORMS_WITH_ACTIONS)}",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
                "is_write": False,
            },
        }

    # Validate action exists for this platform.
    spec = plat_actions.get(action)
    if spec is None:
        available = ", ".join(sorted(plat_actions.keys()))
        return {
            "platform": platform,
            "action": action,
            "data": None,
            "write_warning": None,
            "metadata": {
                "skip_reason": f"unsupported_action: '{action}' on {platform}. "
                               f"Available: {available}",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
                "is_write": False,
            },
        }

    # Build the autocli argv.
    cli_args: list[str] = [platform, action]
    cli_args.extend(str(a) for a in args)
    for flag, value in options.items():
        cli_args.append(f"--{flag}")
        cli_args.append(str(value))

    # Pre-flight Edge launch for login platforms.
    launch_result = None
    if spec.login and platform_defs.requires_login(platform):
        launch_result = await _auto_launch_edge_for_login([platform])

    # Write-action warning.
    write_warning = None
    if spec.write:
        write_warning = (
            f"WRITE OPERATION: '{action}' on {platform} will modify data "
            f"on the user's real account. Ensure the user has confirmed "
            f"this action before proceeding."
        )

    # Execute with retry.
    started = time.monotonic()
    last_reason: str | None = None
    data: Any = None

    for attempt_num in range(SEARCH_MAX_ATTEMPTS):
        data, last_reason = await _attempt(cli_args)
        if data is not None:
            break
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt_num < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    # Extension self-heal pass.
    if data is None and last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        data, last_reason = await _attempt(cli_args)

    elapsed = round(time.monotonic() - started, 2)

    metadata: dict[str, Any] = {
        "skip_reason": last_reason if data is None else None,
        "edge_launched": bool(launch_result.get("ok")) if launch_result else None,
        "elapsed_seconds": elapsed,
        "is_write": spec.write,
    }
    if launch_result is not None:
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "platform": platform,
        "action": action,
        "data": data,
        "write_warning": write_warning,
        "metadata": metadata,
    }
