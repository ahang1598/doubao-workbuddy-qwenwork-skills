"""`mcp-autocli setup` — bootstrap autocli binary + chrome extension.

Pip install drops the Python MCP server, but the server is useless without:
- The `autocli` binary at ~/.local/bin/ (Rust-compiled, platform-specific)
- The chrome extension at ~/.autocli/chrome-extension/ (driven by autocli)
- ~/.autocli/edge-profile/ (Edge stashes cookies here)
- A working Edge install (we only verify, never auto-install — too heavy)

This subcommand handles steps 1–3 so that `pip install mcp-autocli` followed
by `mcp-autocli setup` leaves the user one `launch_login` away from a working
search. Idempotent; safe to re-run. Pass --force to redownload everything.

Why stdlib-only: keeping MCP server's dependency footprint to just `mcp`
itself avoids dragging requests/click/etc. into every install.
"""
from __future__ import annotations

import argparse
import io
import json
import platform
import shutil
import sys
import tarfile
import urllib.error
import urllib.request
import zipfile
from importlib import resources
from pathlib import Path

from .lib import paths


# autocli upstream publishes per-target archives on GitHub releases. URL
# pattern: https://github.com/nashsu/autocli/releases/{tag}/download/{name}
AUTOCLI_RELEASE_BASE = "https://github.com/nashsu/autocli/releases/latest/download"

# Microsoft-maintained fwlink for the current Stable channel macOS Edge .pkg.
# Used as the brew fallback when Homebrew is unavailable and sudo is
# passwordless-ready.
EDGE_MAC_PKG_URL = "https://go.microsoft.com/fwlink/?linkid=2093504"

# (OS, machine) → (target triple, archive extension). The triples match
# autocli's release artifact names; do NOT rename without checking upstream.
_TARGET_MAP: dict[tuple[str, str], tuple[str, str]] = {
    ("win32",  "amd64"):   ("x86_64-pc-windows-msvc",       "zip"),
    ("win32",  "x86_64"):  ("x86_64-pc-windows-msvc",       "zip"),
    ("darwin", "x86_64"):  ("x86_64-apple-darwin",          "tar.gz"),
    ("darwin", "arm64"):   ("aarch64-apple-darwin",         "tar.gz"),
    ("linux",  "x86_64"):  ("x86_64-unknown-linux-musl",    "tar.gz"),
    ("linux",  "aarch64"): ("aarch64-unknown-linux-musl",   "tar.gz"),
    ("linux",  "arm64"):   ("aarch64-unknown-linux-musl",   "tar.gz"),
}


def _print_step(msg: str) -> None:
    print(f"==> {msg}", flush=True)


def _print_ok(msg: str) -> None:
    print(f"    [OK]   {msg}", flush=True)


def _print_info(msg: str) -> None:
    print(f"    [INFO] {msg}", flush=True)


def _print_warn(msg: str) -> None:
    print(f"    [WARN] {msg}", flush=True)


def _print_fail(msg: str) -> None:
    print(f"    [FAIL] {msg}", file=sys.stderr, flush=True)


def _detect_target() -> tuple[str, str]:
    """Map current OS/arch to autocli's release artifact naming.

    Raises RuntimeError with a clear hint if the host isn't on the supported
    matrix — better than a 404 against GitHub.
    """
    os_key = sys.platform  # win32 / darwin / linux
    machine = platform.machine().lower()
    key = (os_key, machine)
    if key not in _TARGET_MAP:
        raise RuntimeError(
            f"Unsupported platform: {os_key}/{machine}. "
            f"Supported: {sorted(_TARGET_MAP.keys())}"
        )
    return _TARGET_MAP[key]


def _download(url: str) -> bytes:
    """Fetch a URL into memory. Used for the autocli archive (single ~MB-sized blob).

    Streaming-to-file would be marginally nicer for very large downloads but
    autocli archives are ~10MB; the simplicity of a single bytes object wins.
    """
    req = urllib.request.Request(url, headers={"User-Agent": "mcp-autocli-setup/0.1"})
    with urllib.request.urlopen(req, timeout=60) as resp:  # noqa: S310 - upstream URL is constant
        return resp.read()


def _find_autocli_in_archive(extract_dir: Path) -> Path | None:
    """Recursively locate the autocli binary inside an unpacked archive.

    Upstream archive layout has shifted in the past (top-level vs nested in a
    subdir named after the target), so search instead of hard-coding the path.
    """
    binary_name = "autocli.exe" if paths.IS_WINDOWS else "autocli"
    for found in extract_dir.rglob(binary_name):
        if found.is_file():
            return found
    return None


def _bundled_autocli_bytes(target: str) -> bytes | None:
    """Return the bundled binary blob for this target, or None if not shipped.

    Current bundle: Windows x86_64, macOS arm64, macOS x86_64. The wheel keeps
    each binary as a raw file (not an archive) under
    _assets/autocli/autocli-<target>[.exe] so install is one byte copy — no
    extraction step. Linux callers still get None here and fall through to the
    GitHub download path.
    """
    name = f"autocli-{target}" + (".exe" if paths.IS_WINDOWS else "")
    try:
        asset_ref = resources.files("mcp_autocli") / "_assets" / "autocli" / name
        with resources.as_file(asset_ref) as p:
            if not p.is_file():
                return None
            return p.read_bytes()
    except (FileNotFoundError, ModuleNotFoundError):
        return None


def _write_autocli(blob: bytes) -> bool:
    """Write the binary blob to ~/.local/bin/, +x on Unix.

    The most common failure here on Windows is that the daemon (a child
    autocli process) is holding the target file open. We don't auto-kill it
    — give the user an actionable message instead.
    """
    paths.LOCAL_BIN_DIR.mkdir(parents=True, exist_ok=True)
    try:
        paths.AUTOCLI_EXE.write_bytes(blob)
    except PermissionError as e:
        _print_fail(
            f"Cannot write {paths.AUTOCLI_EXE}: {e}. "
            "If autocli daemon is running, stop it first (Task Manager / "
            "`pkill autocli`) and retry."
        )
        return False
    if not paths.IS_WINDOWS:
        paths.AUTOCLI_EXE.chmod(0o755)
    _print_ok(f"Installed to {paths.AUTOCLI_EXE} ({len(blob)//1024} KB)")
    return True


def _download_and_install_autocli(target: str, ext: str) -> bool:
    """Download autocli archive from GitHub Releases, extract, install.

    Used as the fallback path for targets we don't bundle (currently Mac/Linux).
    """
    archive_name = f"autocli-{target}.{ext}"
    url = f"{AUTOCLI_RELEASE_BASE}/{archive_name}"
    _print_info(f"Downloading {url}")

    try:
        blob = _download(url)
    except urllib.error.URLError as e:
        _print_fail(f"Download failed: {e}")
        return False
    _print_ok(f"Fetched {len(blob)//1024} KB")

    extract_dir = paths.LOCAL_BIN_DIR / f".autocli-extract-{target}"
    if extract_dir.exists():
        shutil.rmtree(extract_dir, ignore_errors=True)
    extract_dir.mkdir(parents=True, exist_ok=True)

    try:
        if ext == "zip":
            with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                zf.extractall(extract_dir)
        else:  # tar.gz
            with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tf:
                tf.extractall(extract_dir)

        found = _find_autocli_in_archive(extract_dir)
        if found is None:
            _print_fail(f"autocli binary not found inside {archive_name}")
            return False
        return _write_autocli(found.read_bytes())
    finally:
        shutil.rmtree(extract_dir, ignore_errors=True)


def _install_autocli(force: bool) -> bool:
    """Install the autocli binary to ~/.local/bin/.

    Strategy:
    - Bundled binary for this target exists (Windows / macOS) → ALWAYS treat
      the wheel as source of truth. Compare bytes against what's on disk; if
      identical, fast-skip; otherwise overwrite. This intentionally ignores
      simple file-exists idempotency because users frequently have a leftover
      `autocli` from another install path (the upstream Chrome-based fork
      from GitHub Releases, an older `brew tap`, a manual `cargo install`,
      etc.) that silently mismatches the Python wrapper's expectations.
      Letting that stale binary win produces the absolute-worst class of bug:
      the wrapper works, MCP works, search returns errors that *look* like a
      site or login problem but are actually a binary-version mismatch.
    - No bundled binary for this target (Linux today) → keep the original
      idempotent file-exists check, because the fallback is a multi-MB
      GitHub Releases download and re-running setup shouldn't pay that cost
      every time.
    - --force always reinstalls regardless of path.
    """
    _print_step("[1/5] Install autocli binary")

    try:
        target, ext = _detect_target()
    except RuntimeError as e:
        _print_fail(str(e))
        return False

    bundled = _bundled_autocli_bytes(target)

    if bundled is not None:
        # Bundle is authoritative — overwrite anything on disk that isn't
        # byte-identical, regardless of --force.
        if paths.AUTOCLI_EXE.exists() and not force:
            try:
                existing = paths.AUTOCLI_EXE.read_bytes()
            except OSError:
                existing = None
            if existing == bundled:
                _print_ok(
                    f"Bundled binary already installed at {paths.AUTOCLI_EXE} "
                    f"(byte-identical to wheel; skipping rewrite)"
                )
                return True
            _print_info(
                f"Existing autocli at {paths.AUTOCLI_EXE} differs from wheel's "
                f"bundled {target} binary; overwriting with bundle"
            )
        else:
            _print_info(f"Installing bundled binary for {target}")
        return _write_autocli(bundled)

    # No bundle for this platform — original idempotent path.
    if paths.AUTOCLI_EXE.exists() and not force:
        _print_ok(
            f"autocli already installed at {paths.AUTOCLI_EXE} "
            f"(no bundle for {target}; pass --force to redownload)"
        )
        return True

    _print_info(f"No bundled binary for {target}; falling back to GitHub download")
    return _download_and_install_autocli(target, ext)


def _parse_version_tuple(v: str) -> tuple[int, ...]:
    """Parse '1.5.7' → (1, 5, 7) for semver comparison."""
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


def _install_extension(force: bool) -> bool:
    """Extract the bundled chrome-extension zip to ~/.autocli/chrome-extension/.

    Compares the bundled extension's manifest version against the on-disk
    manifest version. Reinstalls when:
    - force=True
    - on-disk manifest.json is missing
    - on-disk version < bundled version (stale extension from an older wheel)

    This mirrors _install_autocli's "bundle is source of truth" stance:
    silently keeping a stale extension causes the worst class of bugs
    (e.g. publish draft windows auto-closing because the old extension
    has WINDOW_IDLE_TIMEOUT=30s instead of 10min).
    """
    _print_step("[2/5] Install chrome extension")

    # Read the bundled extension's manifest version from inside the zip.
    try:
        asset_ref = resources.files("mcp_autocli") / "_assets" / "chrome-extension.zip"
        with resources.as_file(asset_ref) as zip_path:
            zip_bytes = zip_path.read_bytes()
    except (FileNotFoundError, ModuleNotFoundError) as e:
        _print_fail(f"Bundled extension asset missing: {e!r}")
        return False

    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            bundled_manifest = json.loads(zf.read("manifest.json"))
            bundled_version = bundled_manifest.get("version", "0.0.0")
    except (zipfile.BadZipFile, KeyError, json.JSONDecodeError) as e:
        _print_fail(f"Bundled extension zip is corrupt or missing manifest.json: {e}")
        return False

    # Check on-disk version.
    manifest_path = paths.EXTENSION_DIR / "manifest.json"
    if manifest_path.exists() and not force:
        try:
            on_disk = json.loads(manifest_path.read_text(encoding="utf-8"))
            on_disk_version = on_disk.get("version", "0.0.0")
        except (json.JSONDecodeError, OSError):
            on_disk_version = "0.0.0"

        on_disk_v = _parse_version_tuple(on_disk_version)
        bundled_v = _parse_version_tuple(bundled_version)

        if on_disk_v >= bundled_v:
            _print_ok(
                f"Extension v{on_disk_version} already installed at "
                f"{paths.EXTENSION_DIR} (bundled v{bundled_version}; up to date)"
            )
            return True

        _print_info(
            f"On-disk extension v{on_disk_version} is older than bundled "
            f"v{bundled_version}; upgrading"
        )
    elif manifest_path.exists() and force:
        _print_info(f"--force: reinstalling extension (bundled v{bundled_version})")
    else:
        _print_info(f"Installing extension v{bundled_version}")

    # Clear any prior install so leftover files from older versions don't
    # poison the new manifest.
    if paths.EXTENSION_DIR.exists():
        shutil.rmtree(paths.EXTENSION_DIR, ignore_errors=True)
    paths.EXTENSION_DIR.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            zf.extractall(paths.EXTENSION_DIR)
    except zipfile.BadZipFile as e:
        _print_fail(f"Bundled extension zip is corrupt: {e}")
        return False

    if not (paths.EXTENSION_DIR / "manifest.json").exists():
        _print_fail(
            f"Extracted extension is missing manifest.json (extracted to {paths.EXTENSION_DIR})"
        )
        return False
    _print_ok(f"Extracted v{bundled_version} to {paths.EXTENSION_DIR}")
    return True


def _run(cmd: list[str], timeout: int = 600) -> tuple[int, str]:
    """Run cmd, return (exit_code, last-40-lines-of-combined-output).

    Used for brew/installer calls during Edge auto-install. Combined output is
    truncated so a multi-page brew trace doesn't bury the rest of setup's log.
    stdin is inherited so sudo / brew can read a password from the user's TTY
    when present; non-interactive contexts will simply time out or fail fast.
    """
    import subprocess
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return 124, f"command timed out after {timeout}s: {' '.join(cmd)}"
    except FileNotFoundError as e:
        return 127, str(e)
    out = (proc.stdout or "") + (proc.stderr or "")
    lines = out.splitlines()
    if len(lines) > 40:
        out = "\n".join(["... (output truncated to last 40 lines) ..."] + lines[-40:])
    return proc.returncode, out


def _find_brew() -> str | None:
    """Locate the brew binary even when not in the inherited PATH.

    Wukong / many MCP-host spawn contexts drop the user's interactive-shell
    PATH, so shutil.which("brew") routinely misses Homebrew installs that work
    fine in the user's own terminal. Probe the canonical install locations
    directly so we don't fall through to the pkg path unnecessarily.
    """
    candidates = [
        shutil.which("brew"),
        "/opt/homebrew/bin/brew",            # Apple Silicon default
        "/usr/local/bin/brew",               # Intel default
        str(Path.home() / "homebrew" / "bin" / "brew"),  # per-user install
    ]
    for c in candidates:
        if c and Path(c).exists():
            return c
    return None


def _install_edge_macos() -> bool:
    """Best-effort auto-install of Microsoft Edge on macOS.

    Strategy:
    1. brew install --cask microsoft-edge — preferred when brew is available
       anywhere on disk (see _find_brew). brew handles signing, /Applications
       placement, and elevates via its own GUI dialog when no TTY is present.
    2. Direct fwlink pkg + `osascript ... with administrator privileges` —
       used when brew is absent or its install fails. osascript pops the
       standard macOS auth dialog (the same one Settings.app uses), so the
       user only has to type their login password once on screen; no TTY
       required, which matters because Wukong's MCP/spawn contexts often
       don't pass one through.

    Returns True only if Edge is actually present on disk at the end. The
    installer skill that drives this script uses the return value to decide
    whether setup as a whole succeeded — printing [FAIL] when Edge is the
    last thing missing, so the caller (e.g. a Wukong installer agent) can
    retry or escalate to the user instead of silently leaving login platforms
    broken.
    """
    brew = _find_brew()
    if brew:
        _print_info(f"Installing Microsoft Edge via Homebrew ({brew}); takes a few minutes")
        code, out = _run([brew, "install", "--cask", "microsoft-edge"], timeout=900)
        if code == 0 and paths.edge_executable() is not None:
            _print_ok(f"Edge installed via brew at {paths.edge_executable()}")
            return True
        _print_warn(
            f"brew install failed (exit {code}). Output:\n{out}\n"
            "Falling back to direct pkg download."
        )

    _print_info(f"Downloading Edge pkg from {EDGE_MAC_PKG_URL}")
    pkg_path = Path("/tmp/microsoft-edge-mac.pkg")
    try:
        blob = _download(EDGE_MAC_PKG_URL)
    except urllib.error.URLError as e:
        _print_fail(
            f"Edge download failed: {e}. "
            f"Install manually: download from {EDGE_MAC_PKG_URL} and double-click."
        )
        return False
    pkg_path.write_bytes(blob)
    _print_ok(f"Downloaded {len(blob)//1024//1024} MB")

    # osascript with administrator privileges invokes the macOS GUI auth
    # dialog. Works without a controlling TTY (essential under Wukong spawn);
    # the user sees a system password prompt on their screen and types once.
    _print_info("Requesting admin password via macOS dialog — look at your screen")
    osa_script = (
        f'do shell script "/usr/sbin/installer -pkg \\"{pkg_path}\\" -target /" '
        f'with administrator privileges'
    )
    code, out = _run(["osascript", "-e", osa_script], timeout=600)
    pkg_path.unlink(missing_ok=True)
    if code == 0 and paths.edge_executable() is not None:
        _print_ok(f"Edge installed via pkg at {paths.edge_executable()}")
        return True
    _print_fail(
        f"pkg installer failed (exit {code}). Output:\n{out}\n"
        f"Install manually: download from {EDGE_MAC_PKG_URL} and double-click, "
        "then re-run setup."
    )
    return False


def _install_user_adapters(force: bool) -> bool:
    """Deploy bundled YAML adapter overrides to ~/.autocli/adapters/.

    These overrides patch known issues in the upstream builtin adapters
    (douyin missing cookie/scroll, bilibili subtitle's brittle cid path,
    xiaohongshu's missing xsec_token arg + DOM-vs-INITIAL_STATE selector
    rot). autocli loads them at startup and they win over the embedded
    builtins via Registry.insert (same site+name overwrites).

    Strategy:
    - Wheel's _assets/user-adapters/<site>/<name>.yaml is authoritative.
      Always overwrite if differs (mirrors _install_autocli's "bundle is
      source of truth" stance — stale overrides confuse harder than a
      missing one).
    - Force-existing files outside our shipped set are left untouched —
      users may have their own adapters and we don't want to clobber them.
    """
    _print_step("[3/5] Install user adapter overrides")

    try:
        src_root_ref = resources.files("mcp_autocli") / "_assets" / "user-adapters"
        with resources.as_file(src_root_ref) as src_root:
            if not src_root.is_dir():
                _print_info("No bundled user-adapters dir; skipping")
                return True
            paths.USER_ADAPTERS_DIR.mkdir(parents=True, exist_ok=True)
            copied = 0
            unchanged = 0
            for yaml_src in src_root.rglob("*.yaml"):
                rel = yaml_src.relative_to(src_root)
                dst = paths.USER_ADAPTERS_DIR / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                src_bytes = yaml_src.read_bytes()
                if dst.exists() and not force:
                    try:
                        if dst.read_bytes() == src_bytes:
                            unchanged += 1
                            continue
                    except OSError:
                        pass
                dst.write_bytes(src_bytes)
                copied += 1
            _print_ok(
                f"User adapters: {copied} written, {unchanged} unchanged "
                f"(target {paths.USER_ADAPTERS_DIR})"
            )
            return True
    except (FileNotFoundError, ModuleNotFoundError) as e:
        _print_warn(f"Bundled user-adapters resource missing: {e!r}")
        return True  # Not fatal — autocli will fall back to builtins


def _ensure_ytdlp_ffmpeg() -> bool:
    """Best-effort install of yt-dlp + ffmpeg, both needed for download_media.

    yt-dlp: autocli's bilibili download adapter spawns it; mcp's download_media
    also falls back to it for some platforms.
    ffmpeg: yt-dlp uses it to merge DASH audio + video tracks; the keyframe
    pipeline downstream of understand_media may want it later.

    Both are installed via `pip install --user` (no brew dependency), and the
    user-bin location is symlinked into ~/.local/bin so autocli's PATH lookup
    finds them. If pip itself is missing we just warn — installer skill caller
    can recover.
    """
    _print_step("[4/5] Ensure yt-dlp + ffmpeg in PATH")

    import subprocess

    py = sys.executable

    def _pip_install(pkg: str) -> bool:
        try:
            proc = subprocess.run(
                [py, "-m", "pip", "install", "--user", "--quiet", "--upgrade", pkg],
                capture_output=True, text=True, timeout=180,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as e:
            _print_warn(f"pip install {pkg} failed to run: {e}")
            return False
        if proc.returncode != 0:
            _print_warn(
                f"pip install {pkg} exit {proc.returncode}; output:\n"
                + (proc.stderr or proc.stdout or "")[-400:]
            )
            return False
        return True

    # yt-dlp
    if shutil.which("yt-dlp") is None:
        _print_info("Installing yt-dlp via pip --user")
        if not _pip_install("yt-dlp"):
            _print_warn("yt-dlp install failed; download_media may fail on platforms that need it")
        else:
            _print_ok("yt-dlp installed")
    else:
        _print_ok(f"yt-dlp already on PATH ({shutil.which('yt-dlp')})")

    # ffmpeg via imageio-ffmpeg, then symlink into ~/.local/bin
    if shutil.which("ffmpeg") is None:
        _print_info("Installing imageio-ffmpeg (ffmpeg binary)")
        if _pip_install("imageio-ffmpeg"):
            try:
                # imageio_ffmpeg.get_ffmpeg_exe() returns the bundled binary path.
                proc = subprocess.run(
                    [py, "-c", "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"],
                    capture_output=True, text=True, timeout=10,
                )
                ffmpeg_path = (proc.stdout or "").strip()
                if ffmpeg_path and Path(ffmpeg_path).exists():
                    paths.LOCAL_BIN_DIR.mkdir(parents=True, exist_ok=True)
                    link = paths.LOCAL_BIN_DIR / "ffmpeg"
                    try:
                        if link.exists() or link.is_symlink():
                            link.unlink()
                        link.symlink_to(ffmpeg_path)
                        _print_ok(f"Symlinked ffmpeg -> {ffmpeg_path}")
                    except OSError as e:
                        _print_warn(f"ffmpeg symlink failed: {e}; add {Path(ffmpeg_path).parent} to PATH manually")
                else:
                    _print_warn("imageio-ffmpeg installed but get_ffmpeg_exe() returned empty")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                _print_warn(f"ffmpeg discovery failed: {e}")
        else:
            _print_warn("imageio-ffmpeg install failed; bilibili download merge will fail")
    else:
        _print_ok(f"ffmpeg already on PATH ({shutil.which('ffmpeg')})")

    return True  # never fatal — let the user re-run / install manually


def _ensure_dirs_and_edge(install_edge: bool = True) -> bool:
    """Create profile dir and verify Edge is reachable.

    On macOS, when Edge is missing AND install_edge=True (the default), try
    Homebrew first then a direct fwlink pkg fallback. Windows and Linux Edge
    installs still require manual action — winget on Windows has
    license-prompt friction in non-interactive contexts, and Linux Edge needs
    a Microsoft apt/yum repo config that's too invasive to add during setup.
    """
    _print_step("[5/5] Prepare profile + check Edge")

    paths.EDGE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    _print_ok(f"Profile dir ready at {paths.EDGE_PROFILE_DIR}")

    edge = paths.edge_executable()
    if edge is not None:
        _print_ok(f"Edge detected at {edge}")
        return True

    if paths.IS_MACOS and install_edge:
        _print_info("Microsoft Edge not found; attempting auto-install on macOS")
        return _install_edge_macos()

    _print_warn(
        "Microsoft Edge not found in standard install locations. "
        "Install from https://www.microsoft.com/edge/download before "
        "calling the launch_login MCP tool."
    )
    return True  # Not a hard failure — autocli works for no-login platforms


def run_setup(argv: list[str]) -> int:
    """Entry point for `mcp-autocli setup [args]`. Returns process exit code."""
    parser = argparse.ArgumentParser(
        prog="mcp-autocli setup",
        description=(
            "Bootstrap autocli binary + chrome extension so that the MCP "
            "server can drive Edge-based platforms out of the box."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Reinstall the autocli binary + extension even if already present.",
    )
    parser.add_argument(
        "--no-install-edge",
        action="store_true",
        help="On macOS, skip auto-installing Microsoft Edge when missing (just warn).",
    )
    args = parser.parse_args(argv)

    # All output kept ASCII-only so Windows GBK/CP936 consoles don't choke
    # on Unicode arrows / checkmarks. PowerShell/Terminal can render Unicode
    # but cmd.exe and many CI runners still default to legacy code pages.
    print("mcp-autocli setup -- bootstrapping local dependencies", flush=True)
    print(f"  autocli binary -> {paths.AUTOCLI_EXE}", flush=True)
    print(f"  extension      -> {paths.EXTENSION_DIR}", flush=True)
    print(f"  edge profile   -> {paths.EDGE_PROFILE_DIR}", flush=True)
    print("", flush=True)

    ok_bin = _install_autocli(force=args.force)
    ok_ext = _install_extension(force=args.force)
    ok_adapters = _install_user_adapters(force=args.force)
    ok_deps = _ensure_ytdlp_ffmpeg()
    ok_env = _ensure_dirs_and_edge(install_edge=not args.no_install_edge)

    print("", flush=True)
    if ok_bin and ok_ext and ok_adapters and ok_deps and ok_env:
        print("[OK] Setup complete.", flush=True)
        print("", flush=True)
        print("Next steps:", flush=True)
        print("  1. Register `mcp-autocli` in your MCP host's config", flush=True)
        print("     (Claude Code / Wukong / Cursor / Cline all use stdio).", flush=True)
        print("  2. On first use of a login-required platform, the host's", flush=True)
        print("     agent will call `launch_login` to spawn Edge -- log in once.", flush=True)
        return 0

    print("[FAIL] Setup finished with errors. See [FAIL] lines above.", file=sys.stderr, flush=True)
    return 1


def main() -> None:
    """Standalone entry point — only used if someone wires `mcp-autocli-setup`
    as a separate console script. The normal path is `mcp-autocli setup ...`
    routed through server.main().
    """
    sys.exit(run_setup(sys.argv[1:]))


if __name__ == "__main__":
    main()
