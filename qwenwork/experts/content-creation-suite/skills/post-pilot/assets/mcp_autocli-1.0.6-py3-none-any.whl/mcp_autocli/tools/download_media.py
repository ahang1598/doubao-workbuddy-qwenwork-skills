"""`download_media` tool — fetch the actual video/image files of a post.

Why this exists separate from autocli's own `<platform> download` command:
autocli's builtin `download:` pipeline step has two modes — single-URL via
yt-dlp (works for bilibili), and batch via `items: <key>` for arrays of mixed
media (xiaohongshu/douyin overlays use this). The batch path in autocli 0.3.8
returns `download_status: pending` without actually fetching anything. Rather
than wait for that to be fixed upstream, this tool ignores autocli's download
step entirely and does the HTTP fetch in Python:

  1. spawn `autocli <platform> download <id> [...]` — but only care about
     `evaluate`'s output (media[] with signed CDN URLs + metadata).
  2. urllib.request the URL list with the platform's required Referer header.
     Signed URLs already carry their own auth (signaturev3 for douyin,
     sign/t for xhs, no cookie required).
  3. Write files to output_dir with sequence-numbered names; return the
     final paths so the caller can feed them into understand_media or
     write a content-breakdown report.

Platforms covered today:
- xiaohongshu: needs note-id + xsec-token (parsed from URL by caller).
- douyin: needs aweme-id only.
- bilibili: delegated to autocli's own download (yt-dlp path actually works
  end-to-end for this platform, including ffmpeg merge), so we DON'T re-fetch
  — we just locate the produced .mp4.
- weixin: special case — autocli evaluate returns the article body already
  rendered to Markdown (not a video/image URL list). We write the .md plus
  embedded images out and surface both in files[].

Output schema (one dict, not a list — different shape from search):
    {
      "platform": str,
      "output_dir": str,
      "files":  [{"type": "video"|"image", "path": str, "size_bytes": int, "url": str}],
      "metadata": {"title": str, "author": str, ...platform-specific...},
      "skip_reason": str | None,    # set when nothing was downloaded
      "elapsed_seconds": float
    }
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from ..lib.autocli_runner import AutocliNotFoundError, run_autocli_json


SUPPORTED_PLATFORMS: list[str] = [
    "xiaohongshu", "douyin", "bilibili", "weixin", "taobao",
    "twitter", "youtube", "instagram", "tiktok", "facebook", "reddit",
]

# Platforms whose download path is yt-dlp (no autocli adapter).
_YTDLP_PLATFORMS: set[str] = {"youtube", "instagram", "tiktok", "facebook", "reddit"}

# In-memory registry: tracks output_dir → file paths for every successful
# download_media call. cleanup_download reads and drains this.
_download_registry: dict[str, list[str]] = {}

DOWNLOAD_TIMEOUT_SECONDS = 180  # autocli evaluate phase only; fetch phase has its own
FETCH_PER_URL_TIMEOUT_SECONDS = 120

# Each CDN strictly checks Referer to block hot-linking. User-Agent is also
# checked on some endpoints (douyinvod refuses Python's default UA).
_PLATFORM_HEADERS: dict[str, dict[str, str]] = {
    "xiaohongshu": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://www.xiaohongshu.com/",
    },
    "douyin": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://www.douyin.com/",
    },
    "bilibili": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://www.bilibili.com/",
    },
    "twitter": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://x.com/",
    },
    "weixin": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://mp.weixin.qq.com/",
    },
    "taobao": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://detail.tmall.com/",
    },
}

# SSL context lazily created — some CDNs serve certs the system store
# distrusts (China-region CAs); we still verify by default but allow a
# fallback when verification fails on the same host twice in a row.
_SSL_CTX = ssl.create_default_context()


def _ext_for(item_type: str, url: str) -> str:
    """Pick a file extension. URL extension wins when obvious, type fallback otherwise."""
    lower = url.lower().split("?", 1)[0]
    for known in (".mp4", ".m4a", ".webp", ".jpg", ".jpeg", ".png", ".gif", ".webm", ".mov"):
        if lower.endswith(known):
            return known
    return ".mp4" if item_type == "video" else ".webp" if item_type == "image" else ".bin"


def _safe_basename(s: str, max_len: int = 60) -> str:
    """Strip filesystem-hostile characters from a title for use in filenames."""
    keep = []
    for ch in s.strip():
        if ch.isalnum() or ch in " -_.":
            keep.append(ch)
        else:
            keep.append("_")
    base = "".join(keep).strip(" _.")
    return base[:max_len] or "media"


async def _fetch_url(url: str, headers: dict[str, str], dest: Path) -> tuple[bool, int, str | None]:
    """Download one URL to dest. Returns (ok, size_bytes, error_msg)."""
    def _blocking() -> tuple[bool, int, str | None]:
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=FETCH_PER_URL_TIMEOUT_SECONDS, context=_SSL_CTX) as resp:  # noqa: S310
                total = 0
                with open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(64 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)
                        total += len(chunk)
                return True, total, None
        except urllib.error.HTTPError as e:
            return False, 0, f"http_{e.code}"
        except urllib.error.URLError as e:
            return False, 0, f"url_error: {e.reason!r}"
        except (TimeoutError, OSError) as e:
            return False, 0, f"io_error: {e!r}"

    return await asyncio.to_thread(_blocking)


async def _autocli_evaluate(
    platform: str, post_id: str, xsec_token: str = "", quality: str = "best"
) -> tuple[dict | None, str | None]:
    """Spawn autocli to get the evaluate step's JSON output. Returns (data, skip_reason)."""
    args: list[str]
    if platform == "xiaohongshu":
        args = ["xiaohongshu", "download", post_id]
        if xsec_token:
            args.extend(["--xsec-token", xsec_token])
        # autocli writes pending status into the JSON we don't care about,
        # but it still wants a valid output dir for its (broken) download step.
        args.extend(["--output", "/tmp/_mcp_autocli_unused"])
    elif platform == "douyin":
        args = ["douyin", "download", post_id, "--output", "/tmp/_mcp_autocli_unused"]
    elif platform == "weixin":
        # weixin post_id is the full https://mp.weixin.qq.com/s/<slug> URL
        args = ["weixin", "download", post_id, "--output", "/tmp/_mcp_autocli_unused"]
    elif platform == "bilibili":
        # bilibili's builtin download actually works end-to-end via yt-dlp;
        # we let it write to a real output dir and harvest its .mp4 afterwards.
        # The caller has already passed the desired output_dir; we forward it.
        args = ["bilibili", "download", post_id, "--quality", quality]
        # output appended later by caller via separate path
    elif platform == "taobao":
        # post_id 可以是纯数字 item-id 或完整 URL，自动提取
        taobao_id = post_id
        url_match = re.search(r'[?&]id=(\d+)', post_id)
        if url_match:
            taobao_id = url_match.group(1)
        args = ["taobao", "download", taobao_id, "--output", "/tmp/_mcp_autocli_unused"]
    else:
        return None, "unsupported_platform_for_download_media"

    try:
        parsed, raw = await run_autocli_json(args, timeout=DOWNLOAD_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"autocli_spawn_error: {e!r}"

    if parsed is None:
        # autocli printed something unparseable; surface the last 200 chars
        tail = (raw.stdout or raw.stderr or "")[-200:]
        return None, f"autocli_no_json: {tail!r}"
    return parsed, None


def _extract_media_list(platform: str, parsed: Any) -> tuple[list[dict], dict[str, Any]]:
    """Pull (media, metadata) out of autocli's evaluate output.

    Shape differs by platform:
    - xhs / douyin: dict with 'media': [{type, url}, ...] + flat metadata fields.
    - weixin: dict with 'imageUrls': [url, ...] + 'content' (rendered markdown).
    - bilibili: caller doesn't use this path (yt-dlp produces files directly).
    """
    if platform in ("xiaohongshu", "douyin", "taobao"):
        if not isinstance(parsed, dict):
            return [], {}
        media = parsed.get("media") or []
        # extracted_via=='none' means evaluate fell through all three strategies
        # (page didn't render / captcha / etc). Surface that in metadata so
        # the caller can decide to skip the post.
        meta = {
            "title": parsed.get("title", ""),
            "author": parsed.get("author", ""),
            "extracted_via": parsed.get("extracted_via", ""),
            "note_type": parsed.get("note_type"),
            "duration_ms": parsed.get("duration_ms"),
            "statistics": parsed.get("statistics"),
            "subtitle_infos": parsed.get("subtitle_infos"),
            "debug": parsed.get("debug"),
        }
        meta = {k: v for k, v in meta.items() if v not in (None, "", [], {})}
        return media, meta

    if platform == "weixin":
        if not isinstance(parsed, dict):
            return [], {}
        image_urls = parsed.get("imageUrls") or []
        media = [{"type": "image", "url": u} for u in image_urls if u]
        meta = {
            "title": parsed.get("title", ""),
            "author": parsed.get("author", ""),
            "filename": parsed.get("filename", ""),
            # content here is the full article rendered to markdown by the
            # adapter's evaluate step — caller will write this to a .md file.
            "content_markdown": parsed.get("content", ""),
            "publish_time": parsed.get("publishTime"),
        }
        meta = {k: v for k, v in meta.items() if v not in (None, "", [], {})}
        return media, meta

    # bilibili: yt-dlp produced one or more file entries with .path / .size / .title.
    # We don't re-fetch — we treat them as already-downloaded files.
    return [], {}


_VIDEO_EXTS = {".mp4", ".webm", ".mov", ".mkv", ".flv", ".m4v", ".avi"}
_AUDIO_EXTS = {".m4a", ".mp3", ".aac", ".ogg", ".opus", ".wav", ".wma", ".flac"}
_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}


def _ytdlp_download(url: str, output_dir: Path) -> tuple[bool, str]:
    """Download media via yt-dlp. Returns (success, error_msg).

    Uses temp-file redirection instead of PIPE — on Windows, yt-dlp may
    spawn child processes that inherit the pipe handles, preventing EOF
    and causing communicate() to hang forever (same issue as autocli daemon).
    """
    ytdlp = shutil.which("yt-dlp")
    if not ytdlp:
        return False, "yt-dlp_not_installed"

    import subprocess as _sp
    import tempfile as _tf

    out_fd, out_path = _tf.mkstemp(prefix="ytdlp_out_", suffix=".txt")
    err_fd, err_path = _tf.mkstemp(prefix="ytdlp_err_", suffix=".txt")
    try:
        creation_flags = 0x08000000 if sys.platform == "win32" else 0  # CREATE_NO_WINDOW
        with os.fdopen(out_fd, "wb") as out_f, os.fdopen(err_fd, "wb") as err_f:
            proc = _sp.Popen(
                [ytdlp,
                 "-o", str(output_dir / "%(title).60s.%(ext)s"),
                 "--no-playlist", "--restrict-filenames", url],
                stdin=_sp.DEVNULL,
                stdout=out_f,
                stderr=err_f,
                creationflags=creation_flags,
            )
            try:
                rc = proc.wait(timeout=DOWNLOAD_TIMEOUT_SECONDS)
            except _sp.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
                return False, "yt-dlp_timeout"

        if rc != 0:
            if any(output_dir.iterdir()):
                return True, ""
            stderr_text = Path(err_path).read_text(errors="replace")
            stdout_text = Path(out_path).read_text(errors="replace")
            tail = (stderr_text + stdout_text)[-300:]
            return False, f"yt-dlp_exit_{rc}: {tail}"
        return True, ""
    except OSError as e:
        return False, f"yt-dlp_spawn_failed: {e!r}"
    finally:
        Path(out_path).unlink(missing_ok=True)
        Path(err_path).unlink(missing_ok=True)


def _scan_output_dir(output_dir: Path) -> list[dict]:
    """Scan directory for media files, return file info dicts."""
    files: list[dict] = []
    for p in sorted(output_dir.rglob("*")):
        if not p.is_file():
            continue
        suffix = p.suffix.lower()
        if suffix in _VIDEO_EXTS:
            ftype = "video"
        elif suffix in _AUDIO_EXTS:
            ftype = "audio"
        elif suffix in _IMAGE_EXTS:
            ftype = "image"
        else:
            ftype = "media"
        files.append({
            "type": ftype,
            "path": str(p),
            "size_bytes": p.stat().st_size,
            "url": None,
        })
    return files


def _register_download(output_dir: str, files: list[dict]) -> None:
    """Record a successful download so cleanup_download can find it later."""
    _download_registry[output_dir] = [
        f["path"] for f in files if f.get("path")
    ]


def cleanup_download() -> dict[str, Any]:
    """Delete ALL files created by prior download_media calls in this session."""
    if not _download_registry:
        return {"cleaned_dirs": [], "removed_files": 0, "status": "nothing_to_clean"}
    cleaned_dirs: list[str] = []
    total_removed = 0
    for output_dir, file_paths in list(_download_registry.items()):
        for p in file_paths:
            try:
                Path(p).unlink(missing_ok=True)
                total_removed += 1
            except OSError:
                pass
        out = Path(output_dir)
        if out.exists():
            try:
                for child in sorted(out.rglob("*"), reverse=True):
                    if child.is_file():
                        child.unlink(missing_ok=True)
                        total_removed += 1
                    elif child.is_dir():
                        child.rmdir()
                out.rmdir()
            except OSError:
                pass
        cleaned_dirs.append(output_dir)
        del _download_registry[output_dir]
    return {"cleaned_dirs": cleaned_dirs, "removed_files": total_removed, "status": "cleaned"}


async def download_media(
    platform: str,
    post_id: str,
    output_dir: str,
    xsec_token: str = "",
    quality: str = "best",
) -> dict[str, Any]:
    """Download a post's media to local files.

    Args:
        platform: One of SUPPORTED_PLATFORMS.
        post_id: Platform-native identifier (xhs note-id / douyin aweme-id /
                 bilibili bvid).
        output_dir: Directory where files will be written. Created if missing.
        xsec_token: Required for xiaohongshu newer notes; empty otherwise.
        quality: bilibili only — best / 1080p / 720p / 480p.

    Returns:
        Output schema documented at module docstring.
    """
    platform = (platform or "").strip()
    post_id = (post_id or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if not post_id:
        raise ValueError("post_id must be non-empty")

    # 淘宝: 支持传入完整 URL，自动提取 item-id
    if platform == "taobao" and not post_id.isdigit():
        url_match = re.search(r'[?&]id=(\d+)', post_id)
        if url_match:
            post_id = url_match.group(1)

    if platform not in SUPPORTED_PLATFORMS:
        return {
            "platform": platform,
            "output_dir": output_dir,
            "files": [],
            "metadata": {},
            "skip_reason": "unsupported_platform_for_download_media",
            "elapsed_seconds": 0.0,
        }

    out = Path(output_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()

    # Bilibili path: let autocli + yt-dlp do the actual download.
    if platform == "bilibili":
        args = ["bilibili", "download", post_id, "--quality", quality, "--output", str(out)]
        try:
            parsed, raw = await run_autocli_json(args, timeout=DOWNLOAD_TIMEOUT_SECONDS)
        except AutocliNotFoundError:
            raise
        except Exception as e:  # noqa: BLE001
            return {
                "platform": platform,
                "output_dir": str(out),
                "files": [],
                "metadata": {},
                "skip_reason": f"autocli_spawn_error: {e!r}",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }

        # autocli + yt-dlp produce separate video/audio streams (no ffmpeg
        # merge needed — keyframes use video, transcription uses audio).
        # Scan the output dir for whatever was actually downloaded.
        title = ""
        if isinstance(parsed, list):
            for entry in parsed:
                if isinstance(entry, dict):
                    title = title or (entry.get("title") or "")
        files = _scan_output_dir(out)
        if files:
            _register_download(str(out), files)
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": files,
            "metadata": {"title": title} if title else {},
            "skip_reason": None if files else "bilibili_download_produced_no_files",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # Twitter path: autocli's download pipeline handles the full flow
    # (navigate → extract media URLs → download). post_id is a tweet URL
    # or a username; we detect by prefix.
    if platform == "twitter":
        if post_id.startswith("http"):
            args = ["twitter", "download", "--tweet-url", post_id, "--output", str(out)]
        else:
            args = ["twitter", "download", post_id, "--output", str(out)]
        try:
            parsed, raw = await run_autocli_json(args, timeout=DOWNLOAD_TIMEOUT_SECONDS)
        except AutocliNotFoundError:
            raise
        except Exception as e:  # noqa: BLE001
            return {
                "platform": platform,
                "output_dir": str(out),
                "files": [],
                "metadata": {},
                "skip_reason": f"autocli_spawn_error: {e!r}",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }

        files = _scan_output_dir(out)
        if files:
            _register_download(str(out), files)
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": files,
            "metadata": {},
            "skip_reason": None if files else "twitter_download_produced_no_files",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # yt-dlp path: youtube / instagram / tiktok / facebook / reddit.
    # post_id is the full URL. For youtube, also accept bare video ID.
    if platform in _YTDLP_PLATFORMS:
        url = post_id
        if platform == "youtube" and not url.startswith("http"):
            url = f"https://www.youtube.com/watch?v={url}"
        ok, err = await asyncio.to_thread(_ytdlp_download, url, out)
        if not ok:
            return {
                "platform": platform,
                "output_dir": str(out),
                "files": [],
                "metadata": {},
                "skip_reason": err,
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        files = _scan_output_dir(out)
        if files:
            _register_download(str(out), files)
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": files,
            "metadata": {},
            "skip_reason": None if files else f"{platform}_download_produced_no_files",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # weixin path: write the rendered markdown to a .md and download referenced
    # images alongside. Article body is the primary deliverable, images are bonus.
    if platform == "weixin":
        parsed, reason = await _autocli_evaluate(platform, post_id)
        if parsed is None:
            return {
                "platform": platform,
                "output_dir": str(out),
                "files": [],
                "metadata": {},
                "skip_reason": reason,
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        media, metadata = _extract_media_list(platform, parsed)
        files: list[dict] = []

        md_filename = metadata.get("filename") or f"{_safe_basename(metadata.get('title') or 'article')}.md"
        md_path = out / md_filename
        md_body = metadata.get("content_markdown") or ""
        if md_body:
            try:
                md_path.write_text(md_body, encoding="utf-8")
                files.append({
                    "type": "article_markdown",
                    "path": str(md_path),
                    "size_bytes": md_path.stat().st_size,
                    "url": post_id,
                })
            except OSError as e:
                return {
                    "platform": platform,
                    "output_dir": str(out),
                    "files": [],
                    "metadata": metadata,
                    "skip_reason": f"markdown_write_failed: {e!r}",
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                }
        else:
            return {
                "platform": platform,
                "output_dir": str(out),
                "files": [],
                "metadata": metadata,
                "skip_reason": "no_article_content (evaluate returned empty content)",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }

        # Fetch embedded images (best effort; .md is the primary deliverable)
        headers = _PLATFORM_HEADERS["weixin"]
        sem = asyncio.Semaphore(4)
        img_dir = out / f"{_safe_basename(metadata.get('title') or 'article')}_images"
        img_dir.mkdir(parents=True, exist_ok=True)

        async def _one_img(idx: int, item: dict) -> dict:
            url = item.get("url", "")
            ext = _ext_for(item.get("type", "image"), url)
            dest = img_dir / f"image_{idx:03d}{ext}"
            async with sem:
                ok, size, err = await _fetch_url(url, headers, dest)
            return {
                "type": "image",
                "path": str(dest) if ok else None,
                "size_bytes": size,
                "url": url,
                "error": err,
            }

        if media:
            img_results = await asyncio.gather(*[_one_img(i, m) for i, m in enumerate(media)])
            files.extend(r for r in img_results if r["path"])
            img_failures = [r["error"] for r in img_results if r.get("error")]
            skip_reason = None
            if img_failures:
                skip_reason = f"{len(img_failures)}/{len(media)} images failed: {img_failures[:3]}"
        else:
            skip_reason = None

        if files:
            _register_download(str(out), files)
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": files,
            "metadata": metadata,
            "skip_reason": skip_reason,
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # xhs / douyin path: evaluate only, then Python fetch with Referer.
    parsed, reason = await _autocli_evaluate(platform, post_id, xsec_token=xsec_token, quality=quality)
    if parsed is None:
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": [],
            "metadata": {},
            "skip_reason": reason,
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    media, metadata = _extract_media_list(platform, parsed)
    if not media:
        # Most likely cause: extracted_via == 'none' (page didn't render /
        # captcha). The full debug dict is in metadata['debug'].
        return {
            "platform": platform,
            "output_dir": str(out),
            "files": [],
            "metadata": metadata,
            "skip_reason": "no_media_extracted (see metadata.debug)",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    headers = _PLATFORM_HEADERS.get(platform, {})
    base = _safe_basename(metadata.get("title") or post_id)

    # Download all media in parallel; cap to keep CDN happy
    sem = asyncio.Semaphore(4)

    async def _one(idx: int, item: dict) -> dict:
        url = item.get("url", "")
        item_type = item.get("type", "media")
        ext = _ext_for(item_type, url)
        fname = f"{post_id}_{idx:03d}{ext}"
        dest = out / fname
        async with sem:
            ok, size, err = await _fetch_url(url, headers, dest)
        return {
            "type": item_type,
            "path": str(dest) if ok else None,
            "size_bytes": size,
            "url": url,
            "error": err,
        }

    results = await asyncio.gather(*[_one(i, m) for i, m in enumerate(media)])
    files = [r for r in results if r["path"]]

    skip_reason = None
    if not files:
        # All URLs failed — keep error detail per-URL in files anyway? No:
        # caller wants a clean files list. Surface the first error as reason.
        first_err = next((r["error"] for r in results if r.get("error")), "all_fetches_failed")
        skip_reason = f"all_fetches_failed: {first_err}"
    elif len(files) < len(media):
        # Partial — still report skip_reason so caller knows not everything came back
        partial_errs = [r["error"] for r in results if r.get("error")]
        skip_reason = f"partial_fetch: {len(files)}/{len(media)} ok; errors={partial_errs[:3]}"

    if files:
        _register_download(str(out), files)
    return {
        "platform": platform,
        "output_dir": str(out),
        "files": files,
        "metadata": metadata,
        "skip_reason": skip_reason,
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }


async def download_taobao_cart(
    output_dir: str,
    limit: int = 50,
    concurrency: int = 2,
) -> dict[str, Any]:
    """Batch-download videos from all items in the user's Taobao cart.

    Flow:
      1. `autocli taobao cart --limit N` → extract cart item list
      2. For each item, call `download_media(platform="taobao", post_id=item_id)`
      3. Aggregate results

    Args:
        output_dir: Root directory for downloads. Each item gets a subdirectory.
        limit: Max cart items to process.
        concurrency: Max parallel downloads (keep low to avoid anti-bot).

    Returns:
        {
          "total_items": int,
          "downloaded": int,
          "skipped": int,
          "items": [{item_id, title, status, files, skip_reason}, ...],
          "output_dir": str,
          "elapsed_seconds": float,
        }
    """
    started = time.monotonic()
    out = Path(output_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)

    # Step 1: Extract cart item list
    cart_args = ["taobao", "cart", "--limit", str(limit)]
    try:
        parsed, raw = await run_autocli_json(cart_args, timeout=DOWNLOAD_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as exc:
        return {
            "total_items": 0,
            "downloaded": 0,
            "skipped": 0,
            "items": [],
            "output_dir": str(out),
            "skip_reason": f"cart_extraction_failed: {exc!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    if not isinstance(parsed, list) or not parsed:
        return {
            "total_items": 0,
            "downloaded": 0,
            "skipped": 0,
            "items": [],
            "output_dir": str(out),
            "skip_reason": "empty_cart",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # Filter out debug/empty entries
    cart_items = [
        item for item in parsed
        if isinstance(item, dict) and item.get("item_id")
    ]

    if not cart_items:
        return {
            "total_items": 0,
            "downloaded": 0,
            "skipped": 0,
            "items": [],
            "output_dir": str(out),
            "skip_reason": "no_valid_items_in_cart",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    # Step 2: Download each item's video sequentially with limited concurrency
    semaphore = asyncio.Semaphore(concurrency)
    results: list[dict[str, Any]] = []

    async def _download_one(item: dict) -> dict[str, Any]:
        item_id = item["item_id"]
        title = item.get("title", "")
        item_dir = str(out / item_id)

        async with semaphore:
            try:
                result = await download_media(
                    platform="taobao",
                    post_id=item_id,
                    output_dir=item_dir,
                )
                return {
                    "item_id": item_id,
                    "title": title,
                    "status": "downloaded" if result.get("files") else "no_video",
                    "files": result.get("files", []),
                    "skip_reason": result.get("skip_reason"),
                    "elapsed_seconds": result.get("elapsed_seconds", 0),
                }
            except Exception as exc:
                return {
                    "item_id": item_id,
                    "title": title,
                    "status": "error",
                    "files": [],
                    "skip_reason": f"download_error: {exc!r}",
                    "elapsed_seconds": 0,
                }

    results = await asyncio.gather(*[_download_one(item) for item in cart_items])

    downloaded_count = sum(1 for r in results if r["status"] == "downloaded")
    skipped_count = len(results) - downloaded_count

    return {
        "total_items": len(cart_items),
        "downloaded": downloaded_count,
        "skipped": skipped_count,
        "items": results,
        "output_dir": str(out),
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
