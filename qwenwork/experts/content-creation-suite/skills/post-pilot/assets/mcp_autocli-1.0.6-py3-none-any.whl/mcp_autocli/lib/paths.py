"""Fixed filesystem paths shared by all MCP tools.

Mirrors the layout established by the original content-radar skill's setup.sh /
setup.ps1: autocli binary at ~/.local/bin/autocli[.exe], dedicated Edge profile
at ~/.autocli/edge-profile, browser extension at ~/.autocli/chrome-extension.
"""
from __future__ import annotations

import sys
from pathlib import Path


IS_WINDOWS = sys.platform == "win32"
IS_MACOS = sys.platform == "darwin"

HOME = Path.home()

AUTOCLI_DIR = HOME / ".autocli"
EDGE_PROFILE_DIR = AUTOCLI_DIR / "edge-profile"
EXTENSION_DIR = AUTOCLI_DIR / "chrome-extension"

# autocli scans this directory at startup and loads any *.yaml/*.yml as user
# adapters; entries with the same (site, name) as a builtin override it. We
# ship maintained fixes for douyin/bilibili/xiaohongshu here so users don't
# need to keep autocli's Rust source in sync.
USER_ADAPTERS_DIR = AUTOCLI_DIR / "adapters"

LOCAL_BIN_DIR = HOME / ".local" / "bin"
AUTOCLI_EXE = LOCAL_BIN_DIR / ("autocli.exe" if IS_WINDOWS else "autocli")


def edge_executable() -> Path | None:
    """Locate Microsoft Edge executable on Windows or macOS.

    Returns None when Edge is not installed in any known location.
    """
    if IS_WINDOWS:
        candidates = [
            Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
            HOME / "AppData/Local/Microsoft/Edge/Application/msedge.exe",
        ]
    elif IS_MACOS:
        candidates = [
            Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
        ]
    else:
        candidates = []

    for p in candidates:
        if p.exists():
            return p
    return None


def cookies_db_path() -> Path | None:
    """Locate the Cookies SQLite file inside the dedicated Edge profile.

    Chromium 91+ moved Cookies to Default/Network/Cookies; older builds keep it
    in Default/Cookies. Return whichever exists, or None if neither does (e.g.
    Edge has never been started in this profile yet).
    """
    for rel in ("Default/Network/Cookies", "Default/Cookies"):
        p = EDGE_PROFILE_DIR / rel
        if p.exists():
            return p
    return None
