"""Spawn the autocli binary safely from inside an MCP server.

Two non-obvious constraints drive the design here:

1. autocli spawns a long-lived daemon on first run. On Windows, CreateProcess
   inherits handles by default — if we attach autocli's stdout to a pipe
   (subprocess.PIPE), the daemon child inherits that pipe's write end, so the
   pipe never reaches EOF after autocli exits. Naive `subprocess.run(...,
   capture_output=True)` would hang forever. Workaround: redirect stdout/stderr
   to real files (NamedTemporaryFile) — file handles get duplicated cleanly
   and EOF semantics work normally.

2. This module runs inside an MCP stdio server. The server itself communicates
   with the host over its own stdout. If autocli inherits our stdout fd it
   would corrupt the JSON-RPC frames. Explicit file redirection prevents that
   too.

The public entrypoint is `run_autocli_json`, which is async — internally it
delegates to `asyncio.to_thread` so the blocking subprocess call does not
freeze the event loop.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import paths


class AutocliNotFoundError(RuntimeError):
    """Raised when the autocli binary is missing from the fixed install path."""


@dataclass
class AutocliResult:
    """Raw outcome of an autocli invocation, before JSON parsing."""
    stdout: str
    stderr: str
    returncode: int | None  # None on timeout
    timed_out: bool = False

    @property
    def combined(self) -> str:
        return (self.stdout or "") + (self.stderr or "")


def _resolve_exe() -> Path:
    exe = paths.AUTOCLI_EXE
    if not exe.exists():
        raise AutocliNotFoundError(
            f"autocli binary not found at {exe}. "
            f"Run the content-radar setup script first "
            f"(bash setup.sh on macOS/Linux, setup.ps1 on Windows)."
        )
    return exe


def _run_blocking(args: list[str], timeout: int) -> AutocliResult:
    exe = _resolve_exe()

    # Real files (not PIPE) — see module docstring point 1.
    out_fd, out_path = tempfile.mkstemp(prefix="autocli_out_", suffix=".txt")
    err_fd, err_path = tempfile.mkstemp(prefix="autocli_err_", suffix=".txt")
    try:
        creation_flags = 0
        if paths.IS_WINDOWS:
            # CREATE_NO_WINDOW: don't pop a console window for the autocli
            # daemon. DETACHED_PROCESS is incompatible with redirected stdio
            # — using just CREATE_NO_WINDOW is enough.
            creation_flags = 0x08000000  # CREATE_NO_WINDOW

        with os.fdopen(out_fd, "wb") as out_f, os.fdopen(err_fd, "wb") as err_f:
            try:
                proc = subprocess.Popen(
                    [str(exe), *args],
                    stdin=subprocess.DEVNULL,
                    stdout=out_f,
                    stderr=err_f,
                    creationflags=creation_flags,
                )
            except OSError as e:
                return AutocliResult(stdout="", stderr=f"spawn failed: {e}", returncode=-1)

            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                try:
                    proc.kill()
                except OSError:
                    pass
                proc.wait(timeout=5)
                return AutocliResult(
                    stdout=_read_text(out_path),
                    stderr=_read_text(err_path) + f"\nTIMEOUT after {timeout}s",
                    returncode=None,
                    timed_out=True,
                )

        return AutocliResult(
            stdout=_read_text(out_path),
            stderr=_read_text(err_path),
            returncode=rc,
        )
    finally:
        try:
            Path(out_path).unlink(missing_ok=True)
            Path(err_path).unlink(missing_ok=True)
        except OSError:
            pass


def _read_text(path: str) -> str:
    try:
        with open(path, "rb") as f:
            return f.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


async def run_autocli(args: list[str], timeout: int = 60) -> AutocliResult:
    """Run autocli with the given argv tail (e.g. ['bilibili', 'search', 'AI'])."""
    return await asyncio.to_thread(_run_blocking, args, timeout)


async def run_autocli_json(args: list[str], timeout: int = 60) -> tuple[Any, AutocliResult]:
    """Run autocli with --format json appended, parse stdout as JSON.

    Returns (parsed, raw). parsed is None when stdout was empty or unparseable
    — caller inspects `raw` for diagnostics.
    """
    full_args = [*args, "--format", "json"]
    raw = await run_autocli(full_args, timeout=timeout)
    if not raw.stdout.strip():
        return None, raw
    try:
        return json.loads(raw.stdout), raw
    except json.JSONDecodeError:
        # autocli sometimes prints log lines before the JSON body. Try to
        # extract the first JSON value heuristically.
        text = raw.stdout
        for start in range(len(text)):
            ch = text[start]
            if ch in ("{", "["):
                try:
                    return json.loads(text[start:]), raw
                except json.JSONDecodeError:
                    continue
        return None, raw


async def doctor() -> AutocliResult:
    """Run `autocli doctor` to check autocli + extension health."""
    return await run_autocli(["doctor"], timeout=30)


async def version() -> str | None:
    raw = await run_autocli(["--version"], timeout=15)
    for line in (raw.stdout or "").splitlines():
        line = line.strip()
        if line.startswith("autocli "):
            return line
    return None
