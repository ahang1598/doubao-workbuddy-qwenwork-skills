"""`account_dashboard` tool — fan out across multiple autocli subcommands to
build a single "this is my own account, here's the state" picture for one
platform. Designed for content-radar's "what have I been doing and how is it
performing" lane, which `search` / `hot` / `user_timeline` don't cover.

Per-platform composition:
- xiaohongshu: creator-profile (acct stats) + creator-stats (period trends)
- bilibili:    me (acct stats) + favorite (saved list) + history (watched)
- twitter:     profile (acct stats) + bookmarks (saved tweets)

All sub-calls run in parallel. Each sub-call is recorded in `sections[]`
with its own `skip_reason` so partial failures don't kill the whole call —
e.g. xhs creator endpoints require creator center login which the user may
not have done; the bilibili half stays intact.

Output schema:
    {
      "platform": str,
      "sections": {
        "<section_name>": {
          "ok":  bool,
          "data": <list[dict] | dict>,           # raw autocli json on success
          "skip_reason": str | None,
        },
        ...
      },
      "elapsed_seconds": float
    }

Notes on autocli quirks:
- xhs creator-profile / creator-stats / creator-notes-summary all run against
  creator.xiaohongshu.com (different subdomain from the main site), and need
  the logged-in user to have a Creator Center account.
- bilibili me, favorite, history all need a SESSDATA cookie (the same one
  download/subtitle use).
"""
from __future__ import annotations

import time
from typing import Any

from ..lib.autocli_runner import AutocliNotFoundError, run_autocli_json


# Per-platform spec: each entry is a section name + the autocli argv tail.
# Adding a new platform = add a new top-level dict entry.
_PLATFORM_SECTIONS: dict[str, dict[str, list[str]]] = {
    "xiaohongshu": {
        "creator_profile":       ["xiaohongshu", "creator-profile"],
        "creator_stats":         ["xiaohongshu", "creator-stats", "--period", "seven"],
    },
    "bilibili": {
        "me":       ["bilibili", "me"],
        "favorite": ["bilibili", "favorite", "--limit", "20"],
        "history":  ["bilibili", "history", "--limit", "20"],
    },
    "twitter": {
        "profile":   ["twitter", "profile"],
        "bookmarks": ["twitter", "bookmarks", "--limit", "20"],
    },
}

SUPPORTED_PLATFORMS: list[str] = list(_PLATFORM_SECTIONS.keys())

SECTION_TIMEOUT_SECONDS = 60


async def _run_section(name: str, args: list[str]) -> dict[str, Any]:
    """Run one autocli subcommand. Returns the section dict for the response."""
    try:
        parsed, raw = await run_autocli_json(args, timeout=SECTION_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "data": None, "skip_reason": f"autocli_spawn_error: {e!r}"}

    if parsed is None:
        tail = (raw.stdout or raw.stderr or "")[-200:]
        return {"ok": False, "data": None, "skip_reason": f"no_json_output: {tail!r}"}

    # autocli returns either a list (rows) or a dict (single-record). Both
    # are valid; just surface them. The agent can pick fields on its side.
    if isinstance(parsed, list) and len(parsed) == 0:
        return {"ok": False, "data": [], "skip_reason": "empty_result"}
    if isinstance(parsed, dict) and not parsed:
        return {"ok": False, "data": {}, "skip_reason": "empty_result"}

    return {"ok": True, "data": parsed, "skip_reason": None}


async def account_dashboard(platform: str) -> dict[str, Any]:
    """Run the platform's dashboard fan-out concurrently.

    Args:
        platform: One of SUPPORTED_PLATFORMS.

    Returns:
        See module docstring.
    """
    platform = (platform or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if platform not in SUPPORTED_PLATFORMS:
        return {
            "platform": platform,
            "sections": {},
            "skip_reason": f"unsupported_platform (only {SUPPORTED_PLATFORMS})",
            "elapsed_seconds": 0.0,
        }

    started = time.monotonic()
    spec = _PLATFORM_SECTIONS[platform]

    # Run sections serially — concurrent autocli calls fight over the
    # browser daemon and cause "Failed to fetch" / stale-DOM errors.
    sections: dict[str, Any] = {}
    for name, args in spec.items():
        sections[name] = await _run_section(name, args)

    return {
        "platform": platform,
        "sections": sections,
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
