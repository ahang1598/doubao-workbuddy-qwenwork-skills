"""Normalize per-platform autocli search results to a uniform item shape.

autocli returns platform-native JSON: bilibili uses `bvid`, xiaohongshu uses
`note_id`, hackernews uses `objectID`. URL construction varies (some platforms
return full URLs, others only IDs). Engagement metrics live under different
field names: `views` / `score` / `play` / `likes` / `reactions_count`.

This module exposes one function — `normalize(platform_key, raw_json)` — that
returns a list of `NormalizedItem` dicts. The shape is intentionally narrow:
the seven fields the Wukong agent actually consumes (title, url, author,
duration_seconds, views, likes, thumbnail_url, publish_time), plus `raw` for
escape-hatch access to platform-specific fields.

Per-platform normalizers are intentionally tolerant: each tries several common
field-name variants before giving up. If autocli's upstream schema shifts, the
worst case is `None` in a field rather than a crash.
"""
from __future__ import annotations

from typing import Any, Iterable, TypedDict


class NormalizedItem(TypedDict, total=False):
    platform: str
    title: str
    url: str
    author: str | None
    duration_seconds: int | None
    views: int | None
    likes: int | None
    thumbnail_url: str | None
    publish_time: str | None
    raw: dict[str, Any]


# ---- helpers ----

def _first(d: dict[str, Any], *keys: str) -> Any:
    """Return the first value in d for any of the given keys, or None."""
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return None


def _to_int(v: Any) -> int | None:
    """Parse engagement counts that may arrive as int, str, or '1.2万'/'3.5K'."""
    if v is None:
        return None
    if isinstance(v, bool):
        return None  # bool is a subclass of int in Python — exclude it
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).strip().replace(",", "")
    if not s:
        return None
    # Chinese-style suffixes
    suffix_map_cn = {"万": 10_000, "亿": 100_000_000, "千": 1_000}
    for suf, mul in suffix_map_cn.items():
        if s.endswith(suf):
            try:
                return int(float(s[:-1]) * mul)
            except ValueError:
                return None
    # English-style suffixes
    suffix_map_en = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}
    for suf, mul in suffix_map_en.items():
        if s.upper().endswith(suf):
            try:
                return int(float(s[:-1]) * mul)
            except ValueError:
                return None
    try:
        return int(float(s))
    except ValueError:
        return None


def _iter_items(raw: Any) -> Iterable[dict[str, Any]]:
    """autocli sometimes returns a bare list, sometimes a {data: [...]} wrapper.

    Yield only dict elements so per-platform normalizers can assume dict input.
    """
    if raw is None:
        return
    if isinstance(raw, list):
        for x in raw:
            if isinstance(x, dict):
                yield x
        return
    if isinstance(raw, dict):
        for key in ("items", "data", "results", "hits", "videos", "list"):
            v = raw.get(key)
            if isinstance(v, list):
                for x in v:
                    if isinstance(x, dict):
                        yield x
                return
        # Fallback: a single dict treated as one item
        yield raw


def _author_from_dict(v: Any) -> str | None:
    """An `author` / `user` field may be a string or a nested {name: ...}."""
    if v is None:
        return None
    if isinstance(v, str):
        return v or None
    if isinstance(v, dict):
        return _first(v, "name", "nickname", "screen_name", "username", "display_name")
    return None


# ---- per-platform normalizers ----

def _norm_bilibili(d: dict[str, Any]) -> NormalizedItem:
    bvid = _first(d, "bvid", "id")
    url = _first(d, "url", "short_link")
    if not url and bvid:
        url = f"https://www.bilibili.com/video/{bvid}"
    title = _first(d, "title", "name") or ""
    if not url and title:
        from urllib.parse import quote
        url = f"https://search.bilibili.com/all?keyword={quote(title)}"
    return {
        "title": title,
        "url": url or "",
        "author": _author_from_dict(_first(d, "author", "owner", "uploader", "up_name")),
        "duration_seconds": _to_int(_first(d, "duration", "length", "duration_seconds")),
        "views": _to_int(_first(d, "play", "view", "views", "score")),
        "likes": _to_int(_first(d, "like", "likes", "good")),
        "thumbnail_url": _first(d, "pic", "cover", "thumbnail", "thumbnail_url"),
        "publish_time": _first(d, "pubdate", "publish_time", "ctime", "created"),
    }


def _norm_xiaohongshu(d: dict[str, Any]) -> NormalizedItem:
    nid = _first(d, "note_id", "id", "noteId")
    url = _first(d, "url", "share_url")
    if not url and nid:
        url = f"https://www.xiaohongshu.com/explore/{nid}"
    return {
        "title": _first(d, "title", "display_title", "desc") or "",
        "url": url or "",
        "author": _author_from_dict(_first(d, "user", "author", "nickname")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "view_count", "views")),
        "likes": _to_int(_first(d, "liked_count", "likes", "like_count")),
        "thumbnail_url": _first(d, "cover", "cover_url", "thumbnail"),
        "publish_time": _first(d, "time", "publish_time", "created_at"),
    }


def _norm_douyin(d: dict[str, Any]) -> NormalizedItem:
    aid = _first(d, "aweme_id", "video_id", "id")
    url = _first(d, "url", "share_url")
    if not url and aid:
        url = f"https://www.douyin.com/video/{aid}"
    return {
        "title": _first(d, "title", "desc", "content") or "",
        "url": url or "",
        "author": _author_from_dict(_first(d, "author", "user", "nickname")),
        "duration_seconds": _to_int(_first(d, "duration")),
        "views": _to_int(_first(d, "play_count", "plays", "views")),
        "likes": _to_int(_first(d, "digg_count", "likes", "like_count")),
        "thumbnail_url": _first(d, "cover", "thumbnail"),
        "publish_time": _first(d, "create_time", "publish_time"),
    }


def _norm_weibo(d: dict[str, Any]) -> NormalizedItem:
    mid = _first(d, "mid", "id", "bid")
    user = _first(d, "user", "author")
    user_name = _author_from_dict(user)
    user_id = None
    if isinstance(user, dict):
        user_id = _first(user, "id", "uid", "screen_name")
    url = _first(d, "url", "link")
    if not url and mid:
        url = f"https://weibo.com/{user_id}/{mid}" if user_id else f"https://m.weibo.cn/status/{mid}"
    return {
        "title": _first(d, "text", "title", "content") or "",
        "url": url or "",
        "author": user_name,
        "duration_seconds": None,
        "views": _to_int(_first(d, "attitudes_count", "view_count", "hot_value")),
        "likes": _to_int(_first(d, "attitudes_count", "likes")),
        "thumbnail_url": _first(d, "pic", "thumbnail"),
        "publish_time": _first(d, "created_at", "publish_time"),
    }


def _norm_twitter(d: dict[str, Any]) -> NormalizedItem:
    tid = _first(d, "id", "tweet_id", "id_str")
    user = _first(d, "user", "author")
    user_name = _author_from_dict(user)
    screen = None
    if isinstance(user, dict):
        screen = _first(user, "screen_name", "username", "handle")
    url = _first(d, "url", "tweet_url")
    if not url and tid and screen:
        url = f"https://x.com/{screen}/status/{tid}"
    title = _first(d, "text", "full_text", "content", "topic", "word") or ""
    if not url and title:
        from urllib.parse import quote
        url = f"https://x.com/search?q={quote(title)}"
    return {
        "title": title,
        "url": url or "",
        "author": user_name or screen,
        "duration_seconds": None,
        "views": _to_int(_first(d, "view_count", "views", "impression_count", "tweets")),
        "likes": _to_int(_first(d, "favorite_count", "likes", "like_count")),
        "thumbnail_url": None,
        "publish_time": _first(d, "created_at", "publish_time"),
    }


def _norm_youtube(d: dict[str, Any]) -> NormalizedItem:
    vid = _first(d, "video_id", "videoId", "id")
    url = _first(d, "url", "video_url")
    if not url and vid:
        url = f"https://www.youtube.com/watch?v={vid}"
    return {
        "title": _first(d, "title") or "",
        "url": url or "",
        "author": _author_from_dict(_first(d, "channel", "author", "uploader")),
        "duration_seconds": _to_int(_first(d, "duration", "duration_seconds", "length_seconds")),
        "views": _to_int(_first(d, "view_count", "views")),
        "likes": _to_int(_first(d, "like_count", "likes")),
        "thumbnail_url": _first(d, "thumbnail", "thumbnail_url"),
        "publish_time": _first(d, "publish_time", "published", "upload_date"),
    }


def _norm_hackernews(d: dict[str, Any]) -> NormalizedItem:
    hid = _first(d, "id", "objectID", "story_id")
    url = _first(d, "url")
    hn_url = f"https://news.ycombinator.com/item?id={hid}" if hid else ""
    return {
        "title": _first(d, "title", "story_title") or "",
        "url": url or hn_url,
        "author": _first(d, "by", "author"),
        "duration_seconds": None,
        "views": None,
        "likes": _to_int(_first(d, "score", "points")),
        "thumbnail_url": None,
        "publish_time": _first(d, "time", "created_at"),
    }


def _norm_lobsters(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title") or "",
        "url": _first(d, "url", "comments_url", "short_id_url") or "",
        "author": _author_from_dict(_first(d, "submitter_user", "user", "author")),
        "duration_seconds": None,
        "views": None,
        "likes": _to_int(_first(d, "score", "upvotes")),
        "thumbnail_url": None,
        "publish_time": _first(d, "created_at", "publish_time"),
    }


def _norm_devto(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title") or "",
        "url": _first(d, "url", "canonical_url") or "",
        "author": _author_from_dict(_first(d, "user", "author")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "page_views_count", "views")),
        "likes": _to_int(_first(d, "public_reactions_count", "reactions", "reactions_count", "positive_reactions_count")),
        "thumbnail_url": _first(d, "cover_image", "social_image"),
        "publish_time": _first(d, "published_at", "created_at"),
    }


def _norm_stackoverflow(d: dict[str, Any]) -> NormalizedItem:
    qid = _first(d, "question_id", "id")
    url = _first(d, "link", "url")
    if not url and qid:
        url = f"https://stackoverflow.com/q/{qid}"
    return {
        "title": _first(d, "title") or "",
        "url": url or "",
        "author": _author_from_dict(_first(d, "owner", "author")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "view_count", "views")),
        "likes": _to_int(_first(d, "score", "votes")),
        "thumbnail_url": None,
        "publish_time": _first(d, "creation_date", "publish_time"),
    }


def _norm_arxiv(d: dict[str, Any]) -> NormalizedItem:
    aid = _first(d, "id", "arxiv_id", "entry_id")
    url = _first(d, "url", "link", "abs_url")
    if not url and aid:
        # aid might be a bare "2401.12345" or a full URL — handle both.
        url = aid if str(aid).startswith("http") else f"https://arxiv.org/abs/{aid}"
    authors = _first(d, "authors", "author")
    if isinstance(authors, list):
        author = ", ".join(_author_from_dict(a) or "" for a in authors if a)
    else:
        author = _author_from_dict(authors)
    return {
        "title": _first(d, "title") or "",
        "url": url or "",
        "author": author or None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "published", "publish_time", "updated"),
    }


def _norm_hf(d: dict[str, Any]) -> NormalizedItem:
    pid = _first(d, "id", "paper_id")
    url = _first(d, "url")
    if not url and pid:
        url = f"https://huggingface.co/papers/{pid}"
    return {
        "title": _first(d, "title", "name") or "",
        "url": url or "",
        "author": _author_from_dict(_first(d, "author", "submitted_by")),
        "duration_seconds": None,
        "views": None,
        "likes": _to_int(_first(d, "upvotes", "likes")),
        "thumbnail_url": _first(d, "thumbnail"),
        "publish_time": _first(d, "published_at", "submitted_at"),
    }


def _norm_wikipedia(d: dict[str, Any]) -> NormalizedItem:
    title = _first(d, "title") or ""
    url = _first(d, "url", "fullurl")
    if not url and title:
        url = f"https://en.wikipedia.org/wiki/{title.replace(' ', '_')}"
    return {
        "title": title,
        "url": url or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "thumbnail"),
        "publish_time": _first(d, "timestamp"),
    }


def _norm_reddit(d: dict[str, Any]) -> NormalizedItem:
    url = _first(d, "url", "permalink", "link")
    if url and not url.startswith("http"):
        url = f"https://www.reddit.com{url}"
    return {
        "title": _first(d, "title", "name") or "",
        "url": url or "",
        "author": _first(d, "author", "user"),
        "duration_seconds": None,
        "views": _to_int(_first(d, "score", "ups")),
        "likes": _to_int(_first(d, "score", "ups", "upvotes")),
        "thumbnail_url": _first(d, "thumbnail") if _first(d, "thumbnail", "") not in ("self", "default", "nsfw", "spoiler", "") else None,
        "publish_time": _first(d, "created_utc", "created_at", "publish_time"),
    }


def _norm_facebook(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "text", "content", "name") or "",
        "url": _first(d, "url", "link", "permalink") or "",
        "author": _author_from_dict(_first(d, "author", "user", "from")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "views", "view_count")),
        "likes": _to_int(_first(d, "reactions_count", "likes", "like_count", "reactions")),
        "thumbnail_url": _first(d, "image", "thumbnail", "cover"),
        "publish_time": _first(d, "created_at", "publish_time", "date", "time"),
    }


def _norm_instagram(d: dict[str, Any]) -> NormalizedItem:
    username = _first(d, "username", "user", "handle")
    url = _first(d, "url", "profile_url")
    if not url and username:
        url = f"https://www.instagram.com/{username}/"
    return {
        "title": _first(d, "full_name", "name", "title", "caption") or "",
        "url": url or "",
        "author": username,
        "duration_seconds": None,
        "views": _to_int(_first(d, "followers", "follower_count", "views")),
        "likes": _to_int(_first(d, "likes", "like_count")),
        "thumbnail_url": _first(d, "profile_pic_url", "thumbnail", "cover"),
        "publish_time": _first(d, "created_at", "publish_time"),
    }


def _norm_linkedin(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name", "headline", "text") or "",
        "url": _first(d, "url", "link", "profile_url") or "",
        "author": _author_from_dict(_first(d, "author", "user", "poster")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "views", "view_count")),
        "likes": _to_int(_first(d, "likes", "reactions", "reactions_count")),
        "thumbnail_url": _first(d, "image", "thumbnail"),
        "publish_time": _first(d, "published_at", "created_at", "date"),
    }


def _norm_medium(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name") or "",
        "url": _first(d, "url", "link", "postUrl") or "",
        "author": _first(d, "author", "creator", "user"),
        "duration_seconds": None,
        "views": _to_int(_first(d, "views", "reads", "readingTime")),
        "likes": _to_int(_first(d, "claps", "likes", "recommends")),
        "thumbnail_url": _first(d, "image", "thumbnail", "previewImage"),
        "publish_time": _first(d, "date", "published_at", "firstPublishedAt", "createdAt"),
    }


def _norm_substack(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name") or "",
        "url": _first(d, "url", "link", "canonical_url") or "",
        "author": _author_from_dict(_first(d, "author", "publishedBylines", "user")),
        "duration_seconds": None,
        "views": _to_int(_first(d, "views", "view_count")),
        "likes": _to_int(_first(d, "likes", "reactions", "reaction_count")),
        "thumbnail_url": _first(d, "cover_image", "thumbnail", "social_image"),
        "publish_time": _first(d, "date", "post_date", "published_at", "created_at"),
    }


def _norm_tiktok(d: dict[str, Any]) -> NormalizedItem:
    aid = _first(d, "id", "aweme_id", "video_id")
    url = _first(d, "url", "share_url")
    if not url and aid:
        url = f"https://www.tiktok.com/@/video/{aid}"
    author = _first(d, "author", "uniqueId", "user")
    if isinstance(author, dict):
        author = _first(author, "uniqueId", "nickname", "username")
    return {
        "title": _first(d, "desc", "title", "content") or "",
        "url": url or "",
        "author": author,
        "duration_seconds": _to_int(_first(d, "duration")),
        "views": _to_int(_first(d, "plays", "playCount", "play_count", "views")),
        "likes": _to_int(_first(d, "likes", "diggCount", "digg_count", "like_count")),
        "thumbnail_url": _first(d, "cover", "thumbnail"),
        "publish_time": _first(d, "createTime", "create_time", "publish_time"),
    }


def _norm_discord(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "content", "title", "text", "message") or "",
        "url": _first(d, "url", "link", "jump_url") or "",
        "author": _author_from_dict(_first(d, "author", "user")),
        "duration_seconds": None,
        "views": None,
        "likes": _to_int(_first(d, "reactions", "reaction_count")),
        "thumbnail_url": None,
        "publish_time": _first(d, "timestamp", "created_at"),
    }


def _norm_coupang(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name", "productName") or "",
        "url": _first(d, "url", "link", "productUrl") or "",
        "author": _first(d, "brand", "seller", "vendor"),
        "duration_seconds": None,
        "views": _to_int(_first(d, "review_count", "reviewCount", "reviews")),
        "likes": _to_int(_first(d, "rating", "score", "stars")),
        "thumbnail_url": _first(d, "image", "thumbnail", "productImage"),
        "publish_time": None,
    }


def _norm_reuters(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "headline") or "",
        "url": _first(d, "url", "link", "canonical_url") or "",
        "author": _author_from_dict(_first(d, "author", "byline", "authors")),
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "thumbnail", "image", "thumbnail_url"),
        "publish_time": _first(d, "published_at", "date", "published_time", "dateModified"),
    }


def _norm_google(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name") or "",
        "url": _first(d, "url", "link") or "",
        "author": _first(d, "source", "displayLink", "site"),
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "thumbnail", "image"),
        "publish_time": _first(d, "date", "published", "snippet_date"),
    }


def _norm_steam(d: dict[str, Any]) -> NormalizedItem:
    appid = _first(d, "id", "appid", "app_id")
    url = _first(d, "url", "link")
    if not url and appid:
        url = f"https://store.steampowered.com/app/{appid}"
    return {
        "title": _first(d, "name", "title") or "",
        "url": url or "",
        "author": _first(d, "developer", "publisher"),
        "duration_seconds": None,
        "views": _to_int(_first(d, "reviews", "review_count")),
        "likes": _to_int(_first(d, "rating", "score", "positive")),
        "thumbnail_url": _first(d, "header_image", "capsule_image", "thumbnail"),
        "publish_time": _first(d, "release_date", "published"),
    }


def _norm_bbc(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "headline") or "",
        "url": _first(d, "url", "link") or "",
        "author": _first(d, "author", "contributor"),
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "thumbnail", "image"),
        "publish_time": _first(d, "pubDate", "published", "date", "isoDate"),
    }


def _norm_bloomberg(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "headline") or "",
        "url": _first(d, "url", "link") or "",
        "author": _author_from_dict(_first(d, "author", "byline", "authors")),
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "thumbnail", "image", "ledeImage"),
        "publish_time": _first(d, "pubDate", "published_at", "date", "publishedAt"),
    }


def _norm_apple_podcasts(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "trackName", "title", "collectionName", "name") or "",
        "url": _first(d, "trackViewUrl", "url", "collectionViewUrl") or "",
        "author": _first(d, "artistName", "author", "artist"),
        "duration_seconds": _to_int(_first(d, "trackTimeMillis")),
        "views": None,
        "likes": _to_int(_first(d, "trackCount", "rating")),
        "thumbnail_url": _first(d, "artworkUrl100", "artworkUrl600", "artworkUrl60", "thumbnail"),
        "publish_time": _first(d, "releaseDate", "publishDate", "date"),
    }


def _norm_barchart(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "symbol", "name", "title") or "",
        "url": _first(d, "url", "link") or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "date", "tradeTime"),
    }


def _norm_yahoo_finance(d: dict[str, Any]) -> NormalizedItem:
    symbol = _first(d, "symbol", "ticker")
    url = _first(d, "url", "link")
    if not url and symbol:
        url = f"https://finance.yahoo.com/quote/{symbol}"
    return {
        "title": _first(d, "shortName", "longName", "name", "title") or "",
        "url": url or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "date", "earningsTimestamp"),
    }


def _norm_notion(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name", "text") or "",
        "url": _first(d, "url", "link") or "",
        "author": _author_from_dict(_first(d, "author", "created_by", "last_edited_by")),
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": _first(d, "icon", "cover", "thumbnail"),
        "publish_time": _first(d, "created_time", "last_edited_time"),
    }


def _norm_chatgpt(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "name", "text") or "",
        "url": _first(d, "url", "link") or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "create_time", "created_at"),
    }


def _norm_grok(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "text", "content") or "",
        "url": _first(d, "url", "link") or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": None,
    }


def _norm_cursor(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "text", "content") or "",
        "url": _first(d, "url", "link") or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "created_at", "timestamp"),
    }


def _norm_codex(d: dict[str, Any]) -> NormalizedItem:
    return {
        "title": _first(d, "title", "text", "content") or "",
        "url": _first(d, "url", "link") or "",
        "author": None,
        "duration_seconds": None,
        "views": None,
        "likes": None,
        "thumbnail_url": None,
        "publish_time": _first(d, "created_at", "timestamp"),
    }


_NORMALIZERS = {
    "bilibili":       _norm_bilibili,
    "xiaohongshu":    _norm_xiaohongshu,
    "douyin":         _norm_douyin,
    "weibo":          _norm_weibo,
    "twitter":        _norm_twitter,
    "youtube":        _norm_youtube,
    "hackernews":     _norm_hackernews,
    "lobsters":       _norm_lobsters,
    "devto":          _norm_devto,
    "stackoverflow":  _norm_stackoverflow,
    "arxiv":          _norm_arxiv,
    "hf":             _norm_hf,
    "wikipedia":      _norm_wikipedia,
    "reddit":         _norm_reddit,
    "facebook":       _norm_facebook,
    "instagram":      _norm_instagram,
    "linkedin":       _norm_linkedin,
    "medium":         _norm_medium,
    "substack":       _norm_substack,
    "tiktok":         _norm_tiktok,
    "discord-app":    _norm_discord,
    "coupang":        _norm_coupang,
    "reuters":        _norm_reuters,
    "google":         _norm_google,
    "steam":          _norm_steam,
    "bbc":            _norm_bbc,
    "bloomberg":      _norm_bloomberg,
    "apple-podcasts": _norm_apple_podcasts,
    "barchart":       _norm_barchart,
    "yahoo-finance":  _norm_yahoo_finance,
    "notion":         _norm_notion,
    "chatgpt":        _norm_chatgpt,
    "grok":           _norm_grok,
    "cursor":         _norm_cursor,
    "codex":          _norm_codex,
}


def normalize(platform_key: str, raw_json: Any) -> list[NormalizedItem]:
    """Convert raw autocli JSON into a list of NormalizedItem dicts.

    Unknown platforms yield items with just `{platform, title, url, raw}` —
    callers still get something usable instead of a crash. Items without a
    URL are dropped (a URL-less search result is useless to the Wukong agent).
    """
    norm_fn = _NORMALIZERS.get(platform_key)
    out: list[NormalizedItem] = []
    for d in _iter_items(raw_json):
        if norm_fn is not None:
            item = norm_fn(d)
        else:
            item = {
                "title": _first(d, "title", "name", "text") or "",
                "url": _first(d, "url", "link") or "",
                "author": None,
                "duration_seconds": None,
                "views": None,
                "likes": None,
                "thumbnail_url": None,
                "publish_time": None,
            }
        if not item.get("url"):
            continue  # drop URL-less items
        item["platform"] = platform_key
        item["raw"] = d
        out.append(item)
    return out


# ---- post-detail normalization ----

class NormalizedComment(TypedDict, total=False):
    author: str | None
    text: str
    likes: int | None
    publish_time: str | None
    raw: dict[str, Any]


class NormalizedDetail(TypedDict, total=False):
    platform: str
    url: str
    title: str
    content: str
    author: str | None
    views: int | None
    likes: int | None
    comments_count: int | None
    comments: list[NormalizedComment]
    publish_time: str | None
    raw: Any


def _normalize_comment_dict(d: dict[str, Any]) -> NormalizedComment:
    """Best-effort flatten of a single comment dict across platforms."""
    user = _first(d, "user", "author")
    return {
        "author": _author_from_dict(user) or _first(d, "author_name", "username"),
        "text": _first(d, "text", "content", "body", "message") or "",
        "likes": _to_int(_first(d, "like_count", "likes", "favorite_count", "score")),
        "publish_time": _first(d, "publish_time", "created_at", "time"),
        "raw": d,
    }


def _iter_comments(raw: Any) -> list[dict[str, Any]]:
    """Find a comment list inside a detail payload, looking under common keys."""
    if isinstance(raw, list):
        return [c for c in raw if isinstance(c, dict)]
    if not isinstance(raw, dict):
        return []
    # Direct list under a known key
    for key in ("comments", "replies", "comment_list", "items", "data"):
        v = raw.get(key)
        if isinstance(v, list):
            return [c for c in v if isinstance(c, dict)]
    # Nested under "data" / "result"
    for key in ("data", "result", "detail"):
        sub = raw.get(key)
        if isinstance(sub, dict):
            for sub_key in ("comments", "replies", "comment_list"):
                v = sub.get(sub_key)
                if isinstance(v, list):
                    return [c for c in v if isinstance(c, dict)]
    return []


def _norm_detail_xiaohongshu(raw: Any) -> NormalizedDetail:
    """xhs creator-note-detail returns one note + engagement + audience stats."""
    d = raw if isinstance(raw, dict) else {}
    inner = d.get("data") if isinstance(d.get("data"), dict) else d
    return {
        "url": _first(inner, "url", "share_url") or "",
        "title": _first(inner, "title", "display_title", "desc") or "",
        "content": _first(inner, "desc", "content", "body") or "",
        "author": _author_from_dict(_first(inner, "user", "author")),
        "views": _to_int(_first(inner, "view_count", "views", "play_count")),
        "likes": _to_int(_first(inner, "liked_count", "likes", "like_count")),
        "comments_count": _to_int(_first(inner, "comment_count", "comments_count", "comments")),
        "comments": [_normalize_comment_dict(c) for c in _iter_comments(d)],
        "publish_time": _first(inner, "time", "publish_time", "created_at"),
    }


def _norm_detail_youtube(raw: Any) -> NormalizedDetail:
    """yt comments returns a list of comments + (optionally) video stats."""
    if isinstance(raw, list):
        return {
            "url": "",
            "title": "",
            "content": "",
            "author": None,
            "views": None,
            "likes": None,
            "comments_count": len(raw),
            "comments": [_normalize_comment_dict(c) for c in raw if isinstance(c, dict)],
            "publish_time": None,
        }
    d = raw if isinstance(raw, dict) else {}
    video = d.get("video") if isinstance(d.get("video"), dict) else {}
    return {
        "url": _first(video, "url", "video_url") or _first(d, "url") or "",
        "title": _first(video, "title") or _first(d, "title") or "",
        "content": _first(video, "description") or "",
        "author": _author_from_dict(_first(video, "channel", "author") or _first(d, "channel")),
        "views": _to_int(_first(video, "view_count", "views")),
        "likes": _to_int(_first(video, "like_count", "likes")),
        "comments_count": _to_int(_first(d, "total", "comments_count")),
        "comments": [_normalize_comment_dict(c) for c in _iter_comments(d)],
        "publish_time": _first(video, "publish_time", "published"),
    }


def _norm_detail_twitter(raw: Any) -> NormalizedDetail:
    """twitter thread returns original tweet + replies array."""
    d = raw if isinstance(raw, dict) else {}
    orig = d.get("original") if isinstance(d.get("original"), dict) else d
    user = _first(orig, "user", "author")
    return {
        "url": _first(orig, "url", "tweet_url") or "",
        "title": (_first(orig, "text", "full_text", "content") or "")[:120],
        "content": _first(orig, "text", "full_text", "content") or "",
        "author": _author_from_dict(user),
        "views": _to_int(_first(orig, "view_count", "views", "impression_count")),
        "likes": _to_int(_first(orig, "favorite_count", "likes", "like_count")),
        "comments_count": _to_int(_first(d, "reply_count", "reply_total")),
        "comments": [
            _normalize_comment_dict({
                "user": _first(r, "user", "author"),
                "text": _first(r, "text", "full_text") or "",
                "like_count": _first(r, "favorite_count", "likes"),
                "created_at": _first(r, "created_at"),
            })
            for r in (d.get("replies") or [])
            if isinstance(r, dict)
        ],
        "publish_time": _first(orig, "created_at"),
    }


def _norm_detail_zhihu(raw: Any) -> NormalizedDetail:
    """zhihu question returns the question header + a list of top answers.

    Adapter output (as of autocli 0.3.8) ships rows of [rank, author, votes,
    content] — we map each row into the comments[] shape so downstream tools
    that count comments / mine for sentiment treat answers consistently.
    Question metadata (title / view count) is preserved in raw.
    """
    if isinstance(raw, list):
        # Bare answers list (no question header)
        answers = [r for r in raw if isinstance(r, dict)]
        return {
            "url": "",
            "title": "",
            "content": "",
            "author": None,
            "views": None,
            "likes": None,
            "comments_count": len(answers),
            "comments": [
                _normalize_comment_dict({
                    "author": _first(a, "author", "user_name"),
                    "text": _first(a, "content", "text") or "",
                    "like_count": _first(a, "votes", "vote_count", "likes"),
                })
                for a in answers
            ],
            "publish_time": None,
        }
    d = raw if isinstance(raw, dict) else {}
    inner = d.get("question") if isinstance(d.get("question"), dict) else d
    answers = d.get("answers") or _iter_comments(d) or []
    return {
        "url": _first(inner, "url") or "",
        "title": _first(inner, "title", "question") or "",
        "content": _first(inner, "detail", "content", "description") or "",
        "author": _author_from_dict(_first(inner, "author", "user")),
        "views": _to_int(_first(inner, "view_count", "views")),
        "likes": _to_int(_first(inner, "follower_count", "followers")),
        "comments_count": _to_int(_first(inner, "answer_count", "answers_count")) or len(answers),
        "comments": [
            _normalize_comment_dict({
                "author": _first(a, "author", "user_name"),
                "text": _first(a, "content", "text") or "",
                "like_count": _first(a, "votes", "vote_count", "likes"),
            })
            for a in answers if isinstance(a, dict)
        ],
        "publish_time": _first(inner, "created_at", "publish_time"),
    }


def _norm_detail_douban(raw: Any) -> NormalizedDetail:
    """douban subject returns one movie/book record + (optionally) reviews."""
    d = raw if isinstance(raw, dict) else {}
    # `inner` accommodates both flat layout and nested {data: {...}} from autocli
    inner = d.get("data") if isinstance(d.get("data"), dict) else d
    reviews = _iter_comments(d) or inner.get("reviews") or []
    return {
        "url": _first(inner, "url", "subject_url") or "",
        "title": _first(inner, "title", "name") or "",
        "content": _first(inner, "summary", "intro", "description") or "",
        "author": _author_from_dict(_first(inner, "director", "directors", "author")),
        # douban uses `rating` (0-10), expose as likes for ordering parity
        "views": _to_int(_first(inner, "wish_count", "watched_count")),
        "likes": _to_int(_first(inner, "rating", "average_rating", "score")),
        "comments_count": _to_int(_first(inner, "review_count")) or len(reviews),
        "comments": [
            _normalize_comment_dict({
                "author": _first(r, "author", "user_name"),
                "text": _first(r, "content", "text", "summary") or "",
                "like_count": _first(r, "useful_count", "likes", "votes"),
                "created_at": _first(r, "created_at", "time"),
            })
            for r in reviews if isinstance(r, dict)
        ],
        "publish_time": _first(inner, "year", "release_date", "publish_date"),
    }


def _norm_detail_arxiv(raw: Any) -> NormalizedDetail:
    """arxiv paper returns one academic record; no comments concept.

    Author field handles arXiv's multi-author lists by joining names.
    """
    d = raw if isinstance(raw, dict) else {}
    authors = d.get("authors")
    if isinstance(authors, list):
        author_str = ", ".join(
            (a.get("name") if isinstance(a, dict) else str(a))
            for a in authors[:5]
        )
        if len(authors) > 5:
            author_str += " et al."
    else:
        author_str = _author_from_dict(authors) if isinstance(authors, dict) else (str(authors) if authors else None)
    return {
        "url": _first(d, "url", "abs_url", "pdf_url") or "",
        "title": _first(d, "title") or "",
        "content": _first(d, "summary", "abstract") or "",
        "author": author_str,
        "views": None,  # arxiv has no engagement metrics
        "likes": None,
        "comments_count": 0,
        "comments": [],
        "publish_time": _first(d, "published", "updated", "publish_time"),
    }


_DETAIL_NORMALIZERS = {
    "xiaohongshu": _norm_detail_xiaohongshu,
    "youtube":     _norm_detail_youtube,
    "twitter":     _norm_detail_twitter,
    "zhihu":       _norm_detail_zhihu,
    "douban":      _norm_detail_douban,
    "arxiv":       _norm_detail_arxiv,
}


def normalize_detail(platform_key: str, url: str, raw_json: Any) -> NormalizedDetail:
    """Convert raw autocli post-detail JSON into a uniform NormalizedDetail.

    Unknown platforms get a thin shell: caller's `url` echoed back, raw payload
    preserved for escape-hatch access. Callers should always check
    `comments_count` / `len(comments)` before assuming any text body is present.
    """
    norm_fn = _DETAIL_NORMALIZERS.get(platform_key)
    if norm_fn is None:
        detail: NormalizedDetail = {
            "url": url,
            "title": "",
            "content": "",
            "author": None,
            "views": None,
            "likes": None,
            "comments_count": None,
            "comments": [],
            "publish_time": None,
        }
    else:
        detail = norm_fn(raw_json)
        # Caller-passed URL is the authoritative one — autocli may not echo it.
        if not detail.get("url"):
            detail["url"] = url
    detail["platform"] = platform_key
    detail["raw"] = raw_json
    return detail
