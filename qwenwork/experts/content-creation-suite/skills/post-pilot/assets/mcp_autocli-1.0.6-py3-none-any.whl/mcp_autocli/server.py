"""MCP server entry point — registers 13 tools over stdio.

Tools split into five families:
- discovery: search / hot          (keyword or trending board, 35 platforms)
- account-scoped: user_timeline / following_feed / post_detail /
                  account_dashboard / account_notifications
- session: launch_login            (opens the dedicated Edge login window;
  login confirmation is owned by the agent / skill, not the MCP layer)
- media:   download_media / get_subtitle / transcribe_audio / extract_keyframes
  (fetch actual mp4/images/subtitles for a post, ASR when there are no
   captions, and pluck stills at meaningful timestamps — pairs with
   understand_media for content breakdown reports)

The server is intentionally thin: it validates input against the tool schema,
calls the right async function, and serializes the result as a single
TextContent JSON blob. All business logic lives in tools/ and lib/.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from . import __version__
from .lib import platform_defs
from .lib.autocli_runner import AutocliNotFoundError
from .tools.account_dashboard import (
    SUPPORTED_PLATFORMS as DASHBOARD_PLATFORMS,
    account_dashboard,
)
from .tools.account_notifications import (
    SUPPORTED_PLATFORMS as NOTIFICATIONS_PLATFORMS,
    _PLATFORM_VALID_TYPES as NOTIFICATIONS_TYPES,
    account_notifications,
)
from .tools.download_media import (
    SUPPORTED_PLATFORMS as DOWNLOAD_PLATFORMS,
    cleanup_download,
    download_media,
    download_taobao_cart,
)
from .tools.extract_keyframes import extract_keyframes
from .tools.following_feed import (
    SUPPORTED_PLATFORMS as FEED_PLATFORMS,
    following_feed,
)
from .tools.get_subtitle import (
    SUPPORTED_PLATFORMS as SUBTITLE_PLATFORMS,
    get_subtitle,
)
from .tools.hot import SUPPORTED_PLATFORMS as HOT_PLATFORMS, hot
from .tools.launch_login import launch_login
from .tools.publish import (
    SUPPORTED_PLATFORMS as PUBLISH_PLATFORMS,
    SUPPORTED_MEDIA_TYPES as PUBLISH_MEDIA_TYPES,
    MAX_TITLE_CHARS as PUBLISH_MAX_TITLE,
    MAX_IMAGES as PUBLISH_MAX_IMAGES,
    publish,
)
from .tools.post_detail import (
    SUPPORTED_PLATFORMS as DETAIL_PLATFORMS,
    post_detail,
)
from .tools.search import search
from .tools.transcribe_audio import (
    SUPPORTED_ENGINES as TRANSCRIBE_ENGINES,
    transcribe_audio,
)
from .tools.user_timeline import (
    SUPPORTED_PLATFORMS as TIMELINE_PLATFORMS,
    user_timeline,
)
from .tools.platform_action import (
    ACTION_SUMMARY,
    ALL_PLATFORMS_WITH_ACTIONS,
    PLATFORM_ACTIONS,
    platform_action,
)


# Logs MUST go to stderr — stdout is the MCP JSON-RPC channel.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s mcp-autocli: %(message)s",
    stream=sys.stderr,
)
log = logging.getLogger("mcp-autocli")


server: Server = Server("mcp-autocli")


# ---- Tool registry ----

SEARCH_TOOL = Tool(
    name="search",
    description=(
        "Search content on one or more platforms by keyword. Covers 35 platforms "
        "including social (Twitter, Reddit, Facebook, Instagram, TikTok, LinkedIn, "
        "Discord), video (YouTube), content (Medium, Substack, Dev.to), tech "
        "(HackerNews, StackOverflow, Lobsters, Hugging Face), academic (arXiv, "
        "Wikipedia), news (Reuters, Google), e-commerce (Coupang), and Chinese "
        "platforms (Bilibili, Xiaohongshu, Douyin, Weibo, Zhihu). Returns a flat "
        "list of normalized items, each with platform/title/url/author/views/"
        "likes/etc. Per-platform failures are absorbed into "
        "metadata.platforms_skipped — the call only fails hard if the autocli "
        "binary itself is missing.\n\n"
        "LOGIN FLOW: the MCP layer no longer auto-probes login state — the agent "
        "owns that by calling `launch_login` for the requested login platforms "
        "and asking the user to confirm which ones they're signed into before "
        "issuing this search. Probing was removed because the daemon's output is "
        "too noisy to classify reliably (false 'login_required' on xiaohongshu / "
        "douyin / bilibili).\n\n"
        "AUTO-LAUNCH FALLBACK: when the request includes login platforms AND "
        "Microsoft Edge is not running, this tool will automatically spawn the "
        "dedicated Edge with the OpenCLI extension and open each platform's login "
        "tab BEFORE running the actual search. The metadata then carries "
        "`edge_launched: true` and `edge_launch_instruction` — relay that "
        "instruction verbatim to the user, wait for them to log in and reply "
        "(e.g. '已登录'), then re-issue the same search. Do NOT shell-probe for "
        "Chrome/Edge processes yourself; the auto-launch path already handles that.\n\n"
        "If a login platform's reason is 'login_required' (i.e. Edge was up but "
        "the user wasn't logged in), call `launch_login` for those platforms, "
        "prompt the user to log in, then retry `search`."
    ),
    inputSchema={
        "type": "object",
        "required": ["keyword"],
        "properties": {
            "keyword": {
                "type": "string",
                "minLength": 1,
                "description": "Search query string. Chinese or English; passed to autocli as-is.",
            },
            "platforms": {
                "type": "array",
                "items": {"type": "string", "enum": platform_defs.PLATFORM_KEYS},
                "description": (
                    "Optional subset of platforms to search. "
                    f"Defaults to all {len(platform_defs.PLATFORM_KEYS)} supported: {', '.join(platform_defs.PLATFORM_KEYS)}."
                ),
            },
            "limit_per_platform": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "default": 20,
                "description": "Max items per platform before merging.",
            },
        },
    },
)

LAUNCH_LOGIN_TOOL = Tool(
    name="launch_login",
    description=(
        "Open the AutoCLI dedicated Edge profile (isolated from the user's main "
        "browser) with login tabs for the given platforms. Returns immediately — "
        "does not wait for the user to log in. After calling this, the agent must "
        "tell the user to log in in the new window, then wait for confirmation "
        "before retrying `search`."
    ),
    inputSchema={
        "type": "object",
        "required": ["platforms"],
        "properties": {
            "platforms": {
                "type": "array",
                "items": {"type": "string", "enum": platform_defs.LOGIN_PLATFORM_KEYS},
                "minItems": 1,
                "description": (
                    "Platforms to open login tabs for. Must be from: "
                    f"{', '.join(platform_defs.LOGIN_PLATFORM_KEYS)}."
                ),
            },
        },
    },
)

USER_TIMELINE_TOOL = Tool(
    name="user_timeline",
    description=(
        "Fetch the most recent posts of one SPECIFIC user on one SPECIFIC platform. "
        "Use this when you have a creator's user id and want their back-catalogue — "
        "e.g. content-radar's `follow_list` config enumerates user ids per platform "
        "and asks 'what did each of these creators post recently?'\n\n"
        "Platform coverage is narrower than search: only bilibili (numeric UID), "
        "xiaohongshu (24-char hex profile id), and douyin (sec_uid). Other login "
        "platforms (weibo / youtube / twitter) have no user-keyed retrieval in "
        "autocli — for twitter's 'following' stream use `following_feed` instead.\n\n"
        "Login + Edge auto-launch contract identical to `search`."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform", "user_id"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": TIMELINE_PLATFORMS,
                "description": "Target platform key.",
            },
            "user_id": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Platform-native user identifier. "
                    "bilibili = numeric UID; xiaohongshu = 24-char hex profile id; "
                    "douyin = sec_uid."
                ),
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "default": 20,
                "description": "Max posts to return.",
            },
        },
    },
)

FOLLOWING_FEED_TOOL = Tool(
    name="following_feed",
    description=(
        "Fetch the LOGGED-IN account's own following timeline on one platform. "
        "No user_id needed — the account in the Edge cookie IS the selector. "
        "Use this for 'show me what people I follow are posting right now', as "
        "opposed to `user_timeline`'s 'show me what THIS specific user is posting'.\n\n"
        "Platform coverage: bilibili (关注的人的动态), twitter (following timeline). "
        "Other platforms have no equivalent in autocli.\n\n"
        "Requires an active Edge login on the dedicated profile."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": FEED_PLATFORMS,
                "description": "Target platform key (bilibili / twitter).",
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "default": 20,
                "description": "Max items to return.",
            },
        },
    },
)

POST_DETAIL_TOOL = Tool(
    name="post_detail",
    description=(
        "Fetch one specific post (or video / tweet) along with its comments. "
        "Use this AFTER a `search` / `hot` / `user_timeline` call surfaces a "
        "high-engagement candidate and you want comment text for pain-point "
        "mining, negative-sentiment detection, or user-question extraction.\n\n"
        "Returns one `detail` dict (not a list), with: title, content, author, "
        "views, likes, comments_count, and `comments[]` (each with author/text/"
        "likes/publish_time). Different shape from search!\n\n"
        "Platform coverage: xiaohongshu (creator-note-detail), youtube (comments), "
        "twitter (thread). bilibili / douyin / weibo not yet supported by autocli."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform", "url"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": DETAIL_PLATFORMS,
                "description": "Target platform key.",
            },
            "url": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Full URL of the post / video / tweet — typically the `url` "
                    "field from a prior `search` / `hot` / `user_timeline` result."
                ),
            },
            "comment_limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 100,
                "default": 30,
                "description": "Max comments to return (after sort).",
            },
        },
    },
)

HOT_TOOL = Tool(
    name="hot",
    description=(
        "Fetch one platform's hot / trending board — keyword-LESS discovery. "
        "Use this when you want 'what's trending right now' rather than 'search "
        "for this specific keyword'. Complements `search` for content-radar's "
        "'热点维度' (hot topics dimension).\n\n"
        "Platform coverage: bilibili (hot or ranking via `variant`), weibo (微博热搜), "
        "twitter (trending topics), tiktok (explore), steam (top-sellers), "
        "bbc (news), bloomberg (news), apple-podcasts (top). Other platforms "
        "have no hot board in autocli; for those, use `search` with a broad keyword.\n\n"
        "Login platforms (bilibili/weibo/twitter/tiktok) require login on "
        "the dedicated Edge profile. Public platforms (steam/bbc/bloomberg/"
        "apple-podcasts) work without login."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": HOT_PLATFORMS,
                "description": "Target platform key (bilibili / weibo / twitter).",
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "default": 20,
                "description": "Max items to return.",
            },
            "variant": {
                "type": "string",
                "enum": ["hot", "ranking"],
                "default": "hot",
                "description": (
                    "Board variant. 'hot' (default) maps to each platform's "
                    "trending-now board. 'ranking' is bilibili-only (rankings "
                    "board). Other (platform, variant) combos return "
                    "`unsupported_platform_for_hot`."
                ),
            },
        },
    },
)


DOWNLOAD_MEDIA_TOOL = Tool(
    name="download_media",
    description=(
        "Download the actual video/image files of one post to local disk. Pairs "
        "with `understand_media` for content breakdown: this tool gets the bytes "
        "onto disk; `understand_media` reads them.\n\n"
        "Why not call `understand_media` directly on the source URL: 抖音 / 小红书 / "
        "B站 CDN URLs are signed AND require a platform-specific Referer header. "
        "understand_media's backend doesn't pass that header, so the CDN returns "
        "403. This tool fetches with the right Referer first, then you feed the "
        "local path to understand_media.\n\n"
        "Platform coverage:\n"
        "- xiaohongshu: needs note-id + xsec-token (parse both out of the share URL).\n"
        "- douyin: needs aweme-id (the long numeric id in /video/<id> URLs).\n"
        "- bilibili: needs BVID. Goes through autocli + yt-dlp + ffmpeg merge, "
        "produces one mp4. Quality defaults to 'best' but anonymous Edge profile "
        "can only get 480p without a 大会员 SESSDATA cookie.\n"
        "- taobao: needs item-id (商品链接中 id=xxx 的数字). Extracts product video "
        "from detail page via browser evaluate. Tip: use `search` with platform "
        "=['taobao'] first to find item IDs, then download each.\n"
        "- weixin: post_id is the full article URL. Downloads markdown + images.\n"
        "- twitter: post_id is a tweet URL or username. Uses autocli download.\n"
        "- youtube / instagram / tiktok / facebook / reddit: post_id is the full "
        "post/video URL. Uses yt-dlp. For youtube, a bare video ID also works.\n\n"
        "Failure modes:\n"
        "- `skip_reason: no_media_extracted` — page didn't render (captcha / "
        "anti-bot / deleted post). Tell the user and move on; do NOT retry.\n"
        "- `skip_reason: partial_fetch: N/M ok` — some URLs 4xx'd; the rest are "
        "in files[]. Usually safe to use what came back.\n"
        "- `skip_reason: yt-dlp_not_installed` — yt-dlp binary not found. "
        "Fall back to understand_media with the source URL directly."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform", "post_id", "output_dir"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": DOWNLOAD_PLATFORMS,
                "description": "Target platform key.",
            },
            "post_id": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Platform-native identifier. "
                    "xiaohongshu = 24-char hex note id; "
                    "douyin = numeric aweme-id; "
                    "bilibili = BVID (BV1xxxxxx); "
                    "taobao = numeric item id (from item.htm?id=xxx); "
                    "twitter = tweet URL or username; "
                    "youtube = video URL or video ID; "
                    "instagram / tiktok / facebook / reddit = post URL."
                ),
            },
            "output_dir": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Absolute directory path to write files into. Created if missing. "
                    "Files are named <post_id>_NNN.<ext>."
                ),
            },
            "xsec_token": {
                "type": "string",
                "default": "",
                "description": (
                    "xiaohongshu only — the xsec_token query parameter from the "
                    "share URL. Required for newer notes; omit for douyin/bilibili."
                ),
            },
            "quality": {
                "type": "string",
                "enum": ["best", "1080p", "720p", "480p"],
                "default": "best",
                "description": (
                    "bilibili only — desired video quality. Higher than 720p "
                    "needs 大会员 cookie; 480p anonymous is the safe default."
                ),
            },
        },
    },
)

PUBLISH_TOOL = Tool(
    name="publish",
    description=(
        "Post content to the logged-in creator account.\n\n"
        "Supported platforms:\n"
        "- `xiaohongshu`: 图文 (image+text) or 视频 (video) note.\n"
        "- `twitter`: text, image, or video tweet.\n"
        "- `instagram`: image post (carousel if multiple) or video/reel.\n"
        "- `douyin`: 图文 (image+text) or 视频 (video) post via creator center.\n"
        "- `weibo`: 文字/图文/视频微博.\n"
        "- `weixin`: 微信公众号图文消息.\n\n"
        "WRITE OPERATION — commits to the user's real account.\n\n"
        "xiaohongshu: `draft=true` (DEFAULT, SAFE) means autocli fills the "
        "form via the dedicated Edge profile then STOPS, leaving the user to "
        "manually click 发布笔记 or close the page (which triggers xhs's "
        "save-as-draft modal). Use `draft=false` ONLY after explicit user "
        "opt-in.\n\n"
        "twitter: `draft=true` (DEFAULT, SAFE) fills the compose box in the "
        "visible Edge window but does NOT click Post — user clicks manually. "
        "`draft=false` clicks Post. Max 280 chars text. Images: up to 4 "
        "(jpg/png/gif/webp). Video: single mp4/mov.\n\n"
        "instagram: `draft=true` (DEFAULT, SAFE) fills the create post dialog "
        "but does NOT click Share — user clicks manually. `draft=false` clicks "
        "Share. No text-only posts. Images: up to 10 (jpg/png/webp, carousel "
        "if multiple). Video: single mp4/mov (posted as reel). Caption max "
        "2200 chars.\n\n"
        "douyin: `draft=true` (DEFAULT, SAFE) fills the creator center form "
        "but does NOT click 发布 — user clicks manually. `draft=false` clicks "
        "发布. No text-only posts. Title required (max 30 chars). Images: up "
        "to 35 (jpg/png/gif/webp). Video: single mp4/mov.\n\n"
        "weibo: `draft=true` (DEFAULT, SAFE) fills the compose box but does "
        "NOT click 发布 — user clicks manually. `draft=false` clicks 发布. "
        "Supports text-only, image (up to 9), and video (single mp4/mov). "
        "No title field. Content max 2000 chars. Topics use #topic# format.\n\n"
        "weixin: `draft=true` (DEFAULT, SAFE) fills the article editor but "
        "does NOT click 发表 — user clicks manually. `draft=false` clicks 发表. "
        "Title required (max 64 chars). Content max 20000 chars. Optional cover "
        "image (single jpg/png/webp via `images`). Optional author name. "
        "No video support.\n"
        "weixin html_file mode: provide `html_file` path — title auto-extracted "
        "from <title>, CSS auto-inlined, base64 images auto-uploaded. One step.\n\n"
        "Media-type contract:\n"
        "- `media_type=text` (twitter/weibo): pure text post.\n"
        "- `media_type=image`: provide `images`. xiaohongshu: 1–9 paths; "
        "twitter: 1–4 paths; instagram: 1–10 paths; douyin: 1–35 paths; "
        "weibo: 1–9 paths.\n"
        "- `media_type=video`: provide `video` (single file).\n"
        "- `media_type=html` (weixin only): provide `html_file`.\n\n"
        "Login + Edge contract identical to `search`: if not logged in, the "
        "call fails and the agent should call `launch_login`.\n\n"
        "Result shape:\n"
        "- `status: 已填好待确认 (draft 模式)` — xhs/douyin/instagram/weibo draft mode success\n"
        "- `status: 发布成功` / `已点击发布...` — xhs/douyin/weibo publish mode click\n"
        "- `status: posted` — twitter/instagram post success\n"
        "- `status: skipped` with `skip_reason` — validation or autocli error"
    ),
    inputSchema={
        "type": "object",
        "required": ["platform"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": list(PUBLISH_PLATFORMS),
                "description": "Target platform: 'xiaohongshu', 'twitter', 'instagram', 'douyin', 'weibo', or 'weixin'.",
            },
            "media_type": {
                "type": "string",
                "enum": list(PUBLISH_MEDIA_TYPES),
                "default": "image",
                "description": (
                    "'text' (twitter/weibo/weixin) → pure text post. "
                    "'image' (default) → requires `images`. "
                    "'video' → requires `video`. "
                    "'html' (weixin only) → publish from HTML file via `html_file`. "
                    "instagram/douyin: no text-only posts. weixin: no video."
                ),
            },
            "title": {
                "type": "string",
                "maxLength": PUBLISH_MAX_TITLE,
                "description": (
                    f"Note title, max {PUBLISH_MAX_TITLE} chars. "
                    "REQUIRED for xiaohongshu/douyin/weixin, ignored for twitter/instagram/weibo."
                ),
            },
            "content": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Post body text. For twitter: the tweet text (max 280 chars). "
                    "For xiaohongshu: note body. For instagram: caption (max 2200 chars). "
                    "For weibo: 微博正文 (max 2000 chars). "
                    "For weixin: 文章正文 (max 20000 chars)."
                ),
            },
            "images": {
                "type": "array",
                "items": {"type": "string", "minLength": 1},
                "minItems": 1,
                "maxItems": 10,
                "description": (
                    f"REQUIRED when media_type=image. "
                    f"Absolute paths to image files (xiaohongshu max {PUBLISH_MAX_IMAGES}, "
                    "twitter max 4, instagram max 10). "
                    "Allowed: .jpg/.jpeg/.png/.gif/.webp."
                ),
            },
            "video": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "REQUIRED when media_type=video. "
                    "Absolute path to a single video file. "
                    "xiaohongshu: .mp4/.mov/.flv/.f4v/.mkv/.rm/.rmvb/.m4v/.mpg/.mpeg/.ts; "
                    "twitter/instagram: .mp4/.mov"
                ),
            },
            "topics": {
                "type": "array",
                "items": {"type": "string", "minLength": 1},
                "description": "Optional topic tags (without # prefix). xiaohongshu/douyin/weibo only.",
            },
            "author": {
                "type": "string",
                "description": (
                    "Optional author name displayed on the article. "
                    "weixin only. Defaults to 'AI助手' if not provided."
                ),
            },
            "draft": {
                "type": "boolean",
                "default": True,
                "description": (
                    "true (DEFAULT, SAFE): fill form/compose box then stop, "
                    "user clicks publish manually. "
                    "false: actually click publish (xiaohongshu: 发布笔记, "
                    "twitter: Post, instagram: Share, weibo: 发布, "
                    "weixin: 发表). Needs explicit user opt-in."
                ),
            },
            "click_draft_btn": {
                "type": "boolean",
                "default": False,
                "description": (
                    "weixin only: in draft mode, also click the '保存为草稿' "
                    "(Save as Draft) button after filling the form. "
                    "Default false: draft mode fills the form but does not click any button."
                ),
            },
            "html_file": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "weixin only: path to an HTML file to publish as a WeChat "
                    "article. The file is automatically pre-processed: title "
                    "extracted from <title>, CSS inlined, base64 images saved "
                    "and uploaded. When set, `content` and `title` are optional "
                    "(derived from the file). Sets media_type='html' implicitly."
                ),
            },
        },
    },
)

GET_SUBTITLE_TOOL = Tool(
    name="get_subtitle",
    description=(
        "Fetch a post's subtitle/caption segments with from/to timestamps. Use "
        "this when you need a verbatim transcript with timing — e.g. building a "
        "video-script-generator input or quoting specific moments by timestamp.\n\n"
        "Difference vs understand_media: understand_media gives prose description "
        "('this video is about X'); this tool gives structured segments "
        "([{from, to, content}, ...]).\n\n"
        "Platform coverage today: ONLY bilibili (autocli has WBI-signed access to "
        "B站's subtitle API). For 抖音 / 小红书 / 抖音 / youtube / twitter that have "
        "no autocli subtitle subcommand, use download_media + understand_media "
        "(question='give me a verbatim transcript with timestamps') instead."
    ),
    inputSchema={
        "type": "object",
        "required": ["platform", "post_id"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": SUBTITLE_PLATFORMS,
                "description": "Target platform key (currently only 'bilibili').",
            },
            "post_id": {
                "type": "string",
                "minLength": 1,
                "description": "bilibili: BVID (BV1xxxxxx).",
            },
            "lang": {
                "type": "string",
                "default": "",
                "description": (
                    "Subtitle language code (e.g. 'zh-CN', 'ai-zh', 'en-US'). "
                    "Empty = autocli picks the first available."
                ),
            },
        },
    },
)


TRANSCRIBE_AUDIO_TOOL = Tool(
    name="transcribe_audio",
    description=(
        "Run ASR on a local video/audio file to produce timestamped segments. "
        "Use this when `get_subtitle` returned `skip_reason: unsupported_platform` "
        "or `no_subtitle_infos` — the video has no platform-provided captions, "
        "so you have to recognise the speech yourself.\n\n"
        "Pipeline: ffmpeg extracts mono 16kHz WAV → ASR engine → returns "
        "[{index, from, to, content}] (same shape as get_subtitle).\n\n"
        "Engines:\n"
        "- 'bcut' (default): bilibili 必剪 cloud ASR. Free, best-quality Chinese, "
        "no GPU needed. ~30-60s per minute of audio. Sends bytes to "
        "member.bilibili.com — do NOT use for sensitive content.\n"
        "- 'whisper': local faster-whisper. Requires "
        "`pip install mcp-autocli[whisper]`. Best for privacy / English / no "
        "network. ~30-90s per minute on CPU. Set $MCP_AUTOCLI_WHISPER_MODEL "
        "(default 'tiny') for accuracy tradeoff."
    ),
    inputSchema={
        "type": "object",
        "required": ["media_path"],
        "properties": {
            "media_path": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Absolute path to a local mp4/m4a/mp3/wav/... file. "
                    "Typically obtained from a prior download_media call's files[].path."
                ),
            },
            "engine": {
                "type": "string",
                "enum": TRANSCRIBE_ENGINES,
                "default": "bcut",
                "description": "ASR backend. See tool description for tradeoffs.",
            },
            "language": {
                "type": "string",
                "default": "zh-CN",
                "description": (
                    "Language hint, only honoured by whisper. Common values: "
                    "'zh-CN', 'en', 'auto'."
                ),
            },
        },
    },
)

EXTRACT_KEYFRAMES_TOOL = Tool(
    name="extract_keyframes",
    description=(
        "Dump one frame from a video at each ASR/subtitle segment's start "
        "timestamp. Used to build 分镜/keyframe analysis reports paired with "
        "transcript text.\n\n"
        "Input segments come straight from get_subtitle or transcribe_audio "
        "(same shape). When segments exceed max_frames, samples uniformly "
        "across the timeline (not just the first N) so you cover beginning, "
        "middle, end.\n\n"
        "Output is a list of {timestamp_str, transcript, screenshot_path} — "
        "the screenshot paths can be fed into understand_media for image-by-"
        "image analysis if needed."
    ),
    inputSchema={
        "type": "object",
        "required": ["media_path", "segments", "output_dir"],
        "properties": {
            "media_path": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Absolute path to a local video file with a video stream. "
                    "Typically the same path you passed to transcribe_audio."
                ),
            },
            "segments": {
                "type": "array",
                "description": (
                    "Segment list from get_subtitle or transcribe_audio. Each "
                    "item must have a 'from' field (e.g. '12.50s'); 'content' "
                    "is copied through if present."
                ),
                "items": {
                    "type": "object",
                    "required": ["from"],
                    "properties": {
                        "from": {"type": "string"},
                        "content": {"type": "string"},
                    },
                },
            },
            "output_dir": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Absolute directory to write PNG screenshots into. Created "
                    "if missing. Files are named frame_NNN_<ts>s.png."
                ),
            },
            "max_frames": {
                "type": "integer",
                "minimum": 1,
                "maximum": 200,
                "default": 20,
                "description": (
                    "Cap the number of frames. When len(segments) > max_frames, "
                    "samples uniformly across the timeline."
                ),
            },
        },
    },
)


ACCOUNT_DASHBOARD_TOOL = Tool(
    name="account_dashboard",
    description=(
        "Fan out across multiple autocli subcommands to return the logged-in "
        "account's own state on one platform — what stats my account has, what "
        "I've saved/bookmarked, what I've watched, what my recent posts did.\n\n"
        "Use this for content-radar's 'self-audit' lane: before generating new "
        "选题 ideas, check what I already published, how it performed, what I "
        "already bookmarked but haven't acted on. Each platform fan-out runs in "
        "parallel; partial failures are isolated to that section's skip_reason "
        "(e.g. xhs creator endpoints need Creator Center login, but bilibili "
        "stays intact even if xhs fails).\n\n"
        "Per-platform composition:\n"
        "- xiaohongshu: creator-profile + creator-stats(7d)\n"
        "- bilibili:    me + favorite(20) + history(20)\n"
        "- twitter:     profile + bookmarks(20)"
    ),
    inputSchema={
        "type": "object",
        "required": ["platform"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": DASHBOARD_PLATFORMS,
                "description": "Target platform key.",
            },
        },
    },
)

ACCOUNT_NOTIFICATIONS_TOOL = Tool(
    name="account_notifications",
    description=(
        "Pull the logged-in account's notification inbox on one platform — "
        "@mentions, comments on my posts, new followers, etc. High-signal "
        "input for content-radar's 'real-time demand' lane: every entry is a "
        "real person interacting with my own content, much more directly "
        "actionable than aggregate search.\n\n"
        "Per-platform inbox filters:\n"
        "- douyin:      type ∈ {all, like, comment, follow, at} (default all)\n"
        "- twitter:     no type filter — single combined inbox"
    ),
    inputSchema={
        "type": "object",
        "required": ["platform"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": NOTIFICATIONS_PLATFORMS,
                "description": "Target platform key.",
            },
            "notification_type": {
                "type": "string",
                "default": "",
                "description": (
                    "Optional inbox filter. "
                    "douyin: all|like|comment|follow|at; twitter: ignored."
                ),
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 100,
                "default": 20,
                "description": "Max notifications to return.",
            },
        },
    },
)


PLATFORM_ACTION_TOOL = Tool(
    name="platform_action",
    description=(
        "Execute any autocli adapter subcommand on a specific platform. "
        "Covers ALL read and write operations not handled by the specialised "
        "tools (search / hot / post_detail / user_timeline / following_feed / "
        "account_dashboard / account_notifications / download_media / publish / "
        "get_subtitle / transcribe_audio / extract_keyframes / launch_login).\n\n"
        "Use this tool for per-platform operations such as:\n"
        "- Social: twitter post/reply/like/follow, instagram follow/like/comment, "
        "reddit comment/upvote, tiktok follow/like, facebook add-friend\n"
        "- Reading profiles/feeds: twitter profile, instagram explore/profile, "
        "reddit frontpage/subreddit, medium feed\n"
        "- Finance: barchart options/greeks/flow, yahoo-finance quote\n"
        "- News: bloomberg markets/economics/politics, google news/trends\n"
        "- AI tools: chatgpt ask/send, grok ask, cursor composer, codex ask\n"
        "- Productivity: notion read/write/new, discord send/read\n"
        "- Tech: hackernews top/best/new, stackoverflow hot/bounties\n\n"
        "WRITE OPERATIONS (post/reply/like/follow/comment/send/delete etc.) "
        "modify the user's real account. The response includes a `write_warning` "
        "field — relay it to the user and get confirmation before issuing the "
        "call, or only proceed when the user has explicitly asked for the action.\n\n"
        "Action registry (platform → actions):\n" + ACTION_SUMMARY
    ),
    inputSchema={
        "type": "object",
        "required": ["platform", "action"],
        "properties": {
            "platform": {
                "type": "string",
                "enum": ALL_PLATFORMS_WITH_ACTIONS,
                "description": "Target platform key.",
            },
            "action": {
                "type": "string",
                "description": (
                    "Subcommand name — must be one of the actions listed in the "
                    "action registry for the chosen platform."
                ),
            },
            "args": {
                "type": "array",
                "items": {"type": "string"},
                "default": [],
                "description": (
                    "Positional arguments for the subcommand, in order. "
                    "E.g. for 'twitter profile': [\"elonmusk\"]. "
                    "For 'reddit comment': [\"1abc123\", \"Great post!\"]."
                ),
            },
            "options": {
                "type": "object",
                "default": {},
                "description": (
                    "Named flags as key-value pairs. "
                    "E.g. {\"limit\": 20} or {\"type\": \"Call\", \"limit\": 10}. "
                    "Keys are flag names without the '--' prefix."
                ),
            },
        },
    },
)



DOWNLOAD_TAOBAO_CART_TOOL = Tool(
    name="download_taobao_cart",
    description=(
        "One-step batch download: extract all items from the user's Taobao "
        "shopping cart and download each item's product video to local disk.\n\n"
        "Flow: navigates to cart.taobao.com → extracts item list → for each "
        "item, navigates to its detail page, clicks the video play button, "
        "and fetches the CDN video URL.\n\n"
        "Requires the user to be logged into Taobao on the dedicated Edge "
        "profile. Items without video are skipped (status='no_video').\n\n"
        "Returns per-item status so the caller can see which items had video "
        "and which didn't."
    ),
    inputSchema={
        "type": "object",
        "required": ["output_dir"],
        "properties": {
            "output_dir": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Root directory for downloads. Each cart item gets a "
                    "subdirectory named by its item_id."
                ),
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 100,
                "default": 50,
                "description": "Max cart items to process.",
            },
            "concurrency": {
                "type": "integer",
                "minimum": 1,
                "maximum": 4,
                "default": 2,
                "description": (
                    "Max parallel downloads. Keep low (1-2) to avoid "
                    "Taobao anti-bot detection."
                ),
            },
        },
    },
)

CLEANUP_DOWNLOAD_TOOL = Tool(
    name="cleanup_download",
    description=(
        "Delete ALL files created by prior download_media calls in this "
        "session. No arguments needed — the tool tracks every output_dir "
        "internally.\n\n"
        "Call this after you have finished processing downloaded media "
        "(transcribe, keyframes, understand_media, etc.) to free disk space. "
        "Returns the list of cleaned directories and total files removed."
    ),
    inputSchema={
        "type": "object",
        "properties": {},
    },
)


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        SEARCH_TOOL,
        LAUNCH_LOGIN_TOOL,
        USER_TIMELINE_TOOL,
        FOLLOWING_FEED_TOOL,
        POST_DETAIL_TOOL,
        HOT_TOOL,
        DOWNLOAD_MEDIA_TOOL,
        DOWNLOAD_TAOBAO_CART_TOOL,
        PUBLISH_TOOL,
        GET_SUBTITLE_TOOL,
        TRANSCRIBE_AUDIO_TOOL,
        EXTRACT_KEYFRAMES_TOOL,
        ACCOUNT_DASHBOARD_TOOL,
        ACCOUNT_NOTIFICATIONS_TOOL,
        PLATFORM_ACTION_TOOL,
        CLEANUP_DOWNLOAD_TOOL,
    ]


def _serialize(payload: Any) -> list[TextContent]:
    """Render any JSON-serializable payload as one TextContent block.

    Wukong / Claude Code parse this back into a structured value by JSON-
    decoding the text field.
    """
    return [
        TextContent(
            type="text",
            text=json.dumps(payload, ensure_ascii=False, default=str),
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    arguments = arguments or {}
    try:
        if name == "search":
            result = await search(
                keyword=arguments["keyword"],
                platforms=arguments.get("platforms"),
                limit_per_platform=arguments.get("limit_per_platform", 20),
            )
            return _serialize(result)

        if name == "launch_login":
            result = await launch_login(platforms=arguments["platforms"])
            return _serialize(result)

        if name == "user_timeline":
            result = await user_timeline(
                platform=arguments["platform"],
                user_id=arguments["user_id"],
                limit=arguments.get("limit", 20),
            )
            return _serialize(result)

        if name == "following_feed":
            result = await following_feed(
                platform=arguments["platform"],
                limit=arguments.get("limit", 20),
            )
            return _serialize(result)

        if name == "post_detail":
            result = await post_detail(
                platform=arguments["platform"],
                url=arguments["url"],
                comment_limit=arguments.get("comment_limit", 30),
            )
            return _serialize(result)

        if name == "hot":
            result = await hot(
                platform=arguments["platform"],
                limit=arguments.get("limit", 20),
                variant=arguments.get("variant", "hot"),
            )
            return _serialize(result)

        if name == "download_media":
            result = await download_media(
                platform=arguments["platform"],
                post_id=arguments["post_id"],
                output_dir=arguments["output_dir"],
                xsec_token=arguments.get("xsec_token", ""),
                quality=arguments.get("quality", "best"),
            )
            return _serialize(result)

        if name == "publish":
            result = await publish(
                platform=arguments["platform"],
                title=arguments.get("title"),
                content=arguments.get("content", ""),
                media_type=arguments.get("media_type", "html" if arguments.get("html_file") else ("text" if arguments["platform"] in ("twitter", "weibo", "weixin") else "image")),
                images=arguments.get("images"),
                video=arguments.get("video"),
                topics=arguments.get("topics"),
                draft=arguments.get("draft", True),
                html_file=arguments.get("html_file"),
                author=arguments.get("author"),
                click_draft_btn=arguments.get("click_draft_btn", False),
            )
            return _serialize(result)

        if name == "get_subtitle":
            result = await get_subtitle(
                platform=arguments["platform"],
                post_id=arguments["post_id"],
                lang=arguments.get("lang", ""),
            )
            return _serialize(result)

        if name == "transcribe_audio":
            result = await transcribe_audio(
                media_path=arguments["media_path"],
                engine=arguments.get("engine", "bcut"),
                language=arguments.get("language", "zh-CN"),
            )
            return _serialize(result)

        if name == "extract_keyframes":
            result = await extract_keyframes(
                media_path=arguments["media_path"],
                segments=arguments["segments"],
                output_dir=arguments["output_dir"],
                max_frames=arguments.get("max_frames", 20),
            )
            return _serialize(result)

        if name == "account_dashboard":
            result = await account_dashboard(platform=arguments["platform"])
            return _serialize(result)

        if name == "account_notifications":
            result = await account_notifications(
                platform=arguments["platform"],
                notification_type=arguments.get("notification_type", ""),
                limit=arguments.get("limit", 20),
            )
            return _serialize(result)

        if name == "platform_action":
            result = await platform_action(
                platform=arguments["platform"],
                action=arguments["action"],
                args=arguments.get("args", []),
                options=arguments.get("options", {}),
            )
            return _serialize(result)


        if name == "download_taobao_cart":
            result = await download_taobao_cart(
                output_dir=arguments["output_dir"],
                limit=arguments.get("limit", 50),
                concurrency=arguments.get("concurrency", 2),
            )
            return _serialize(result)

        if name == "cleanup_download":
            result = cleanup_download()
            return _serialize(result)

        return _serialize({"error": f"unknown tool: {name}"})

    except AutocliNotFoundError as e:
        log.warning("autocli missing: %s", e)
        return _serialize({
            "error": "autocli_not_installed",
            "message": str(e),
        })
    except KeyError as e:
        return _serialize({
            "error": "missing_required_argument",
            "argument": str(e).strip("'"),
        })
    except ValueError as e:
        return _serialize({"error": "invalid_argument", "message": str(e)})
    except Exception as e:
        # Last-resort: never crash the MCP loop on a tool exception. The
        # client (Wukong / Claude Code) deserves a structured failure it can
        # show the user, not a dropped connection.
        log.exception("tool %s crashed", name)
        return _serialize({
            "error": "internal_error",
            "message": f"{type(e).__name__}: {e}",
        })


async def _async_main() -> None:
    log.info("mcp-autocli %s starting (stdio)", __version__)
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    """Console-script entry point — `mcp-autocli` after `pip install`.

    Dispatches subcommands:
    - `mcp-autocli setup [--force]` → bootstrap autocli binary + extension
    - `mcp-autocli` (no args)        → run the stdio MCP server (how MCP
      hosts launch it)

    Keeping the no-arg path as the server is critical: MCP host configs
    typically invoke `mcp-autocli` with no arguments and expect stdio.
    """
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        from .setup_cli import run_setup
        sys.exit(run_setup(sys.argv[2:]))

    try:
        asyncio.run(_async_main())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
