"""`transcribe_audio` tool — ASR for video/audio when no API subtitle exists.

Why this exists: get_subtitle covers bilibili (uploaded/AI subs) and douyin
(when subtitle_infos is populated). For everything else — small douyin videos
without subs, xiaohongshu video notes, bilibili videos without ai-zh — the
only way to get a transcript is to recognize the audio.

Engines (controlled by `engine` arg):
- "bcut" (default): bilibili 必剪 free cloud ASR. Best for Chinese, ~30-60s
  per minute of audio. No GPU needed. Network call to member.bilibili.com.
- "whisper": faster-whisper local model. Optional dep — install with
  `pip install mcp-autocli[whisper]`. Best for English / privacy-sensitive
  cases. Slower on CPU (~30-90s per minute) but no network.

Pipeline:
1. ffmpeg extracts mono 16kHz WAV from the input (any container ffmpeg reads)
2. engine.transcribe() returns utterances with ms-precision timing
3. Normalised to [{index, from, to, content}] — same schema as get_subtitle
   so extract_keyframes can consume either source.

Adapted from content-extractor's scripts/extractor/bcut_asr.py.
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

log = logging.getLogger("mcp-autocli.transcribe")


SUPPORTED_ENGINES: list[str] = ["bcut", "whisper"]

TRANSCRIBE_TIMEOUT_SECONDS = 600
EXTRACT_AUDIO_TIMEOUT_SECONDS = 120

# bcut endpoints — bilibili's free cloud ASR. Stable for years; changing
# these means upstream broke the API.
_BCUT_API_REQ_UPLOAD = "https://member.bilibili.com/x/bcut/rubick-interface/resource/create"
_BCUT_API_COMMIT_UPLOAD = "https://member.bilibili.com/x/bcut/rubick-interface/resource/create/complete"
_BCUT_API_CREATE_TASK = "https://member.bilibili.com/x/bcut/rubick-interface/task"
_BCUT_API_QUERY_RESULT = "https://member.bilibili.com/x/bcut/rubick-interface/task/result"

_BCUT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
}


def _find_ffmpeg() -> str | None:
    """Locate ffmpeg — PATH first, then imageio-ffmpeg's bundled binary."""
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg  # type: ignore
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        return None


def _extract_audio(video_path: Path, audio_path: Path) -> tuple[bool, str | None]:
    """Extract mono 16kHz PCM WAV from any video container. Returns (ok, err)."""
    ffmpeg = _find_ffmpeg()
    if not ffmpeg:
        return False, "ffmpeg not found (run `mcp-autocli setup` to install imageio-ffmpeg)"

    if not video_path.exists():
        return False, f"input file does not exist: {video_path}"
    if video_path.stat().st_size < 1024:
        return False, f"input file too small ({video_path.stat().st_size} bytes — likely incomplete download)"

    cmd = [
        ffmpeg, "-i", str(video_path),
        "-vn",                  # drop video
        "-acodec", "pcm_s16le", # 16-bit PCM (bcut-compatible)
        "-ar", "16000",         # 16kHz sample rate
        "-ac", "1",             # mono
        "-y",                   # overwrite
        str(audio_path),
    ]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=EXTRACT_AUDIO_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return False, f"ffmpeg timeout after {EXTRACT_AUDIO_TIMEOUT_SECONDS}s"
    except (FileNotFoundError, OSError) as e:
        return False, f"ffmpeg spawn failed: {e!r}"

    if proc.returncode != 0 or not audio_path.exists() or audio_path.stat().st_size == 0:
        stderr_tail = (proc.stderr or "")[-300:]
        return False, f"ffmpeg failed (exit {proc.returncode}): {stderr_tail}"

    return True, None


class _BcutAPIError(Exception):
    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"bcut[{code}]: {message}")


def _bcut_transcribe_blocking(audio_path: Path) -> list[dict[str, Any]]:
    """Sync bcut pipeline: upload → commit → create_task → poll. Returns segments."""
    import requests  # noqa: PLC0415 — bcut path only imports it when used

    session = requests.Session()
    session.headers.update(_BCUT_HEADERS)

    sound_bin = audio_path.read_bytes()
    sound_fmt = audio_path.suffix.lstrip(".").lower()
    sound_name = audio_path.name

    # Step 1: request upload slot
    resp = session.post(_BCUT_API_REQ_UPLOAD, data={
        "type": 2,
        "name": sound_name,
        "size": len(sound_bin),
        "resource_file_type": sound_fmt,
        "model_id": 7,
    }, timeout=30)
    resp.raise_for_status()
    j = resp.json()
    if j.get("code"):
        raise _BcutAPIError(j["code"], j.get("message", "upload-slot request failed"))
    data = j["data"]
    upload_urls = data["upload_urls"]
    per_size = data["per_size"]

    # Step 2: PUT chunks to the upload URLs
    etags: list[str] = []
    for idx, upload_url in enumerate(upload_urls):
        start = idx * per_size
        end = (idx + 1) * per_size
        chunk_resp = session.put(upload_url, data=sound_bin[start:end], timeout=60)
        chunk_resp.raise_for_status()
        etags.append(chunk_resp.headers.get("Etag", ""))

    # Step 3: commit upload
    resp = session.post(_BCUT_API_COMMIT_UPLOAD, data={
        "in_boss_key": data["in_boss_key"],
        "resource_id": data["resource_id"],
        "etags": ",".join(etags),
        "upload_id": data["upload_id"],
        "model_id": 7,
    }, timeout=30)
    resp.raise_for_status()
    j = resp.json()
    if j.get("code"):
        raise _BcutAPIError(j["code"], j.get("message", "commit failed"))
    download_url = j["data"]["download_url"]

    # Step 4: create ASR task (with retry on transient -504)
    task_id = None
    for attempt in range(1, 4):
        resp = session.post(_BCUT_API_CREATE_TASK, json={
            "resource": download_url, "model_id": "7",
        }, timeout=30)
        resp.raise_for_status()
        j = resp.json()
        if j.get("code") == 0:
            task_id = j["data"]["task_id"]
            break
        if j.get("code") == -504 and attempt < 3:
            time.sleep(2 * attempt)
            continue
        raise _BcutAPIError(j["code"], j.get("message", "create task failed"))
    if not task_id:
        raise _BcutAPIError(-1, "create task retries exhausted")

    # Step 5: poll for completion (up to 5 minutes)
    poll_started = time.time()
    while time.time() - poll_started < 300:
        resp = session.get(_BCUT_API_QUERY_RESULT, params={
            "model_id": 7, "task_id": task_id,
        }, timeout=30)
        resp.raise_for_status()
        j = resp.json()
        if j.get("code"):
            raise _BcutAPIError(j["code"], j.get("message", "poll failed"))
        result_data = j["data"]
        state = result_data.get("state")
        # state: 0 stop / 1 running / 3 error / 4 complete
        if state == 4:
            raw = json.loads(result_data.get("result", "{}"))
            utterances = raw.get("utterances", [])
            return [
                {
                    "start_ms": int(u.get("start_time", 0)),
                    "end_ms":   int(u.get("end_time", 0)),
                    "text":     u.get("transcript", ""),
                }
                for u in utterances
            ]
        if state == 3:
            raise _BcutAPIError(-1, f"recognition failed: {result_data.get('remark', 'unknown')}")
        time.sleep(1)

    raise _BcutAPIError(-1, "recognition timed out after 300s")


def _whisper_transcribe_blocking(audio_path: Path, language: str) -> list[dict[str, Any]]:
    """faster-whisper local pipeline. Optional dep."""
    try:
        from faster_whisper import WhisperModel  # type: ignore  # noqa: PLC0415
    except ImportError:
        raise RuntimeError(
            "faster-whisper not installed; install with `pip install mcp-autocli[whisper]` "
            "or pick engine='bcut'."
        )

    # Model size pick: tiny is the smallest weights (~75MB), good enough for
    # transcript-extraction use; small/base/large take more disk + RAM.
    # Caller can override via env if they have CUDA / want better accuracy.
    import os  # noqa: PLC0415
    model_size = os.environ.get("MCP_AUTOCLI_WHISPER_MODEL", "tiny")
    compute_type = os.environ.get("MCP_AUTOCLI_WHISPER_COMPUTE", "int8")

    model = WhisperModel(model_size, device="cpu", compute_type=compute_type)
    segments_iter, _info = model.transcribe(
        str(audio_path),
        language=language if language else None,
        vad_filter=True,
    )
    return [
        {
            "start_ms": int(seg.start * 1000),
            "end_ms":   int(seg.end * 1000),
            "text":     seg.text.strip(),
        }
        for seg in segments_iter
    ]


def _ms_to_label(ms: int) -> str:
    """Format ms timestamp as e.g. '0.00s' to match get_subtitle output."""
    return f"{ms / 1000:.2f}s"


async def transcribe_audio(
    media_path: str,
    engine: str = "bcut",
    language: str = "zh-CN",
) -> dict[str, Any]:
    """ASR a video/audio file to timestamped segments.

    Args:
        media_path: Absolute path to a local mp4/m4a/mp3/wav/... file. Caller
                    typically gets this from a prior download_media call.
        engine: "bcut" (default — bilibili cloud, free, best for Chinese) or
                "whisper" (local faster-whisper, requires
                `pip install mcp-autocli[whisper]`).
        language: Hint for whisper engine (e.g. "zh-CN", "en", "auto").
                  Ignored by bcut (server picks).

    Returns:
        {
          "media_path": str,
          "engine": str,
          "language": str,
          "segments": [{"index": int, "from": "0.00s", "to": "1.08s", "content": str}],
          "skip_reason": str | None,
          "elapsed_seconds": float
        }
    """
    media_path = (media_path or "").strip()
    if not media_path:
        raise ValueError("media_path must be non-empty")
    engine = (engine or "bcut").strip().lower()
    if engine not in SUPPORTED_ENGINES:
        raise ValueError(f"engine must be one of {SUPPORTED_ENGINES}, got {engine!r}")

    src = Path(media_path).expanduser()
    if not src.exists():
        return {
            "media_path": str(src),
            "engine": engine,
            "language": language,
            "segments": [],
            "skip_reason": "input_file_not_found",
            "elapsed_seconds": 0.0,
        }

    started = time.monotonic()

    # Extract mono 16kHz PCM WAV — both engines accept this format.
    audio_path = src.with_suffix(".transcribe.wav")
    ok, err = await asyncio.to_thread(_extract_audio, src, audio_path)
    if not ok:
        return {
            "media_path": str(src),
            "engine": engine,
            "language": language,
            "segments": [],
            "skip_reason": f"audio_extract_failed: {err}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    try:
        if engine == "bcut":
            try:
                raw_segments = await asyncio.wait_for(
                    asyncio.to_thread(_bcut_transcribe_blocking, audio_path),
                    timeout=TRANSCRIBE_TIMEOUT_SECONDS,
                )
            except _BcutAPIError as e:
                return {
                    "media_path": str(src), "engine": engine, "language": language,
                    "segments": [],
                    "skip_reason": f"bcut_api_error: {e}",
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                }
            except asyncio.TimeoutError:
                return {
                    "media_path": str(src), "engine": engine, "language": language,
                    "segments": [],
                    "skip_reason": f"bcut_timeout after {TRANSCRIBE_TIMEOUT_SECONDS}s",
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                }
        else:  # whisper
            try:
                raw_segments = await asyncio.wait_for(
                    asyncio.to_thread(_whisper_transcribe_blocking, audio_path, language),
                    timeout=TRANSCRIBE_TIMEOUT_SECONDS,
                )
            except RuntimeError as e:  # faster-whisper missing
                return {
                    "media_path": str(src), "engine": engine, "language": language,
                    "segments": [],
                    "skip_reason": str(e),
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                }
    finally:
        # Always clean up extracted audio (might be 100+MB for long videos)
        try:
            audio_path.unlink(missing_ok=True)
        except OSError:
            pass

    segments = [
        {
            "index": i + 1,
            "from": _ms_to_label(seg["start_ms"]),
            "to": _ms_to_label(seg["end_ms"]),
            "content": seg["text"],
        }
        for i, seg in enumerate(raw_segments)
    ]

    return {
        "media_path": str(src),
        "engine": engine,
        "language": language,
        "segments": segments,
        "skip_reason": None if segments else "no_speech_detected",
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
