"""`publish` tool — post content to a creator account via autocli's UI automation.

Supported platforms:

- **xiaohongshu**: 图文 or 视频笔记.
  - `media_type="image"`: requires `images` (1–9 paths).
  - `media_type="video"`: requires `video` (single mp4/mov/.../ts path).
- **twitter**: text / image / video tweet.
  - `media_type="text"`: pure text post.
  - `media_type="image"`: tweet with images (1–4), requires `images`.
  - `media_type="video"`: tweet with video (single mp4/mov), requires `video`.
- **instagram**: image / video (reel) post.
  - `media_type="image"`: post with images (1–10 carousel), requires `images`.
  - `media_type="video"`: reel with video (single mp4/mov), requires `video`.
  - No text-only posts; caption max 2200 chars.
- **douyin**: 图文 or 视频.
  - `media_type="image"`: requires `images` (1–35 paths).
  - `media_type="video"`: requires `video` (single mp4/mov), requires `video`.
  - No text-only posts; title required (max 30 chars).
- **weibo**: 文字 / 图文 / 视频微博.
  - `media_type="text"`: pure text post.
  - `media_type="image"`: post with images (1–9), requires `images`.
  - `media_type="video"`: post with video (single mp4/mov), requires `video`.
  - No title; content max 2000 chars. Topics use #topic# format.
- **weixin**: 微信公众号图文消息.
  - `media_type="text"`: 纯文本文章 (title required, content required).
  - `media_type="image"`: 带封面图文章 (single cover image via `images`).
  - Title required (max 64 chars). Content max 20000 chars.

Write operation. `draft=true` (DEFAULT, SAFE) means: autocli fills the form
via the dedicated Edge profile then STOPS, leaving the human to click the
publish button manually. `draft=false` actually clicks the publish button —
needs explicit user opt-in.

Output schema:
    {
      "platform": str,
      "media_type": str,
      "title": str | None,
      "draft": bool,
      "status": str,    # "已填好待确认 (draft 模式)" | "发布成功" | "posted" | "skipped"
      "detail": str,
      "skip_reason": str | None,
      "elapsed_seconds": float,
    }
"""
from __future__ import annotations

import asyncio
import http.server
import re
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Any

from ..lib import paths
from ..lib.autocli_runner import AutocliNotFoundError, run_autocli_json
from .search import _is_edge_running


SUPPORTED_PLATFORMS: list[str] = ["xiaohongshu", "twitter", "instagram", "douyin", "weibo", "weixin"]
SUPPORTED_MEDIA_TYPES: list[str] = ["image", "video", "text", "html"]


def _serve_content_once(content: str) -> str:
    """Start a one-shot HTTP server that serves *content* as text/html.

    Returns the URL (http://127.0.0.1:PORT/content.html).
    The server shuts down after the first GET request.
    """
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(content.encode('utf-8'))

        def log_message(self, *_args: Any) -> None:
            pass  # silence logs

    # Pick a free port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]

    server = http.server.HTTPServer(('127.0.0.1', port), Handler)

    def _run():
        server.handle_request()  # serve exactly one request, then exit
        server.server_close()

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    return f'http://127.0.0.1:{port}/content.html'

PUBLISH_TIMEOUT_SECONDS = 180
MAX_TITLE_CHARS = 20
MAX_IMAGES = 9

_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
_ALLOWED_VIDEO_EXTS = {".mp4", ".mov", ".flv", ".f4v", ".mkv", ".rm", ".rmvb", ".m4v", ".mpg", ".mpeg", ".ts"}

TWITTER_MAX_CHARS = 280
TWITTER_MAX_IMAGES = 4
_TWITTER_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
_TWITTER_ALLOWED_VIDEO_EXTS = {".mp4", ".mov"}

INSTAGRAM_MAX_IMAGES = 10
INSTAGRAM_MAX_CAPTION_CHARS = 2200
_INSTAGRAM_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
_INSTAGRAM_ALLOWED_VIDEO_EXTS = {".mp4", ".mov"}

DOUYIN_MAX_TITLE_CHARS = 30
DOUYIN_MAX_IMAGES = 35
DOUYIN_MAX_CONTENT_CHARS = 5000
_DOUYIN_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
_DOUYIN_ALLOWED_VIDEO_EXTS = {".mp4", ".mov"}

WEIBO_MAX_CONTENT_CHARS = 2000
WEIBO_MAX_IMAGES = 9
_WEIBO_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
_WEIBO_ALLOWED_VIDEO_EXTS = {".mp4", ".mov"}

WEIXIN_MAX_TITLE_CHARS = 64
WEIXIN_MAX_CONTENT_CHARS = 20000
WEIXIN_MAX_IMAGES = 9
_WEIXIN_ALLOWED_IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp"}


# ---------------------------------------------------------------------------
# HTML pre-processing for weixin html_file mode
# ---------------------------------------------------------------------------

def _inline_css(html: str) -> str:
    """Extract <style> blocks and inline their rules onto matching elements.

    Only handles simple selectors: tag, .class, #id, and tag.class combos.
    Compound / pseudo / media-query selectors are skipped gracefully.
    """
    style_blocks: list[str] = []
    for match in re.finditer(r'<style[^>]*>(.*?)</style>', html, re.DOTALL):
        style_blocks.append(match.group(1))

    if not style_blocks:
        return html

    # Parse CSS rules into (selector, declarations) pairs
    rules: list[tuple[str, str]] = []
    for block in style_blocks:
        # Remove CSS comments
        block = re.sub(r'/\*.*?\*/', '', block, flags=re.DOTALL)
        for rule_match in re.finditer(r'([^{}]+)\{([^{}]+)\}', block):
            selector = rule_match.group(1).strip()
            declarations = rule_match.group(2).strip().rstrip(';')
            if not declarations:
                continue
            # Handle comma-separated selectors
            for sel in selector.split(','):
                sel = sel.strip()
                if sel:
                    rules.append((sel, declarations))

    # Strip <style> tags from HTML
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL)

    # Apply rules by selector type
    for selector, declarations in rules:
        # Skip complex selectors (pseudo, combinators, media queries, attribute selectors)
        if any(ch in selector for ch in (':', '>', '+', '~', '[', '@', ' ')):
            continue

        if selector.startswith('#'):
            # ID selector: #myid
            element_id = selector[1:]
            pattern = re.compile(
                r'(<[^>]+\bid=["\']' + re.escape(element_id) + r'["\'][^>]*)(>)',
                re.IGNORECASE,
            )
        elif selector.startswith('.'):
            # Class selector: .myclass
            class_name = selector[1:]
            pattern = re.compile(
                r'(<[^>]+\bclass="[^"]*\b' + re.escape(class_name) + r'\b[^"]*"[^>]*)(>)',
                re.IGNORECASE,
            )
        elif '.' in selector:
            # tag.class selector
            _tag, class_name = selector.split('.', 1)
            pattern = re.compile(
                r'(<' + re.escape(_tag) + r'[^>]+\bclass="[^"]*\b' + re.escape(class_name) + r'\b[^"]*"[^>]*)(>)',
                re.IGNORECASE,
            )
        else:
            # Tag selector: p, h1, div, etc.
            pattern = re.compile(
                r'(<' + re.escape(selector) + r'(?:\s[^>]*)?)(>)',
                re.IGNORECASE,
            )

        def _add_style(m: re.Match, decls: str = declarations) -> str:
            tag_open = m.group(1)
            close = m.group(2)
            existing = re.search(r'style="([^"]*)"', tag_open)
            if existing:
                merged = existing.group(1).rstrip(';') + '; ' + decls
                tag_open = tag_open[:existing.start()] + f'style="{merged}"' + tag_open[existing.end():]
            else:
                tag_open += f' style="{decls}"'
            return tag_open + close

        html = pattern.sub(_add_style, html)

    return html


def preprocess_html_file(html_file_path: str) -> dict[str, Any]:
    """Read an HTML file and prepare it for weixin publish.

    Steps:
      1. Extract <title> for article title.
      2. Extract <body> content (or use whole file if no <body>).
      3. Inline <style> CSS rules onto elements.
      4. Keep base64 images inline (ProseMirror accepts them via paste).

    Returns dict with keys: title, content.
    """
    html_path = Path(html_file_path).resolve()
    raw_html = html_path.read_text(encoding='utf-8')

    # Extract title
    title_match = re.search(r'<title[^>]*>(.*?)</title>', raw_html, re.IGNORECASE)
    title = title_match.group(1).strip() if title_match else ''

    # Extract body
    body_match = re.search(r'<body[^>]*>(.*)</body>', raw_html, re.DOTALL | re.IGNORECASE)
    body = body_match.group(1).strip() if body_match else raw_html

    # Remove <h1> from body if its text matches the extracted title (avoid duplicate title in article)
    if title:
        def _h1_text(m: re.Match) -> str:
            inner = re.sub(r'<[^>]+>', '', m.group(1)).strip()
            if inner == title:
                return ''  # strip matching <h1>
            return m.group(0)  # keep non-matching <h1>
        body = re.sub(r'<h1[^>]*>(.*?)</h1>', _h1_text, body, flags=re.DOTALL | re.IGNORECASE)

    # Temporarily replace large base64 data URIs with short placeholders
    # so that CSS inlining (regex-based) runs on ~KB instead of ~MB.
    base64_map: dict[str, str] = {}
    placeholder_index = 0

    def _stash_base64(match: re.Match) -> str:
        nonlocal placeholder_index
        placeholder_index += 1
        key = f'__B64_STASH_{placeholder_index}__'
        base64_map[key] = match.group(0)
        return key

    body_light = re.sub(r'data:image/[^"\'>\s]+', _stash_base64, body)

    # Carry over <style> from <head> into body for inline processing
    style_tags = re.findall(r'<style[^>]*>.*?</style>', raw_html, re.DOTALL | re.IGNORECASE)
    body_with_styles = '\n'.join(style_tags) + '\n' + body_light

    # Inline CSS (now fast — only a few KB)
    body_inlined = _inline_css(body_with_styles)

    # Restore base64 data URIs
    for key, original in base64_map.items():
        body_inlined = body_inlined.replace(key, original)

    # Keep base64 images as-is (WeChat ProseMirror accepts them via paste)
    return {
        'title': title,
        'content': body_inlined,
    }


def _validate(
    platform: str,
    media_type: str,
    title: str | None,
    content: str,
    images: list[str] | None,
    video: str | None,
) -> str | None:
    """Pre-flight validation. Returns skip_reason string on failure, None on success."""
    if platform not in SUPPORTED_PLATFORMS:
        return f"unsupported_platform: only {SUPPORTED_PLATFORMS} supported, got {platform!r}"
    if media_type not in SUPPORTED_MEDIA_TYPES:
        return f"unsupported_media_type: must be one of {SUPPORTED_MEDIA_TYPES}"
    if not isinstance(content, str) or not content.strip():
        return "content_required"

    if platform == "twitter":
        if len(content) > TWITTER_MAX_CHARS:
            return f"content_too_long: {len(content)} chars (twitter max {TWITTER_MAX_CHARS})"
        if media_type == "image":
            if not isinstance(images, list) or not images:
                return "images_required: media_type=image needs at least 1 image"
            if len(images) > TWITTER_MAX_IMAGES:
                return f"too_many_images: {len(images)} (twitter max {TWITTER_MAX_IMAGES})"
            for p in images:
                if not isinstance(p, str) or not p:
                    return f"invalid_image_path: {p!r}"
                ip = Path(p)
                if not ip.exists():
                    return f"image_not_found: {p}"
                if not ip.is_file():
                    return f"image_not_a_file: {p}"
                if ip.suffix.lower() not in _TWITTER_ALLOWED_IMG_EXTS:
                    return (
                        f"unsupported_image_format: {ip.suffix} "
                        f"(twitter allowed: {sorted(_TWITTER_ALLOWED_IMG_EXTS)})"
                    )
        elif media_type == "video":
            if not isinstance(video, str) or not video.strip():
                return "video_required: media_type=video needs a single video path"
            vp = Path(video)
            if not vp.exists():
                return f"video_not_found: {video}"
            if not vp.is_file():
                return f"video_not_a_file: {video}"
            if vp.suffix.lower() not in _TWITTER_ALLOWED_VIDEO_EXTS:
                return (
                    f"unsupported_video_format: {vp.suffix} "
                    f"(twitter allowed: {sorted(_TWITTER_ALLOWED_VIDEO_EXTS)})"
                )
        return None

    if platform == "instagram":
        if media_type == "text":
            return "instagram_no_text_only: Instagram requires at least one image or video"
        if len(content) > INSTAGRAM_MAX_CAPTION_CHARS:
            return f"content_too_long: {len(content)} chars (instagram max {INSTAGRAM_MAX_CAPTION_CHARS})"
        if media_type == "image":
            if not isinstance(images, list) or not images:
                return "images_required: media_type=image needs at least 1 image"
            if len(images) > INSTAGRAM_MAX_IMAGES:
                return f"too_many_images: {len(images)} (instagram max {INSTAGRAM_MAX_IMAGES})"
            for p in images:
                if not isinstance(p, str) or not p:
                    return f"invalid_image_path: {p!r}"
                ip = Path(p)
                if not ip.exists():
                    return f"image_not_found: {p}"
                if not ip.is_file():
                    return f"image_not_a_file: {p}"
                if ip.suffix.lower() not in _INSTAGRAM_ALLOWED_IMG_EXTS:
                    return (
                        f"unsupported_image_format: {ip.suffix} "
                        f"(instagram allowed: {sorted(_INSTAGRAM_ALLOWED_IMG_EXTS)})"
                    )
        elif media_type == "video":
            if not isinstance(video, str) or not video.strip():
                return "video_required: media_type=video needs a single video path"
            vp = Path(video)
            if not vp.exists():
                return f"video_not_found: {video}"
            if not vp.is_file():
                return f"video_not_a_file: {video}"
            if vp.suffix.lower() not in _INSTAGRAM_ALLOWED_VIDEO_EXTS:
                return (
                    f"unsupported_video_format: {vp.suffix} "
                    f"(instagram allowed: {sorted(_INSTAGRAM_ALLOWED_VIDEO_EXTS)})"
                )
        return None

    if platform == "douyin":
        if media_type == "text":
            return "douyin_no_text_only: douyin requires at least one image or video"
        if not isinstance(title, str) or not title.strip():
            return "title_required"
        if len(title) > DOUYIN_MAX_TITLE_CHARS:
            return f"title_too_long: {len(title)} chars (douyin max {DOUYIN_MAX_TITLE_CHARS})"
        if len(content) > DOUYIN_MAX_CONTENT_CHARS:
            return f"content_too_long: {len(content)} chars (douyin max {DOUYIN_MAX_CONTENT_CHARS})"
        if media_type == "image":
            if not isinstance(images, list) or not images:
                return "images_required: media_type=image needs at least 1 image"
            if len(images) > DOUYIN_MAX_IMAGES:
                return f"too_many_images: {len(images)} (douyin max {DOUYIN_MAX_IMAGES})"
            for p in images:
                if not isinstance(p, str) or not p:
                    return f"invalid_image_path: {p!r}"
                ip = Path(p)
                if not ip.exists():
                    return f"image_not_found: {p}"
                if not ip.is_file():
                    return f"image_not_a_file: {p}"
                if ip.suffix.lower() not in _DOUYIN_ALLOWED_IMG_EXTS:
                    return (
                        f"unsupported_image_format: {ip.suffix} "
                        f"(douyin allowed: {sorted(_DOUYIN_ALLOWED_IMG_EXTS)})"
                    )
        elif media_type == "video":
            if not isinstance(video, str) or not video.strip():
                return "video_required: media_type=video needs a single video path"
            vp = Path(video)
            if not vp.exists():
                return f"video_not_found: {video}"
            if not vp.is_file():
                return f"video_not_a_file: {video}"
            if vp.suffix.lower() not in _DOUYIN_ALLOWED_VIDEO_EXTS:
                return (
                    f"unsupported_video_format: {vp.suffix} "
                    f"(douyin allowed: {sorted(_DOUYIN_ALLOWED_VIDEO_EXTS)})"
                )
        return None

    if platform == "weixin":
        # html mode: title is extracted from the file, content is pre-processed
        if media_type == "html":
            return None
        if not isinstance(title, str) or not title.strip():
            return "title_required"
        if len(title) > WEIXIN_MAX_TITLE_CHARS:
            return f"title_too_long: {len(title)} chars (weixin max {WEIXIN_MAX_TITLE_CHARS})"
        if len(content) > WEIXIN_MAX_CONTENT_CHARS:
            return f"content_too_long: {len(content)} chars (weixin max {WEIXIN_MAX_CONTENT_CHARS})"
        if media_type == "image":
            if not isinstance(images, list) or not images:
                return "images_required: media_type=image needs at least 1 image"
            if len(images) > WEIXIN_MAX_IMAGES:
                return f"too_many_images: {len(images)} (weixin max {WEIXIN_MAX_IMAGES})"
            for p in images:
                if not isinstance(p, str) or not p:
                    return f"invalid_image_path: {p!r}"
                ip = Path(p)
                if not ip.exists():
                    return f"image_not_found: {p}"
                if not ip.is_file():
                    return f"image_not_a_file: {p}"
                if ip.suffix.lower() not in _WEIXIN_ALLOWED_IMG_EXTS:
                    return (
                        f"unsupported_image_format: {ip.suffix} "
                        f"(weixin allowed: {sorted(_WEIXIN_ALLOWED_IMG_EXTS)})"
                    )
        elif media_type == "video":
            return "weixin_no_video: weixin publish only supports text and image (cover) media types"
        return None

    if platform == "weibo":
        if len(content) > WEIBO_MAX_CONTENT_CHARS:
            return f"content_too_long: {len(content)} chars (weibo max {WEIBO_MAX_CONTENT_CHARS})"
        if media_type == "image":
            if not isinstance(images, list) or not images:
                return "images_required: media_type=image needs at least 1 image"
            if len(images) > WEIBO_MAX_IMAGES:
                return f"too_many_images: {len(images)} (weibo max {WEIBO_MAX_IMAGES})"
            for p in images:
                if not isinstance(p, str) or not p:
                    return f"invalid_image_path: {p!r}"
                ip = Path(p)
                if not ip.exists():
                    return f"image_not_found: {p}"
                if not ip.is_file():
                    return f"image_not_a_file: {p}"
                if ip.suffix.lower() not in _WEIBO_ALLOWED_IMG_EXTS:
                    return (
                        f"unsupported_image_format: {ip.suffix} "
                        f"(weibo allowed: {sorted(_WEIBO_ALLOWED_IMG_EXTS)})"
                    )
        elif media_type == "video":
            if not isinstance(video, str) or not video.strip():
                return "video_required: media_type=video needs a single video path"
            vp = Path(video)
            if not vp.exists():
                return f"video_not_found: {video}"
            if not vp.is_file():
                return f"video_not_a_file: {video}"
            if vp.suffix.lower() not in _WEIBO_ALLOWED_VIDEO_EXTS:
                return (
                    f"unsupported_video_format: {vp.suffix} "
                    f"(weibo allowed: {sorted(_WEIBO_ALLOWED_VIDEO_EXTS)})"
                )
        return None

    # -- xiaohongshu --
    if not isinstance(title, str) or not title.strip():
        return "title_required"
    if len(title) > MAX_TITLE_CHARS:
        return f"title_too_long: {len(title)} chars (max {MAX_TITLE_CHARS})"

    if media_type == "image":
        if not isinstance(images, list) or not images:
            return "images_required: media_type=image needs at least 1 image"
        if len(images) > MAX_IMAGES:
            return f"too_many_images: {len(images)} (max {MAX_IMAGES})"
        for p in images:
            if not isinstance(p, str) or not p:
                return f"invalid_image_path: {p!r}"
            ip = Path(p)
            if not ip.exists():
                return f"image_not_found: {p}"
            if not ip.is_file():
                return f"image_not_a_file: {p}"
            if ip.suffix.lower() not in _ALLOWED_IMG_EXTS:
                return (
                    f"unsupported_image_format: {ip.suffix} "
                    f"(allowed: {sorted(_ALLOWED_IMG_EXTS)})"
                )
    elif media_type == "video":
        if not isinstance(video, str) or not video.strip():
            return "video_required: media_type=video needs a single video path"
        vp = Path(video)
        if not vp.exists():
            return f"video_not_found: {video}"
        if not vp.is_file():
            return f"video_not_a_file: {video}"
        if vp.suffix.lower() not in _ALLOWED_VIDEO_EXTS:
            return (
                f"unsupported_video_format: {vp.suffix} "
                f"(allowed: {sorted(_ALLOWED_VIDEO_EXTS)})"
            )

    return None


def _build_cli_args(
    platform: str,
    media_type: str,
    title: str | None,
    content: str,
    images: list[str] | None,
    video: str | None,
    topics: list[str] | None,
    draft: bool,
    author: str | None = None,
    click_draft_btn: bool = False,
) -> list[str]:
    """Map MCP params → autocli argv. Diverges by platform and media_type."""
    if platform == "twitter":
        if media_type == "image":
            return [
                "twitter", "publish-image",
                "--images", ",".join(str(Path(p).resolve()) for p in (images or [])),
                "--draft", "true" if draft else "false",
                content,
            ]
        elif media_type == "video":
            return [
                "twitter", "publish-video",
                "--video", str(Path(video).resolve()),  # type: ignore[arg-type]
                "--draft", "true" if draft else "false",
                content,
            ]
        return ["twitter", "publish", "--draft", "true" if draft else "false", content]

    if platform == "instagram":
        if media_type == "image":
            return [
                "instagram", "publish-image",
                "--images", ",".join(str(Path(p).resolve()) for p in (images or [])),
                "--draft", "true" if draft else "false",
                content,
            ]
        elif media_type == "video":
            return [
                "instagram", "publish-video",
                "--video", str(Path(video).resolve()),  # type: ignore[arg-type]
                "--draft", "true" if draft else "false",
                content,
            ]
        return []

    if platform == "weixin":
        subcmd = "publish-html" if media_type == "html" else "publish"
        cli = [
            "weixin", subcmd,
            "--title", title or "",
            "--draft", "true" if draft else "false",
        ]
        if author:
            cli.extend(["--author", author])
        if click_draft_btn:
            cli.extend(["--click_draft_btn", "true"])
        if images:
            cli.extend(["--images", ",".join(str(Path(p).resolve()) for p in images)])
        if media_type == "html" and len(content) > 100_000:
            # Content too large for CLI arg — serve via temp HTTP server
            url = _serve_content_once(content)
            cli.append(url)
        else:
            cli.append(content)
        return cli

    if platform == "weibo":
        if media_type == "image":
            cli = [
                "weibo", "publish-image",
                "--images", ",".join(str(Path(p).resolve()) for p in (images or [])),
                "--draft", "true" if draft else "false",
            ]
        elif media_type == "video":
            cli = [
                "weibo", "publish-video",
                "--video", str(Path(video).resolve()),  # type: ignore[arg-type]
                "--draft", "true" if draft else "false",
            ]
        else:
            cli = ["weibo", "publish", "--draft", "true" if draft else "false"]
        if topics:
            cleaned = ",".join(t.strip() for t in topics if t.strip())
            if cleaned:
                cli.extend(["--topics", cleaned])
        cli.append(content)
        return cli

    if platform == "douyin":
        if media_type == "image":
            cli = [
                "douyin", "publish-image",
                "--title", title or "",
                "--images", ",".join(str(Path(p).resolve()) for p in (images or [])),
                "--draft", "true" if draft else "false",
            ]
        else:
            cli = [
                "douyin", "publish-video",
                "--title", title or "",
                "--video", str(Path(video).resolve()),  # type: ignore[arg-type]
                "--draft", "true" if draft else "false",
            ]
        if topics:
            cleaned = ",".join(t.strip() for t in topics if t.strip())
            if cleaned:
                cli.extend(["--topics", cleaned])
        cli.append(content)
        return cli

    # xiaohongshu
    if media_type == "image":
        media_arg = ["--images", ",".join(str(Path(p).resolve()) for p in (images or []))]
        subcommand = "publish"
    else:
        media_arg = ["--video", str(Path(video).resolve())]  # type: ignore[arg-type]
        subcommand = "publish-video"

    cli = [
        platform,
        subcommand,
        "--title", title or "",
        *media_arg,
        "--draft", "true" if draft else "false",
    ]
    if topics:
        cleaned = ",".join(t.strip() for t in topics if t.strip())
        if cleaned:
            cli.extend(["--topics", cleaned])
    cli.append(content)
    return cli


_PLATFORM_START_URLS: dict[str, str] = {
    "xiaohongshu": "https://creator.xiaohongshu.com",
    "twitter": "https://x.com",
    "instagram": "https://www.instagram.com",
    "douyin": "https://creator.douyin.com",
    "weibo": "https://weibo.com",
    "weixin": "https://mp.weixin.qq.com",
}


def _ensure_edge_with_extension(platform: str) -> bool:
    """Start the dedicated Edge profile with the OpenCLI extension loaded.

    Opens the platform's creator page instead of about:blank.
    Skips if the dedicated Edge is already running.
    Returns True if Edge was cold-started (caller should wait longer).
    """
    from .launch_login import _ensure_extension_fresh
    _ensure_extension_fresh()
    if _is_edge_running():
        return False
    edge_exe = paths.edge_executable()
    if edge_exe is None:
        return False
    start_url = _PLATFORM_START_URLS.get(platform, "")
    args = [
        str(edge_exe),
        f"--user-data-dir={paths.EDGE_PROFILE_DIR}",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    if paths.EXTENSION_DIR.exists():
        args.append(f"--load-extension={paths.EXTENSION_DIR}")
    if start_url:
        args.append(start_url)
    try:
        if paths.IS_WINDOWS:
            subprocess.Popen(
                args,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x00000008,  # DETACHED_PROCESS
                close_fds=True,
            )
        else:
            subprocess.Popen(
                args,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
    except OSError:
        return False
    return True


EDGE_COLD_START_SECONDS = 8


async def publish(
    platform: str,
    title: str | None,
    content: str,
    media_type: str = "image",
    images: list[str] | None = None,
    video: str | None = None,
    topics: list[str] | None = None,
    draft: bool = True,
    html_file: str | None = None,
    author: str | None = None,
    click_draft_btn: bool = False,
) -> dict[str, Any]:
    """Publish content on `platform`.

    When ``html_file`` is provided (weixin only), the file is pre-processed
    automatically: title extracted from ``<title>``, CSS inlined, base64
    images kept inline for ProseMirror paste.
    """
    started = time.monotonic()

    # -- html_file: pre-process and override title / content / images / media_type --
    if html_file and platform == "weixin":
        html_path = Path(html_file).resolve()
        if not html_path.exists():
            return {
                "platform": platform, "media_type": "html", "title": title,
                "draft": draft, "status": "skipped", "detail": "",
                "skip_reason": f"html_file_not_found: {html_file}",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        try:
            prep = preprocess_html_file(str(html_path))
        except Exception as exc:
            return {
                "platform": platform, "media_type": "html", "title": title,
                "draft": draft, "status": "skipped", "detail": str(exc),
                "skip_reason": "html_preprocess_error",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        title = prep['title'] or title or "未命名文章"
        content = prep['content']
        media_type = "html"

    skip = _validate(platform, media_type, title, content, images, video)
    if skip:
        return {
            "platform": platform,
            "media_type": media_type,
            "title": title,
            "draft": draft,
            "status": "skipped",
            "detail": "",
            "skip_reason": skip,
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    cold_started = _ensure_edge_with_extension(platform)
    if cold_started:
        await asyncio.sleep(EDGE_COLD_START_SECONDS)

    cli_args = _build_cli_args(
        platform=platform,
        media_type=media_type,
        title=title,
        content=content,
        images=images,
        video=video,
        topics=topics,
        draft=draft,
        author=author,
        click_draft_btn=click_draft_btn,
    )

    try:
        parsed, raw = await run_autocli_json(cli_args, timeout=PUBLISH_TIMEOUT_SECONDS)
    except AutocliNotFoundError as e:
        return {
            "platform": platform,
            "media_type": media_type,
            "title": title,
            "draft": draft,
            "status": "skipped",
            "detail": "",
            "skip_reason": f"autocli_not_installed: {e}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    elapsed = round(time.monotonic() - started, 2)

    if raw.timed_out:
        return {
            "platform": platform,
            "media_type": media_type,
            "title": title,
            "draft": draft,
            "status": "skipped",
            "detail": (raw.stderr or "")[:500],
            "skip_reason": f"timeout: autocli did not finish within {PUBLISH_TIMEOUT_SECONDS}s",
            "elapsed_seconds": elapsed,
        }

    if isinstance(parsed, list) and parsed:
        item = parsed[0] if isinstance(parsed[0], dict) else {}
        return {
            "platform": platform,
            "media_type": media_type,
            "title": title,
            "draft": draft,
            "status": item.get("status", "unknown"),
            "detail": item.get("detail", ""),
            "skip_reason": None,
            "elapsed_seconds": elapsed,
        }

    return {
        "platform": platform,
        "media_type": media_type,
        "title": title,
        "draft": draft,
        "status": "skipped",
        "detail": (raw.stderr or raw.stdout or "")[-500:],
        "skip_reason": f"autocli_error: exit={raw.returncode}, no valid JSON",
        "elapsed_seconds": elapsed,
    }
