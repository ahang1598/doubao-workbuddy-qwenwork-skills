"""Platform metadata for the 35 platforms exposed via `search`.

Each platform record carries:
- `key`: autocli subcommand name (e.g. `bilibili`, `hackernews`)
- `display_name`: human-readable label
- `requires_login`: whether the platform requires a logged-in Edge profile.
  When true, callers may pass the key to `launch_login` to open its login tab.
- `login_url` / `home_url`: only set for login platforms; consumed by
  launch_login to open the right tab in the dedicated Edge.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Platform:
    key: str
    display_name: str
    requires_login: bool
    login_url: str = ""
    home_url: str = ""


# Login-required platforms (20) — autocli reaches them via the Chrome extension
# running in the dedicated Edge profile.
_LOGIN_PLATFORMS: list[Platform] = [
    Platform("xiaohongshu", "小红书",  True,
             "https://www.xiaohongshu.com/explore",
             "https://www.xiaohongshu.com/explore"),
    Platform("bilibili",    "B站",     True,
             "https://passport.bilibili.com/login",
             "https://www.bilibili.com/"),
    Platform("douyin",      "抖音",    True,
             "https://www.douyin.com/",
             "https://www.douyin.com/"),
    Platform("weibo",       "微博",    True,
             "https://passport.weibo.com/sso/signin",
             "https://weibo.com/"),
    Platform("twitter",     "Twitter", True,
             "https://x.com/login",
             "https://x.com/home"),
    Platform("youtube",     "YouTube", True,
             "https://accounts.google.com/ServiceLogin?service=youtube",
             "https://www.youtube.com/"),
    Platform("reddit",      "Reddit",  True,
             "https://www.reddit.com/login/",
             "https://www.reddit.com/"),
    Platform("facebook",    "Facebook", True,
             "https://www.facebook.com/login/",
             "https://www.facebook.com/"),
    Platform("instagram",   "Instagram", True,
             "https://www.instagram.com/accounts/login/",
             "https://www.instagram.com/"),
    Platform("linkedin",    "LinkedIn", True,
             "https://www.linkedin.com/login",
             "https://www.linkedin.com/feed/"),
    Platform("medium",      "Medium",  True,
             "https://medium.com/m/signin",
             "https://medium.com/"),
    Platform("substack",    "Substack", True,
             "https://substack.com/sign-in",
             "https://substack.com/"),
    Platform("tiktok",      "TikTok",  True,
             "https://www.tiktok.com/login",
             "https://www.tiktok.com/"),
    Platform("discord-app", "Discord", True,
             "https://discord.com/login",
             "https://discord.com/app"),
    Platform("coupang",     "Coupang", True,
             "https://login.coupang.com/login/login.pang",
             "https://www.coupang.com/"),
    Platform("reuters",     "Reuters", True,
             "https://www.reuters.com/account/sign-in",
             "https://www.reuters.com/"),
    Platform("barchart",    "Barchart", True,
             "https://www.barchart.com/login",
             "https://www.barchart.com/"),
    Platform("yahoo-finance", "Yahoo Finance", True,
             "https://login.yahoo.com/",
             "https://finance.yahoo.com/"),
    Platform("notion",      "Notion",  True,
             "https://www.notion.so/login",
             "https://www.notion.so/"),
    Platform("chatgpt",     "ChatGPT", True,
             "https://chatgpt.com/auth/login",
             "https://chatgpt.com/"),
    Platform("weixin",      "微信公众号", True,
             "https://mp.weixin.qq.com/",
             "https://mp.weixin.qq.com/"),
    Platform("taobao",     "淘宝/天猫", True,
             "https://login.taobao.com/",
             "https://www.taobao.com/"),
]

# Public-API platforms (15) — no login required.
_PUBLIC_PLATFORMS: list[Platform] = [
    Platform("hackernews",    "HackerNews",    False),
    Platform("lobsters",      "Lobsters",      False),
    Platform("devto",         "Dev.to",        False),
    Platform("stackoverflow", "StackOverflow", False),
    Platform("arxiv",         "Arxiv",         False),
    Platform("hf",            "Hugging Face",  False),
    Platform("wikipedia",     "Wikipedia",     False),
    Platform("google",        "Google",        False),
    Platform("steam",         "Steam",         False),
    Platform("bbc",           "BBC",           False),
    Platform("bloomberg",     "Bloomberg",     False),
    Platform("apple-podcasts", "Apple Podcasts", False),
    Platform("grok",          "Grok",          False),
    Platform("cursor",        "Cursor",        False),
    Platform("codex",         "Codex",         False),
]


ALL_PLATFORMS: list[Platform] = _LOGIN_PLATFORMS + _PUBLIC_PLATFORMS

_BY_KEY: dict[str, Platform] = {p.key: p for p in ALL_PLATFORMS}

PLATFORM_KEYS: list[str] = [p.key for p in ALL_PLATFORMS]
LOGIN_PLATFORM_KEYS: list[str] = [p.key for p in _LOGIN_PLATFORMS]
PUBLIC_PLATFORM_KEYS: list[str] = [p.key for p in _PUBLIC_PLATFORMS]


def get(key: str) -> Platform | None:
    return _BY_KEY.get(key)


def requires_login(key: str) -> bool:
    p = _BY_KEY.get(key)
    return bool(p and p.requires_login)
