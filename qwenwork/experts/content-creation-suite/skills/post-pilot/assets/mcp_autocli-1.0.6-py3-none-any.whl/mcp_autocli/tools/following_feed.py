"""`following_feed` tool — fetch the caller's own "following" stream.

Where this differs from `user_timeline`:
- user_timeline pulls a *specific* user's posts (caller passes a user_id).
- following_feed pulls *the logged-in account's own* following timeline —
  whatever bilibili / twitter shows that account when they hit
  "Following / 关注". No user_id needed because the account itself is the
  selector (via the Edge cookie).

Platform coverage:

| platform  | autocli subcommand    | notes                                    |
|-----------|-----------------------|------------------------------------------|
| bilibili  | `bilibili feed`       | "关注的人的动态时间线"                    |
| twitter   | `twitter timeline`    | for-you / following (default = following)|

Both require an active Edge login on the dedicated profile — autocli reads
the cookie from there. If Edge isn't running we auto-launch (same contract
as search / user_timeline) so the user gets a login window instead of an
opaque `autocli_error`.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

from ..lib import platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    AutocliResult,
    run_autocli_json,
)
from ..lib.result_normalizer import NormalizedItem, normalize
from .search import (
    EXTENSION_HEAL_WAIT_SECONDS,
    RETRYABLE_REASONS,
    RETRY_BACKOFF_SECONDS,
    SEARCH_MAX_ATTEMPTS,
    _auto_launch_edge_for_login,
    _classify_error,
)


FEED_TIMEOUT_SECONDS = 45

# Each value is (subcommand, takes_limit_flag, extra_args). twitter timeline
# accepts a `--type following` flag — default is "for-you", but for a
# content-radar use case "following" gives signal from accounts the user
# already trusts and is the more useful default here.
PLATFORM_FEED_CMD: dict[str, tuple[str, bool, list[str]]] = {
    "bilibili": ("feed",     True, []),
    "twitter":  ("timeline", True, ["--type", "following"]),
}

SUPPORTED_PLATFORMS: list[str] = list(PLATFORM_FEED_CMD.keys())


async def _attempt(args: list[str], platform_key: str) -> tuple[list[NormalizedItem] | None, str | None]:
    try:
        parsed, raw = await run_autocli_json(args, timeout=FEED_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    items = normalize(platform_key, parsed)
    if items:
        return items, None
    return None, "empty_result"


async def _fetch_one(platform_key: str, limit: int) -> tuple[list[NormalizedItem], str | None]:
    spec = PLATFORM_FEED_CMD.get(platform_key)
    if spec is None:
        return [], "unsupported_platform_for_following_feed"
    subcmd, takes_limit, extra = spec
    args = [platform_key, subcmd, *extra]
    if takes_limit:
        args.extend(["--limit", str(limit)])

    last_reason: str | None = None
    for attempt in range(SEARCH_MAX_ATTEMPTS):
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    if last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None

    return [], last_reason


async def following_feed(platform: str, limit: int = 20) -> dict[str, Any]:
    """Pull the logged-in account's own following timeline on one platform.

    Args:
        platform: One of bilibili / twitter.
        limit: Max items to return; capped at 50 in the tool schema.

    Returns:
        {
          "platform": str,
          "items":    [NormalizedItem, ...],
          "metadata": {
            "skip_reason":     str | None,
            "edge_launched":   bool | None,
            "elapsed_seconds": float,
          }
        }
    """
    platform = (platform or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if platform not in platform_defs.PLATFORM_KEYS:
        raise ValueError(f"unsupported platform: {platform}")
    if platform not in PLATFORM_FEED_CMD:
        return {
            "platform": platform,
            "items": [],
            "metadata": {
                "skip_reason": "unsupported_platform_for_following_feed",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
            },
        }

    # Both supported platforms are login-required, but check defensively.
    launch_result = None
    if platform_defs.requires_login(platform):
        launch_result = await _auto_launch_edge_for_login([platform])

    started = time.monotonic()
    items, reason = await _fetch_one(platform, limit)
    elapsed = round(time.monotonic() - started, 2)

    metadata: dict[str, Any] = {
        "skip_reason": reason,
        "edge_launched": bool(launch_result.get("ok")) if launch_result else None,
        "elapsed_seconds": elapsed,
    }
    if launch_result is not None:
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "platform": platform,
        "items": items,
        "metadata": metadata,
    }
