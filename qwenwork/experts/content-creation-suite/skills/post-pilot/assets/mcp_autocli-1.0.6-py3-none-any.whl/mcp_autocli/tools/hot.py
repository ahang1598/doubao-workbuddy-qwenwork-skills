"""`hot` tool — fetch a platform's hot / trending board.

Where this differs from `search`:
- `search` is keyword-driven: caller knows roughly what they're looking for.
- `hot` is keyword-less discovery: "what's the platform's current top of
  mind?" Useful for content-radar's "热点维度" — the kind of signal a
  creator wants when they don't yet have a topic in hand.

Platform coverage:

| platform       | subcommand               | login? | notes                              |
|----------------|--------------------------|--------|------------------------------------|
| bilibili       | `bilibili hot`           | yes    | "B站热门视频"                       |
| bilibili       | `bilibili ranking`       | yes    | rankings board                     |
| weibo          | `weibo hot`              | yes    | "微博热搜"                          |
| twitter        | `twitter trending`       | yes    | "Twitter trending topics"           |
| tiktok         | `tiktok explore`         | yes    | TikTok explore / For You           |
| steam          | `steam top-sellers`      | no     | Steam top-selling games            |
| bbc            | `bbc news`              | no     | BBC top news                       |
| bloomberg      | `bloomberg news`         | no     | Bloomberg top news                 |
| apple-podcasts | `apple-podcasts top`     | no     | Apple Podcasts top charts          |

bilibili exposes two variants (hot / ranking). The default is `hot` because
it's the closer analog to weibo/twitter's "trending right now". Callers who
want the ranking board pass `variant="ranking"`.

hackernews / lobsters / devto / arxiv / hf / wikipedia have NO `hot`
subcommand in autocli today — for those, the existing `search` tool with
a broad keyword and `sort` flag is the closest equivalent. We surface
`unsupported_platform_for_hot` rather than pretend.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

from ..lib import platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    AutocliResult,
    run_autocli_json,
)
from ..lib.result_normalizer import NormalizedItem, normalize
from .search import (
    EXTENSION_HEAL_WAIT_SECONDS,
    RETRYABLE_REASONS,
    RETRY_BACKOFF_SECONDS,
    SEARCH_MAX_ATTEMPTS,
    _auto_launch_edge_for_login,
    _classify_error,
)


HOT_TIMEOUT_SECONDS = 45

# (subcommand, takes_limit_flag, extra_args). `bilibili ranking` doesn't
# universally accept --limit; we apply it client-side via slicing for safety.
PLATFORM_HOT_CMD: dict[tuple[str, str], tuple[str, bool, list[str]]] = {
    ("bilibili", "hot"):         ("hot",          True,  []),
    ("bilibili", "ranking"):     ("ranking",      False, []),
    ("weibo",    "hot"):         ("hot",           True,  []),
    ("twitter",  "hot"):         ("trending",      True,  []),
    ("tiktok",   "hot"):         ("explore",       True,  []),
    ("steam",    "hot"):         ("top-sellers",   False, []),
    ("bbc",      "hot"):         ("news",          True,  []),
    ("bloomberg", "hot"):        ("news",          True,  []),
    ("apple-podcasts", "hot"):   ("top",           True,  []),
}

SUPPORTED_PLATFORMS: list[str] = sorted({k[0] for k in PLATFORM_HOT_CMD})
DEFAULT_VARIANT = "hot"


async def _attempt(args: list[str], platform_key: str) -> tuple[list[NormalizedItem] | None, str | None]:
    try:
        parsed, raw = await run_autocli_json(args, timeout=HOT_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    items = normalize(platform_key, parsed)
    if items:
        return items, None
    return None, "empty_result"


async def _fetch_one(
    platform_key: str, variant: str, limit: int
) -> tuple[list[NormalizedItem], str | None]:
    spec = PLATFORM_HOT_CMD.get((platform_key, variant))
    if spec is None:
        return [], "unsupported_platform_for_hot"
    subcmd, takes_limit, extra = spec
    args = [platform_key, subcmd, *extra]
    if takes_limit:
        args.extend(["--limit", str(limit)])

    last_reason: str | None = None
    for attempt in range(SEARCH_MAX_ATTEMPTS):
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    if last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        items, last_reason = await _attempt(args, platform_key)
        if items:
            return items, None

    return [], last_reason


async def hot(
    platform: str,
    limit: int = 20,
    variant: str = DEFAULT_VARIANT,
) -> dict[str, Any]:
    """Fetch one platform's hot/trending board.

    Args:
        platform: One of bilibili / weibo / twitter. Other keys produce
          `unsupported_platform_for_hot`.
        limit: Max items to return; capped at 50 in the tool schema.
          Applied client-side if the underlying subcommand ignores --limit.
        variant: "hot" (default) or "ranking" (bilibili only).

    Returns:
        {
          "platform": str,
          "variant":  str,
          "items":    [NormalizedItem, ...],
          "metadata": {
            "skip_reason":     str | None,
            "edge_launched":   bool | None,
            "elapsed_seconds": float,
          }
        }
    """
    platform = (platform or "").strip()
    variant = (variant or DEFAULT_VARIANT).strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if platform not in platform_defs.PLATFORM_KEYS:
        raise ValueError(f"unsupported platform: {platform}")
    if (platform, variant) not in PLATFORM_HOT_CMD:
        return {
            "platform": platform,
            "variant": variant,
            "items": [],
            "metadata": {
                "skip_reason": "unsupported_platform_for_hot",
                "edge_launched": None,
                "elapsed_seconds": 0.0,
            },
        }

    launch_result = None
    if platform_defs.requires_login(platform):
        launch_result = await _auto_launch_edge_for_login([platform])

    started = time.monotonic()
    items, reason = await _fetch_one(platform, variant, limit)
    # Apply limit client-side for subcommands that ignore --limit.
    if items and len(items) > limit:
        items = items[:limit]
    elapsed = round(time.monotonic() - started, 2)

    metadata: dict[str, Any] = {
        "skip_reason": reason,
        "edge_launched": bool(launch_result.get("ok")) if launch_result else None,
        "elapsed_seconds": elapsed,
    }
    if launch_result is not None:
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "platform": platform,
        "variant": variant,
        "items": items,
        "metadata": metadata,
    }
