"""`search` tool — fan out autocli search calls across one or more platforms
and merge the normalized results.

Inputs:
- `keyword` (required)
- `platforms` (optional; defaults to all 13 supported platforms)
- `limit_per_platform` (optional; default 20)

Output: dict shaped like
    {
      "keyword": "...",
      "total": <int>,
      "items": [NormalizedItem, ...],
      "metadata": {
        "platforms_searched": [...],
        "platforms_skipped":  [{platform, reason}, ...],
        "elapsed_seconds":    <float>
      }
    }

Per-platform failures are absorbed into `platforms_skipped` rather than raising
— a single dead platform should never poison a multi-platform search. The only
hard error this tool surfaces is `AutocliNotFoundError` (binary missing), which
the server layer converts into a textual MCP error.
"""
from __future__ import annotations

import asyncio
import subprocess
import sys
import time
from typing import Any

from ..lib import paths, platform_defs
from ..lib.autocli_runner import (
    AutocliNotFoundError,
    AutocliResult,
    run_autocli_json,
)
from ..lib.result_normalizer import NormalizedItem, normalize


SEARCH_TIMEOUT_SECONDS = 45

# autocli + the Edge extension are flaky against real sites: a single keyword
# can come back as proper JSON one second and an empty array (or wbiSign / 422)
# the next. Retry transient failures a couple of times before declaring the
# platform truly empty. Reasons that indicate a configuration problem
# (login_required, unsupported_*) are NOT retried. `extension_disconnected`
# gets one inline self-heal pass instead — see _search_one.
SEARCH_MAX_ATTEMPTS = 3
RETRYABLE_REASONS = {"empty_result", "autocli_error", "timeout"}
RETRY_BACKOFF_SECONDS = 0.5
# autocli's CLI already burns ~3.7s of internal HTTP retry against the
# daemon's 503 "extension not connected" response. Sleeping ~3s here on top
# gives the extension's own eager reconnect (2s, 4s, 5s) a fresh window
# before the next autocli call. Anything beyond this covers only the
# pathological "service worker killed, waiting on 24s alarm" case, which
# the agent should escalate via launch_login rather than have us grind on.
EXTENSION_HEAL_WAIT_SECONDS = 3.0

# Each platform exposes a different subcommand for keyword-style retrieval.
# Most use `search <keyword>`; a few use `tag <keyword>` (the platform doesn't
# have a real search API and instead indexes content by tag). A small handful
# don't have keyword retrieval at all — those map to None and the tool
# surfaces `unsupported_search` to the caller.
PLATFORM_SEARCH_CMD: dict[str, str | None] = {
    # --- original 13 ---
    "xiaohongshu":   "search",
    "bilibili":      "search",
    "douyin":        "search",
    "weibo":         "search",
    "twitter":       "search",
    "youtube":       "search",
    "hackernews":    "search",
    "stackoverflow": "search",
    "arxiv":         "search",
    "wikipedia":     "search",
    "lobsters":      "tag",     # `lobsters tag rust` — no general-purpose search
    "devto":         "tag",     # `devto tag ai`     — no general-purpose search
    "hf":            None,      # only `hf top` exists — caller gets `unsupported_search`
    # --- overseas: login-required ---
    "reddit":        "search",
    "facebook":      "search",
    "instagram":     "search",
    "linkedin":      "search",
    "medium":        "search",
    "substack":      "search",
    "tiktok":        "search",
    "discord-app":   "search",
    "coupang":       "search",
    "reuters":       "search",
    "notion":        "search",
    "taobao":        "search",
    "barchart":      None,      # financial data only — no keyword search
    "yahoo-finance": None,      # quote lookup only — no keyword search
    "chatgpt":       None,      # AI chat — no keyword search
    # --- overseas: public ---
    "google":        "search",
    "apple-podcasts": "search",
    "steam":         None,      # only `steam top-sellers` — no keyword search
    "bbc":           None,      # only `bbc news` — no keyword search
    "bloomberg":     None,      # only `bloomberg news` — no keyword search
    "grok":          None,      # AI chat — no keyword search
    "cursor":        None,      # AI IDE — no keyword search
    "codex":         None,      # AI agent — no keyword search
}


def _is_edge_running() -> bool:
    """Check if the dedicated Edge profile (not the user's main Edge) is running.

    Inspects process command lines for the dedicated profile path to avoid
    false positives from the user's own Edge or background WebView2 processes.
    """
    try:
        profile_dir = str(paths.EDGE_PROFILE_DIR)
        if sys.platform == "win32":
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-CimInstance Win32_Process -Filter \"Name='msedge.exe'\" "
                 "| Select-Object -ExpandProperty CommandLine"],
                capture_output=True, text=True, timeout=8,
            )
            return profile_dir in result.stdout
        return subprocess.run(
            ["pgrep", "-f", profile_dir],
            capture_output=True, timeout=3,
        ).returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


# Seconds to give Edge after spawn before letting the main search loop fire.
# Edge cold-start on macOS is ~1-2s; the extension's service worker registers
# and connects within another ~1-2s. autocli itself has 30s of extension-poll
# headroom on top of this, so being conservative here costs almost nothing
# but keeps the first per-platform attempt from wasting a retry.
EDGE_WARMUP_SECONDS = 4.0


async def _auto_launch_edge_for_login(
    login_targets: list[str],
    url_overrides: dict[str, str] | None = None,
    extension_only: bool = False,
) -> dict[str, Any] | None:
    """If Edge isn't running, spawn it with our profile + extension.

    By default opens the platform login pages (for search scenarios).
    Pass *extension_only=True* to launch Edge with just the extension
    (no URL tabs) — useful for publish, where the adapter navigates itself.

    Returns the launch result dict on success, or None if Edge was already up.
    """
    if not login_targets:
        return None
    if _is_edge_running():
        return None

    from .launch_login import launch_login as _launch_login
    try:
        result = await _launch_login(
            platforms=login_targets,
            url_overrides=url_overrides,
            extension_only=extension_only,
        )
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"launch_login raised: {e!r}",
                "opened_pages": [], "user_instruction": ""}

    if result.get("ok"):
        await asyncio.sleep(EDGE_WARMUP_SECONDS)
    return result


def _classify_error(raw: AutocliResult) -> str:
    """Map raw autocli output to a coarse skip reason.

    Distinguish the cases the Wukong agent might want to act on differently:
    login required, extension dead, timeout, empty result, everything else.
    """
    if raw.timed_out:
        return "timeout"
    combined = (raw.combined or "").lower()
    if "login" in combined or "401" in combined or "需要登录" in raw.combined:
        return "login_required"
    if "extension" in combined and ("not connected" in combined or "disconnect" in combined):
        return "extension_disconnected"
    if raw.returncode not in (None, 0):
        return "autocli_error"
    return "empty_result"


async def _attempt_search(
    args: list[str], platform_key: str
) -> tuple[list[NormalizedItem] | None, str | None]:
    """Run one autocli invocation and classify the outcome.

    Returns (items, reason):
    - (items, None)  → success with at least one normalized item
    - (None, reason) → failure, items dropped, or empty result
    Raises AutocliNotFoundError to the caller — binary missing is fatal.
    """
    try:
        parsed, raw = await run_autocli_json(args, timeout=SEARCH_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:
        return None, f"runner_error: {e!r}"

    if parsed is None:
        return None, _classify_error(raw)
    items = normalize(platform_key, parsed)
    if items:
        return items, None
    # Distinguish "platform returned data but everything got dropped (no
    # URL)" from "platform returned nothing".
    return None, "empty_result"


async def _search_one(
    platform_key: str, keyword: str, limit: int
) -> tuple[list[NormalizedItem], str | None]:
    """Search one platform. Returns (items, skip_reason).

    skip_reason is None on success. Items may be empty even on success.
    Transient failures (RETRYABLE_REASONS) are retried up to
    SEARCH_MAX_ATTEMPTS times before being reported as the skip reason.
    `extension_disconnected` gets one extra dedicated heal pass after the
    main loop.
    """
    subcmd = PLATFORM_SEARCH_CMD.get(platform_key)
    if subcmd is None:
        # autocli has no keyword-based command for this platform (e.g. `hf`
        # only exposes `top`). Skip cleanly rather than spawning a doomed call.
        return [], "unsupported_search"
    args = [platform_key, subcmd, keyword, "--limit", str(limit)]

    last_reason: str | None = None
    for attempt in range(SEARCH_MAX_ATTEMPTS):
        items, last_reason = await _attempt_search(args, platform_key)
        if items:
            return items, None
        if last_reason not in RETRYABLE_REASONS:
            break
        if attempt < SEARCH_MAX_ATTEMPTS - 1:
            await asyncio.sleep(RETRY_BACKOFF_SECONDS)

    # One-shot inline self-heal: sleep past autocli's own retry burst to
    # let the Edge extension's eager reconnect land, then try exactly once
    # more. If still disconnected, surface the reason so the agent can
    # escalate via launch_login.
    if last_reason == "extension_disconnected":
        await asyncio.sleep(EXTENSION_HEAL_WAIT_SECONDS)
        items, last_reason = await _attempt_search(args, platform_key)
        if items:
            return items, None

    return [], last_reason


def _resolve_platforms(requested: list[str] | None) -> tuple[list[str], list[dict[str, str]]]:
    """Validate caller-supplied platform list against the supported set.

    Returns (valid_keys, invalid_skipped). Unknown keys are filtered into the
    skipped list with reason `unsupported_platform`.
    """
    if not requested:
        return list(platform_defs.PLATFORM_KEYS), []
    valid: list[str] = []
    skipped: list[dict[str, str]] = []
    for key in requested:
        if key in platform_defs.PLATFORM_KEYS:
            valid.append(key)
        else:
            skipped.append({"platform": key, "reason": "unsupported_platform"})
    return valid, skipped


async def search(
    keyword: str,
    platforms: list[str] | None = None,
    limit_per_platform: int = 20,
) -> dict[str, Any]:
    keyword = (keyword or "").strip()
    if not keyword:
        raise ValueError("keyword must be non-empty")

    targets, skipped = _resolve_platforms(platforms)
    if not targets:
        return {
            "keyword": keyword,
            "total": 0,
            "items": [],
            "metadata": {
                "platforms_searched": [],
                "platforms_skipped": skipped,
                "elapsed_seconds": 0.0,
            },
        }

    # Pre-flight: if any target needs login and Edge isn't running, spawn it
    # ourselves (with the dedicated profile + extension + login tabs) BEFORE
    # touching autocli. Otherwise autocli's own pre-check fails with
    # "Microsoft Edge is not running" — which gets classified as
    # `autocli_error` and lost in retries, and the agent never learns that
    # the right move is launch_login. Doing it here makes the contract
    # "user says 'search xiaohongshu' → Edge login window appears" a hard
    # guarantee instead of relying on the agent to read skip-reason metadata
    # correctly. Public-only searches (e.g. HackerNews) skip this entirely.
    login_targets = [k for k in targets if platform_defs.requires_login(k)]
    launch_result = await _auto_launch_edge_for_login(login_targets)

    # Run platforms serially. Concurrent autocli spawns make the daemon /
    # Edge-extension flake more often (a parallel sweep tends to come back
    # with sporadic empty_result / autocli_error on a subset of platforms).
    # Serial costs more wall-clock but the per-platform results are reliable.
    started = time.monotonic()
    all_items: list[NormalizedItem] = []
    searched: list[str] = []
    for key in targets:
        try:
            items, reason = await _search_one(key, keyword, limit_per_platform)
        except AutocliNotFoundError:
            # Propagate the single hard error — binary missing is fatal.
            raise
        except Exception as e:
            skipped.append({"platform": key, "reason": f"exception: {e!r}"})
            continue
        if reason is not None:
            skipped.append({"platform": key, "reason": reason})
        if items:
            all_items.extend(items)
            searched.append(key)
    elapsed = round(time.monotonic() - started, 2)

    metadata: dict[str, Any] = {
        "platforms_searched": searched,
        "platforms_skipped": skipped,
        "elapsed_seconds": elapsed,
    }
    if launch_result is not None:
        # Tell the agent we already opened Edge + login tabs — its job now is
        # to surface `edge_launch_instruction` to the user verbatim and wait
        # for "已登录" before re-issuing the same search call. Without this
        # field, the agent has no way to distinguish "user just needs to log
        # in" from "platform genuinely returned nothing".
        metadata["edge_launched"] = bool(launch_result.get("ok"))
        instr = launch_result.get("user_instruction") or ""
        if instr:
            metadata["edge_launch_instruction"] = instr
        err = launch_result.get("error")
        if err:
            metadata["edge_launch_error"] = err

    return {
        "keyword": keyword,
        "total": len(all_items),
        "items": all_items,
        "metadata": metadata,
    }
