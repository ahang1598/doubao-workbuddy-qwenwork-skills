"""MCP server exposing autocli search and Edge login launch as tools."""

__version__ = "1.0.6"
