"""`extract_keyframes` tool — capture stills at meaningful timestamps in a video.

Why this exists: content-extractor's douyin/bilibili/xhs flows have a
keyframe-analysis branch that pairs each ASR/subtitle segment with a screenshot
at its start timestamp, used downstream for shot-composition / 分镜分析 reports.
understand_media gives prose description but doesn't return images, so this
fills the gap.

Pipeline:
1. Take a list of segments (output of get_subtitle / transcribe_audio).
2. For each (or every Nth, bounded by max_frames), call
   `ffmpeg -ss <ts> -i <video> -vframes 1` to dump one PNG.
3. Return a list pairing each segment's transcript text with its frame path.

Time stamp parsing: accepts both "0.00s" (transcribe_audio / get_subtitle)
and raw float / integer ms. Robust to both, single helper.

Bounding: max_frames defaults to 20 so a 60-minute video doesn't dump 5000
files. When segments exceed max_frames, we sample uniformly across them
(not just first 20 — last frames are equally informative for video script
generation).
"""
from __future__ import annotations

import asyncio
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any


KEYFRAME_TIMEOUT_PER_FRAME = 15
KEYFRAME_DEFAULT_MAX = 20


def _find_ffmpeg() -> str | None:
    """Locate ffmpeg — PATH first, then imageio-ffmpeg fallback."""
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg  # type: ignore
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        return None


def _parse_timestamp(value: Any) -> float | None:
    """Convert assorted segment.from values into ffmpeg-compatible seconds.

    Accepts:
    - "0.00s" / "12.50s" (transcribe_audio / get_subtitle output)
    - "12.5" / "12" (plain numeric string)
    - 12.5 / 12 (float / int seconds)
    - integer ms when key was 'start_ms' (caller must convert first; we
      treat raw ints/floats > 1000 here as seconds, not ms, because
      our own segment schema is always seconds).

    Returns None when value can't be parsed.
    """
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.strip().rstrip("s").strip()
        if not s:
            return None
        try:
            return float(s)
        except ValueError:
            return None
    return None


def _sample_indices(total: int, max_count: int) -> list[int]:
    """Pick uniformly-spaced segment indices for keyframe extraction.

    Examples:
    - total=5, max=20 → [0, 1, 2, 3, 4]
    - total=100, max=10 → [0, 11, 22, 33, 44, 55, 66, 77, 88, 99]
    """
    if total <= max_count:
        return list(range(total))
    # arithmetic sequence covering full range, inclusive endpoints
    step = (total - 1) / (max_count - 1)
    return [round(i * step) for i in range(max_count)]


def _extract_one_frame(
    ffmpeg: str, video_path: Path, timestamp_s: float, out_path: Path
) -> tuple[bool, str | None]:
    """Run ffmpeg to dump one frame at timestamp_s. Returns (ok, err)."""
    # -ss BEFORE -i is the fast seek (uses index, accurate to ~1s)
    # For sub-second precision, ffmpeg auto-falls-back to slow seek via -accurate_seek.
    cmd = [
        ffmpeg, "-ss", f"{timestamp_s:.3f}", "-i", str(video_path),
        "-vframes", "1", "-q:v", "2",
        "-y", str(out_path),
    ]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=KEYFRAME_TIMEOUT_PER_FRAME,
        )
    except subprocess.TimeoutExpired:
        return False, f"timeout at t={timestamp_s:.2f}s"
    except (FileNotFoundError, OSError) as e:
        return False, f"ffmpeg spawn failed: {e!r}"

    if proc.returncode != 0 or not out_path.exists() or out_path.stat().st_size == 0:
        return False, f"ffmpeg exit {proc.returncode}: {(proc.stderr or '')[-200:]}"
    return True, None


async def extract_keyframes(
    media_path: str,
    segments: list[dict[str, Any]],
    output_dir: str,
    max_frames: int = KEYFRAME_DEFAULT_MAX,
) -> dict[str, Any]:
    """Extract one keyframe per segment timestamp into output_dir.

    Args:
        media_path: Absolute path to a video file (the input to ASR / source
                    of the subtitle). Must contain a video stream.
        segments: List of segment dicts with at least a 'from' (timestamp)
                  field. Designed to accept output of get_subtitle or
                  transcribe_audio directly. 'content' (transcript text) is
                  copied through if present.
        output_dir: Directory to write PNG screenshots into. Created if missing.
        max_frames: Cap the number of frames extracted; when len(segments) >
                    max_frames, sample uniformly across them. Default 20.

    Returns:
        {
          "media_path": str,
          "output_dir": str,
          "frames": [
            {"index": int, "timestamp_str": str, "timestamp_s": float,
             "transcript": str, "screenshot_path": str}
          ],
          "skip_reason": str | None,
          "elapsed_seconds": float
        }
    """
    media_path = (media_path or "").strip()
    if not media_path:
        raise ValueError("media_path must be non-empty")
    if not isinstance(segments, list):
        raise ValueError("segments must be a list")
    if max_frames < 1:
        raise ValueError("max_frames must be >= 1")

    started = time.monotonic()
    src = Path(media_path).expanduser()
    if not src.exists():
        return {
            "media_path": str(src),
            "output_dir": output_dir,
            "frames": [],
            "skip_reason": "input_file_not_found",
            "elapsed_seconds": 0.0,
        }

    ffmpeg = _find_ffmpeg()
    if not ffmpeg:
        return {
            "media_path": str(src),
            "output_dir": output_dir,
            "frames": [],
            "skip_reason": "ffmpeg_not_found (run `mcp-autocli setup`)",
            "elapsed_seconds": 0.0,
        }

    if not segments:
        return {
            "media_path": str(src),
            "output_dir": output_dir,
            "frames": [],
            "skip_reason": "empty_segments (call transcribe_audio / get_subtitle first)",
            "elapsed_seconds": 0.0,
        }

    out_dir = Path(output_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    sampled = _sample_indices(len(segments), max_frames)

    sem = asyncio.Semaphore(4)  # ffmpeg is CPU/IO bound, 4 parallel is plenty

    async def _one(seg_idx: int) -> dict[str, Any] | None:
        seg = segments[seg_idx]
        ts_raw = seg.get("from")
        ts_s = _parse_timestamp(ts_raw)
        if ts_s is None:
            return {
                "index": seg_idx,
                "timestamp_str": str(ts_raw),
                "timestamp_s": None,
                "transcript": seg.get("content", ""),
                "screenshot_path": None,
                "error": f"unparseable timestamp: {ts_raw!r}",
            }
        out_name = f"frame_{seg_idx:03d}_{int(ts_s):04d}s.png"
        out_path = out_dir / out_name
        async with sem:
            ok, err = await asyncio.to_thread(
                _extract_one_frame, ffmpeg, src, ts_s, out_path,
            )
        return {
            "index": seg_idx,
            "timestamp_str": str(ts_raw),
            "timestamp_s": ts_s,
            "transcript": seg.get("content", ""),
            "screenshot_path": str(out_path) if ok else None,
            "error": err if not ok else None,
        }

    results = await asyncio.gather(*[_one(i) for i in sampled])
    ok_frames = [r for r in results if r and r.get("screenshot_path")]
    failed = [r for r in results if r and not r.get("screenshot_path")]

    skip_reason = None
    if not ok_frames:
        first_err = failed[0]["error"] if failed else "all_frames_failed"
        skip_reason = f"all_frames_failed: {first_err}"
    elif failed:
        skip_reason = f"partial: {len(ok_frames)}/{len(results)} ok; first error: {failed[0]['error']}"

    return {
        "media_path": str(src),
        "output_dir": str(out_dir),
        "frames": ok_frames,
        "skip_reason": skip_reason,
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
