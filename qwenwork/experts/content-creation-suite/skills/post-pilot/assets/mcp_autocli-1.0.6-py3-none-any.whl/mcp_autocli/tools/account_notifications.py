"""`account_notifications` tool — pull the logged-in account's notification
inbox on one platform. Designed for content-radar's "what are people actually
talking about with me right now" lane (mentions / @ / comments-on-my-stuff /
follows). The signal density is high because every entry is a real human's
real interaction with the user's own content.

Per-platform autocli call + args we expose:
- douyin:      `notifications --type {all|like|comment|follow|at} --limit N`
- twitter:     `notifications --limit N`  (no type filter)

Output columns differ slightly by platform — xhs/douyin use
[rank/user/action/content/...] rows, twitter uses [id/action/author/text/url].
We don't try to unify the schema beyond passing through autocli's rows so the
caller has access to all fields. `notification_type` is echoed back for
xhs/douyin so the agent can see which inbox tab was queried.

Output schema:
    {
      "platform": str,
      "notification_type": str | None,
      "items": list[dict],
      "skip_reason": str | None,
      "elapsed_seconds": float
    }
"""
from __future__ import annotations

import time
from typing import Any

from ..lib.autocli_runner import AutocliNotFoundError, run_autocli_json


# Defaults to the busiest / most useful inbox per platform (mentions on xhs,
# everything on douyin); caller can override.
_PLATFORM_DEFAULT_TYPE: dict[str, str] = {
    "douyin": "all",
    "twitter": "",  # no type filter
}

SUPPORTED_PLATFORMS: list[str] = list(_PLATFORM_DEFAULT_TYPE.keys())

NOTIFICATIONS_TIMEOUT_SECONDS = 60

# Valid type values per platform — we don't enforce at the MCP layer (autocli
# will reject bad values with a clear error), but documenting here for
# server.py's tool schema.
_PLATFORM_VALID_TYPES: dict[str, list[str]] = {
    "douyin":      ["all", "like", "comment", "follow", "at"],
    "twitter":     [],  # twitter has no --type
}


async def account_notifications(
    platform: str,
    notification_type: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """Fetch notifications for the logged-in account.

    Args:
        platform: One of SUPPORTED_PLATFORMS.
        notification_type: Optional per-platform inbox filter. Default picks
            the busiest inbox (xhs=mentions, douyin=all). Twitter ignores this
            arg — the platform exposes only one combined inbox.
        limit: Max items to return (default 20).

    Returns:
        See module docstring.
    """
    platform = (platform or "").strip()
    if not platform:
        raise ValueError("platform must be non-empty")
    if platform not in SUPPORTED_PLATFORMS:
        return {
            "platform": platform,
            "notification_type": None,
            "items": [],
            "skip_reason": f"unsupported_platform (only {SUPPORTED_PLATFORMS})",
            "elapsed_seconds": 0.0,
        }

    started = time.monotonic()

    args: list[str] = [platform, "notifications"]

    # Determine effective notification_type
    effective_type = (notification_type or "").strip() or _PLATFORM_DEFAULT_TYPE[platform]

    # Only pass --type for platforms that support it
    if platform == "douyin":
        args.extend(["--type", effective_type])

    args.extend(["--limit", str(limit)])

    try:
        parsed, raw = await run_autocli_json(args, timeout=NOTIFICATIONS_TIMEOUT_SECONDS)
    except AutocliNotFoundError:
        raise
    except Exception as e:  # noqa: BLE001
        return {
            "platform": platform,
            "notification_type": effective_type or None,
            "items": [],
            "skip_reason": f"autocli_spawn_error: {e!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    if not isinstance(parsed, list):
        tail = (raw.stdout or raw.stderr or "")[-200:]
        return {
            "platform": platform,
            "notification_type": effective_type or None,
            "items": [],
            "skip_reason": f"no_list_output: {tail!r}",
            "elapsed_seconds": round(time.monotonic() - started, 2),
        }

    return {
        "platform": platform,
        "notification_type": effective_type or None,
        "items": parsed,
        "skip_reason": None if parsed else "empty_inbox",
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
